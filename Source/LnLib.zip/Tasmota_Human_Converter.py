#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 11-01-2023 18.33.00


import  sys; sys.dont_write_bytecode = True
import  os

import sys
import json, yaml
from types import SimpleNamespace
from datetime import timedelta, datetime
import time
this=sys.modules[__name__]


if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Utils')
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/tasmota')


from LnUtils import is_integer_in_range, toYaml
from LnSunTime import sunTime_casetta






def setup(*, gVars):
    global logger
    logger=gVars.logger



####################################################################
# "RESULT": {
#         "Timers": "ON",
#         "Timer1": {
#             "Enable": 1,
#             "Mode": 0,
#             "Time": "01:00",
#             "Window": 0,
#             "Days": "1111111",
#             "Repeat": 1,
#             "Output": 1,
#             "Action": 0
#         },
#
# voglamo tradurlo in:
#    Timers:
#       T1.x: 17:21 on LMMGVSD sS   x rappresenta il relay di output
#       T2.x: 22:30 off LMMGVSD   x rappresenta il relay di output
####################################################################
def timersToHuman(dev_data: dict, relay_nr: int=0) -> dict:
    # -----------------------------------
    def _convertWeekDays(val):
        _it_days='DLMMGVS' # tasmota days start from Sunday
        _en_days='SMTWTFS' # tasmota days start from Sunday
        separator='_ '
        _data=''
        for i in range(0, 7):
            _data+=_en_days[i] if val[i]=='1' else separator
        return _data[1:] + _data[0] # lets start from Monday



    # -----------------------------------
    def sum_offset(t0_time, offset):
        offset_HH, offset_MM=offset.split(':')
        offset_minutes=abs(int(offset_HH))*60+int(offset_MM)
        if offset_minutes==0:
            return t0_time

        t0_HH, t0_MM=t0_time.split(':')
        t0=timedelta(hours=int(t0_HH), minutes=int(t0_MM))
        ofs=timedelta(hours=int(offset_HH), minutes=int(offset_MM))

        if offset[0]=='-':
            new_time=t0-ofs
        else:
            new_time=t0+ofs

        return time.strftime("%H:%M", time.gmtime(new_time.total_seconds()))

    # -----------------------------------


    if relay_nr<1:
        relay_nr=list(range(1,16+1)) # possono essere massimo 16 timers
    else:
        relay_nr=[min(int(relay_nr), 16)] # per evitare > 16

    _action=['off', 'on', 'toggle', 'rule/blink']
    _mode=['clock time', 'sunrise', 'sunset']
    sunrise_time, sunset_time=sunTime_casetta(str_format='%H:%M')

    myTimers={}

    if not dev_data or not 'Timers' in dev_data:
        logger.caller("data: %s", dev_data)
        return "N/A"


    areEnabled=(dev_data['Timers']=="ON")

    if areEnabled:
        for name in dev_data.keys():
            if not name.startswith('Timer'): ### per sicurezza
                continue

            index=name.split('Timer')[1] ### get timer_number, skip "Timers key"
            if index.isdigit():
                timer_nr=int(index)
            else:
                continue

            timerx=dev_data[f'Timer{timer_nr}']
            if timerx['Enable']==0:
                continue

            output=int(timerx['Output'])
            if output not in relay_nr:
                continue

            MODE=_mode[int(timerx['Mode'])]
            ACTION=_action[int(timerx['Action'])]
            REPEAT='-R' if timerx['Repeat']==1 else '-N'
            offset=timerx["Time"]
            DAYS=_convertWeekDays(timerx['Days'])
            RELAY=timerx['Output']

            if MODE == 'sunset':
                onTime=' sS'
                offset=timerx["Time"]
                _time=sum_offset(t0_time=sunset_time,offset=offset)

            elif MODE == 'sunrise':
                onTime=' sR'
                _time=sum_offset(t0_time=sunrise_time,offset=offset)

            else:
                onTime=''
                _time=timerx["Time"]

            fOutput=False
            if fOutput:
                myTimers[f't{timer_nr}.{output}{REPEAT}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}' ### con Output indicator
            else:
                myTimers[f't{timer_nr}{REPEAT}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}'
    else:
        myTimers='Disabled'

    return myTimers




####################################################################################################
# setTimer number ena_dis HH:MM   days   output   repeat action
# setTimer   1    ena|dis 12:30 -1--1-1     1       r|n      on
# setTimer   1    ena|dis 12:30 dlmMgvs     1       r|n      on
# ref: https://tasmota.github.io/docs/Timers/#json-payload-anatomy
#-
# return:
#       Timer1 {"Enable":1,"Time":"02:23","Window":0,"Days":"--TW--S","Repeat":1,"Output":1,"Action":1}
####################################################################################################
def humanToTimer_prev(data: (str, list), nRelays: int) -> dict:
    ret=SimpleNamespace(rcode=1, err_msg=None, timer={})
    if isinstance(data, str):
        token=data.split()
    else:
        token=data[:]

    nargs=len(token)
    if nargs not in [2, 7]:
        ret.err_msg="invalid arguments number"
        return ret


    timerx={}
    if nargs>=2:
        timer, ena_disa, *rest=token
        timer_nr=is_integer_in_range(timer, 1, 16)
        if timer_nr is False:
            ret.err_msg=f"invalid timer [{timer}] number"
            return ret

        elif ena_disa not in ['ena', 'enable', 'dis', 'disa', 'disable']:
            ret.err_msg=f"invalid [{ena_disa}] keyword"
            return ret

        timerx['Enable']=1 if ena_disa in ['ena', 'enable'] else 0
        ret.rcode=0


    if nargs==7:
        hhmm, days, output, repeat, action=rest

        hh, mm, *rest=f'{hhmm}:'.split(':') # per evitare errore nello splitting
        hh=is_integer_in_range(hh, 0, 23)
        mm=is_integer_in_range(mm, 0, 59)
        if hh is False or mm is False:
            ret.err_msg=f"invalid time [{hhmm}] value"
            return ret

        _it_days='dlmMgvs' # tasmota days start from Sunday
        _en_days='smtwtfs' # tasmota days start from Sunday
        _days=''
        for i in range(0, 7):
            _days+="1" if _it_days[i] in days else "0"
        days=_days

        relay_nr=is_integer_in_range(output, 1, nRelays)
        if relay_nr is False:
            ret.err_msg=f"relay number [{output}] is out of device's relays "
            return ret

        if repeat not in ['r', 'n']:
            ret.err_msg=f"invalid repeat [{repeat}] value"
            return ret

        if action.lower() not in ["on", "off", "toggle"]:
            ret.err_msg=f"invalid action [{action}] value"
            return ret

        _timerx={
                "Mode": 0, # clock
                "Time": f'{hh}:{mm}',
                "Window": 0,
                "Days": days,
                "Repeat": (1 if repeat=='r' else 0),
                "Output": relay_nr,
                "Action": action,
            }

        timerx.update(_timerx)
        ret.rcode=0


    ret.payload=timerx
    ret.timer_nr=f"Timer{timer_nr}"

    return ret



import argparse


def reply_text(text, parse_mode="html"):
    print(text)
    return None


##############################################################
# - Parse Input
##############################################################
def parsingTimerString(argString):
    global ret
    import sys, shlex
    import argparse
    ret=SimpleNamespace(rcode=None, err_msg=None, args=None)

    class MyArgumentParser(argparse.ArgumentParser):
        def print_help(self, file=None):
            global ret
            if file is None:
                file = sys.stdout
            return h_usage()

        def error(self, message):
            global ret
            ret.err_msg=message
            ret.rcode="error"
            return ret



    def h_usage():
        global ret
        _syntax=f'''
            args:
                number:    timer number (1-16)
                --enable:    yes | no
                --action:    on | off
                --time:      hh:mm
                --days:      lmMgvsd
                --output:    relay nr
                --repeat:    yes | no
        '''
        _syntax=yaml.load(_syntax, Loader=yaml.SafeLoader)
        ret.rcode='h_usage'
        ret.err_msg=_syntax
        return ret



    def _time(hhmm):
        hh, mm, *rest=f'{hhmm}:'.split(':') # per evitare errore nello splitting
        hh=is_integer_in_range(hh, 0, 23)
        mm=is_integer_in_range(mm, 0, 59)
        if hh is False or mm is False:
            ret.err_msg=f"invalid time [{hhmm}] value"
            ret.rcode="_time"

        return hhmm

    def _days(days):
        _it_days='dlmMgvs' # tasmota days start from Sunday
        _en_days='smtwtfs' # tasmota days start from Sunday
        _days=''
        for i in range(0, 7):
            _days+="1" if _it_days[i] in days else "0"
        return _days


    if len(argString.strip())==0:
        return h_usage()

    # =============================================
    # = Parsing
    # =============================================
    # parser = argparse.ArgumentParser(description='ebooks management',
    parser = MyArgumentParser(description='Tasmota Timer settings',
                                    # add_help=False,
                                    # usage=h_usage(), # quando c'è un errore
                                    formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                                    )

    ### positional
    parser.add_argument('number', help='timer number 1-16',  type=int,   choices=range(1, 17))

    parser.add_argument('--action', help='on | off',        required=True, type=str, choices=['on', 'off'])
    parser.add_argument('--enable', help='yes | no',        required=True, type=str, choices=['yes', 'no'])
    ### optional
    parser.add_argument('--repeat', help='yes | no',        required=False, type=str, choices=['yes', 'no'])
    parser.add_argument('--days',   help='lmMgvsd',         required=False, type=_days, default=''),
    parser.add_argument('--time',   help='hh:mm',           required=False, type=_time )
    parser.add_argument('--output', help='output relay nr', required=False, type=int, default=1)

    parser.add_argument('--display-args', help='display args', action='store_true')


    # enable_group=parser.add_mutually_exclusive_group(required=True)
    # parser.add_argument('--enable', help='enable timer', action='store_true')
    # parser.add_argument('--disable', help='disable timer', action='store_true')

    argString=argString.replace('—', '--')
    try:
        args = parser.parse_args(shlex.split(argString))
        ret.args=args
        if args.display_args:
            import json
            json_data = json.dumps(vars(args), indent=4, sort_keys=True)
            print('input arguments: {json_data}'.format(**locals()))
    except:
        ret.rcode="try"



    return  ret

####################################################################################################
# setTimer number ena_dis HH:MM   days   output   repeat action
# setTimer   1    ena|dis 12:30 -1--1-1     1       r|n      on
# setTimer   1    ena|dis 12:30 dlmMgvs     1       r|n      on
# ref: https://tasmota.github.io/docs/Timers/#json-payload-anatomy
#-
# return:
#       Timer1 {"Enable":1,"Time":"02:23","Window":0,"Days":"--TW--S","Repeat":1,"Output":1,"Action":1}
####################################################################################################
def humanToTimer(data: (str, list), nRelays: int) -> dict:
    ret=SimpleNamespace(rcode=1, err_msg=None, timerx={})

    if isinstance(data, list):
        argString=' '.join(data)
    else:
        argString=data

    result=parsingTimerString(argString)
    if result.rcode:
        return result

    else:
        args=result.args

        timerx={
                "Mode": 0, # clock
                "Enable": (1 if args.enable=='yes' else 0),
                "Time": args.time,
                "Window": 0,
                "Days": args.days,
                "Repeat": (1 if args.repeat=='yes' else 0),
                "Output": args.output,
                "Action": (1 if args.action=='on' else 0),
            }

        ret.rcode=0
        ret.payload=timerx
        ret.timerx=f"Timer{args.number}"

    return ret





####################################################################
#
# {"PulseTime":{"Set":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"Remaining":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}}
#
#   PulseTime<x>:   Display the amount of PulseTime remaining on the corresponding Relay<x>
#           0 / OFF = disable use of PulseTime for Relay<x>
#           1..111 = set PulseTime for Relay<x> in 0.1 second increments
#           112..64900 = set PulseTime for Relay<x>, offset by 100, in 1 second increments.
#           Add 100 to desired interval in seconds, e.g.,
#           PulseTime 113 = 13 seconds and PulseTime 460 = 6 minutes (i.e., 360 seconds)
#           <value> Set the duration to keep Relay<x> ON when Power<x> ON command is issued.
#           After this amount of time, the power will be turned OFF.
#
####################################################################
def humanToPulseTime(value: str):
    ret=SimpleNamespace(rcode=1, err_msg=None, pulsetime_value=0)

    #-------------------------------------------------
    def secondsToPulseTime(seconds: float) -> int:
        seconds=float(seconds)
        if seconds<=11.1:
            pulsetime_value=seconds*10
        else:
            pulsetime_value=float(seconds)+100

        return float(pulsetime_value)
    #-------------------------------------------------

    try: ### if passed as seconds
        ret.pulsetime_value=secondsToPulseTime(seconds=float(value))
        rcode=0

    except (ValueError):
        try:
            mm, ss=value.split(':')
            ret.pulsetime_value=secondsToPulseTime(seconds=int(mm)*60+float(ss))
            ret.rcode=0

        except (Exception) as exc:
            ret.err_msg=f"ERROR evaluating seconds value '{value}')"

    return ret



####################################################################
### preparazione stato PulseTime
### relay_nr: parte da '0''
####################################################################
   #----------------------------------------------
def pulseTimeToHuman(dev_data: dict, relay_nr: int, strip_leading=False):
    def millisecs_to_HMS_ms(milliseconds, strip_leading=False):
        s, ms = divmod(milliseconds, 1000)
        m, s = divmod(s, 60)
        h, m = divmod(m, 60)
        hours=int(h)
        minutes=int(m)
        seconds=int(s)
        # milliseconds=int(ms)
        milliseconds = f'.{int(ms):01}' if ms>0 else ''

        ret_val=f'{hours:02}:{minutes:02}:{seconds:02}{milliseconds}'
        if strip_leading:
            if h==0 and minutes==0:
                ret_val=f'{seconds:02}{milliseconds}'
            elif h==0:
                ret_val=f'{minutes:02}:{seconds:02}{milliseconds}'


        return ret_val

    #-----------------------------------------------
    def pulsetime_to_ms(value):
        if value<=111:
            seconds=int(value/10)
            milliseconds=(value/10)*1000
        else:
            seconds=int(value-100)
            milliseconds=(value-100)*1000
        return milliseconds
    #-----------------------------------------------


    pulsetime_set="?"
    pulsetime_remaining="?"

    if dev_data:
        SET=dev_data["Set"]
        _ms=pulsetime_to_ms(SET[relay_nr])
        pulsetime_value=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)

        REMAINING=dev_data["Remaining"]
        _ms=pulsetime_to_ms(REMAINING[relay_nr])
        pulsetime_remaining=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)



    return pulsetime_value, pulsetime_remaining



#################################################
#
#################################################
def checkRange(value: int, min: int, max: int) -> int:
    ret=SimpleNamespace(rcode=1, err_msg=None, value=-1)

    try:
        if int(min) <= int(value) <= int(max)+1:
            ret.value=int(value)
            ret.rcode=0
        else:
            raise ValueError

    except (ValueError):
        ret.err_msg=f"value: '{value}' is out of range"

    except (Exception) as exc:
        ret.err_msg=str(exc)


    return ret






TIMERS= {
        "Timers": "ON",
        "Timer1": {
            "Enable": 1,
            "Mode": 0, # clock
            "Mode": 2, # sunset
            "Mode": 1, # sunrise
            "Time": "01:30",
            "Window": 0,
            "Days": "1111111",
            "Repeat": 1,
            "Output": 1,
            "Action": 0
        },
        "Timer2": {
            "Enable": 1,
            "Mode": 0, # clock
            "Mode": 1, # sunrise
            "Mode": 2, # sunset
            "Time": "01:30",
            "Window": 0,
            "Days": "1111111",
            "Repeat": 1,
            "Output": 2,
            "Action": 0
        },
    }



if __name__ == '__main__':
    argString=' '.join(sys.argv[1:])
    print(argString)
    result=parsingTimerString(argString)
    if result.rcode:
        print('........fine', result.rcode, toYaml(result.err_msg))
    else:
        print('........fine', result.args)
    sys.exit()
    # setTimer              number HH:MM   days   output   repeat action
    # setTimer                1    12:30 -1--1-1     1       1      on
    args="1 ena 21:15 dlmMgvs  1   ry   on"
    data=humanToTimer(data=args, nRelays=1)
    print(args)
    print("     ", data)

    args="1 ena 21:15 M  1   ry   on"
    data=humanToTimer(data=args, nRelays=1)
    print(args)
    print("     ", data)

    args="1 ena"
    data=humanToTimer(data=args, nRelays=1)
    print(args)
    print("     ", data)

    args="1 dis"
    data=humanToTimer(data=args, nRelays=1)
    print(args)
    print("     ", data)

    # data=humanToTimer(data='1 enable', nRelays=1)
    # print(data)

