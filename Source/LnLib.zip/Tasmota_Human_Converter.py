#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 30-11-2022 18.05.22


import  sys; sys.dont_write_bytecode = True
import  os

import sys
import json, yaml
from types import SimpleNamespace
from datetime import timedelta, datetime
import time
this=sys.modules[__name__]

from LnSuntimes import sunTime_casetta




   #----------------------------------------------
def pulseTimeToHuman(value: int) -> int:
    """Errori strani:
        remaining 1886060 invece di 132 - 1886192
        remaining 1885929 invece di 115 - 1886044
    """
    #-----------------------------------------------
    def millisecs_to_HMS_ms(milliseconds, strip_leading=False):
        s, ms = divmod(milliseconds, 1000)
        m, s = divmod(s, 60)
        h, m = divmod(m, 60)

        hours=int(h)
        minutes=int(m)
        seconds=int(s)
        milliseconds=int(ms)

        ret_val=f'{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:01}'
        if strip_leading:
            if h==0 and minutes==0:
                ret_val=f'{seconds:02}.{milliseconds:01}'
            elif h==0:
                ret_val=f'{minutes:02}:{seconds:02}.{milliseconds:01}'

        return ret_val
    #-----------------------------------------------

    if value<=111:
        seconds=int(value/10)
        milliseconds=(value/10)*1000
    else:
        seconds=int(value-100)
        milliseconds=(value-100)*1000
    return millisecs_to_HMS_ms(milliseconds=milliseconds, strip_leading=True)
#----------------------------------------------







####################################################################
#
# {"PulseTime":{"Set":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"Remaining":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}}
#
#   PulseTime<x>:   Display the amount of PulseTime remaining on the corresponding Relay<x>
#           0 / OFF = disable use of PulseTime for Relay<x>
#           1..111 = set PulseTime for Relay<x> in 0.1 second increments
#           112..64900 = set PulseTime for Relay<x>, offset by 100, in 1 second increments.
#           Add 100 to desired interval in seconds, e.g.,
#           PulseTime 113 = 13 seconds and PulseTime 460 = 6 minutes (i.e., 360 seconds)
#           <value> Set the duration to keep Relay<x> ON when Power<x> ON command is issued.
#           After this amount of time, the power will be turned OFF.
#
####################################################################
def humanToPulseTime(args: list, nRelays: int) -> SimpleNamespace:
    """ setPulseTime <relay> <seconds>  -->  pulsetime<relay> <pt_units>
        setPulseTime <relay> <MM:SS>    -->  pulsetime<relay> <pt_units>
    """
    #-------------------------------------------------
    def secondsToPulseTime(seconds: float) -> int:
        seconds=float(seconds)
        if seconds<=11.1:
            pulsetime_value=seconds*10
        else:
            pulsetime_value=float(seconds)+100

        return float(pulsetime_value)
    #-------------------------------------------------


    msg=None
    if len(args)>1:
        ret=checkRelayNumber(arg=args[0], nRelays=nRelays)
        if ret.err_msg:
            return ret
        else:
            relay=ret.relay

        if isinstance(args[1], (int, float)):
            value=secondsToPulseTime(seconds=args[1])

        else:
            try: ### if passed as seconds
                value=secondsToPulseTime(seconds=float(args[1]))

            except (ValueError):
                try:
                    mm, ss=args[1].split(':')
                except (Exception) as exc:
                    msg=f"ERROR evaluating seconds value '{args[1]}')"
                    value=-1

                pt.value=secondsToPulseTime(seconds=float(mm)*60+float(ss))

    else:
        pt.msg='missing args...'


    pt=SimpleNamespace()
    pt.value=value
    pt.msg=msg
    pt.relay=relay
    return pt






#################################################
# Load device json file
#################################################
def checkRelayNumber(arg: (int, str), nRelays: int) -> SimpleNamespace:
    ### check if target relay is valid
    relay=-1 ### error

    if arg:
        try:
            relay=int(arg) # get required relay
            if (relay in range(1, nRelays+1)):
                err_msg=None
            else:
                relay=-1
                err_msg=f"relay: '{relay}' is out of device output range! [1, {nRelays})]"


        except (ValueError):
            err_msg=f"Relay number '{arg}' is not valid!"

        except (Exception) as exc:
            err_msg=f"ERROR evaluating relay number '{arg}')"

    else:
        err_msg=f"ERROR missing relay number '{arg}')"


    ret=SimpleNamespace()
    ret.err_msg=err_msg
    ret.relay=relay
    return ret





####################################################################
# "RESULT": {
#         "Timers": "ON",
#         "Timer1": {
#             "Enable": 1,
#             "Mode": 0,
#             "Time": "01:00",
#             "Window": 0,
#             "Days": "1111111",
#             "Repeat": 1,
#             "Output": 1,
#             "Action": 0
#         },
#
# voglamo tradurlo in:
#    Timers:
#       T1.x: 17:21 on LMMGVSD sS   x rappresenta il relay di output
#       T2.x: 22:30 off LMMGVSD   x rappresenta il relay di output
####################################################################
def timersToHuman(data: dict, outputRelay: int=0, italic=False) -> dict:
    # -----------------------------------
    def _convertWeekDays(val):
        _it_days='DLMMGVS' # tasmota days start from Sunday
        _en_days='SMTWTFS' # tasmota days start from Sunday
        _data=''
        for i in range(0, 7):
            _data+=_en_days[i] if val[i]=='1' else '_ '
        return _data[1:] + _data[0] # lets start from Monday



    # -----------------------------------
    def sum_offset(t0_time, offset):
        offset_HH, offset_MM=offset.split(':')
        offset_minutes=abs(int(offset_HH))*60+int(offset_MM)
        if offset_minutes==0:
            return t0_time

        t0_HH, t0_MM=t0_time.split(':')
        t0=timedelta(hours=int(t0_HH), minutes=int(t0_MM))
        ofs=timedelta(hours=int(offset_HH), minutes=int(offset_MM))

        if offset[0]=='-':
            new_time=t0-ofs
        else:
            new_time=t0+ofs

        return time.strftime("%H:%M", time.gmtime(new_time.total_seconds()))

    # -----------------------------------
    if outputRelay<1:
        outputRelay=list(range(1,16+1)) # possono essere massimo 16 timers
    else:
        outputRelay=[min(int(outputRelay), 16)] # per evitare > 16

    _action=['off', 'on', 'toggle', 'rule/blink']
    _mode=['clock time', 'sunrise', 'sunset']
    sunrise_time, sunset_time=sunTime_casetta(str_format='%H:%M')



    myTimers={}

    areEnabled=(data['Timers']=="ON")

    if areEnabled:

        for name in data.keys():
            index=name[-1]
            if index.isdigit():
                i=int(index)
            else:
                continue

            timerx=data[f'Timer{i}']
            if timerx['Enable']==0:
                continue

            output=int(timerx['Output'])
            if output not in outputRelay:
                continue

            MODE=_mode[int(timerx['Mode'])]
            ACTION=_action[int(timerx['Action'])]
            REPEAT='YES' if timerx['Repeat']=='1' else 'NO'
            offset=timerx["Time"]
            DAYS=_convertWeekDays(timerx['Days'])
            RELAY=timerx['Output']

            if MODE == 'sunset':
                onTime=' sS'
                offset=timerx["Time"]
                _time=sum_offset(t0_time=sunset_time,offset=offset)

            elif MODE == 'sunrise':
                onTime=' sR'
                _time=sum_offset(t0_time=sunrise_time,offset=offset)

            else:
                onTime=''
                _time=timerx["Time"]

            if italic:
                myTimers[f'T{i}.{output}']=f'{italicB}{_time} {ACTION} {DAYS}{onTime}{italicE}' # italic
            else:
                myTimers[f'T{i}.{output}']=f'{_time} {ACTION} {DAYS}{onTime}'
    else:
        myTimers='Disabled'

    return myTimers




####################################################################################################
# Timer1 {"Enable":1,"Time":"02:23","Window":0,"Days":"--TW--S","Repeat":1,"Output":1,"Action":1}
# setTimer number HH:MM   days   output   repeat action
# setTimer   1    12:30 -1--1-1     1       1      on
# ref: https://tasmota.github.io/docs/Timers/#json-payload-anatomy
# Ovviamente i controlli non sono esaustivi ma solo uno sgrosso
####################################################################################################
def humanToTimers(data: str, nRelays: int) -> dict:
    ret=SimpleNamespace()

    token=data.split()

    if len(token)==2:
        timer_num, ena_disa=token
        if int(timer_num) not in range(1,16+1):
            ret.err_msg="invalid timer number"
            return ret

        elif ena_disa not in ['enable', 'disable']:
            ret.err_msg=f"invalid {ena_disa} keyword"
            return ret

        ret.timer={
            f"Timer{timer_num}": {
                "Enable": 1 if ena_disa=='enable' else 0
            }
        }

        ret.err_msg=None



    elif len(token)==6:
        timer_num, hhmm, days, output, repeat, action=token
        if int(timer_num) not in range(1,16+1):
            ret.err_msg="invalid timer number"
            return ret

        elif not ':' in hhmm:
            ret.err_msg="invalid time value"
            return ret

        elif len(days)!=7:
            ret.err_msg="invalid days value"
            return ret

        elif int(output) not in range(1,16+1):
            ret.err_msg="invalid output relay"
            return ret

        elif int(repeat) not in range(0,1+1):
            ret.err_msg="invalid repeat value"
            return ret

        elif action.lower() not in ["on", "off", "toggle"]:
            ret.err_msg="invalid action value"
            return ret

        else:
            ret.timer={
                f"Timer{timer_num}": {
                    "Enable": 1,
                    "Mode": 0, # clock
                    "Time": hhmm,
                    "Window": 0,
                    "Days": days,
                    "Repeat": repeat,
                    "Output": output,
                    "Action": action,
                }
            }

            ret.err_msg=None
    else:
        ret.err_msg="invalid arguments number"
        return ret


    return ret


TIMERS= {
        "Timers": "ON",
        "Timer1": {
            "Enable": 1,
            "Mode": 0, # clock
            "Mode": 2, # sunset
            "Mode": 1, # sunrise
            "Time": "01:30",
            "Window": 0,
            "Days": "1111111",
            "Repeat": 1,
            "Output": 1,
            "Action": 0
        },
        "Timer2": {
            "Enable": 1,
            "Mode": 0, # clock
            "Mode": 1, # sunrise
            "Mode": 2, # sunset
            "Time": "01:30",
            "Window": 0,
            "Days": "1111111",
            "Repeat": 1,
            "Output": 2,
            "Action": 0
        },
    }



if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    from suntimes_LN import sunTime_casetta
    args=[2, '600']
    # ret=checkRelayNumber(arg=args[0], nRelays=1)
    ret=humanToPulseTime(args=[1, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[0, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[2, '600'], nRelays=1)
    print(ret)


    data=pulseTimeToHuman(value=1000)
    print(data)

    data=timersToHuman(data=TIMERS, outputRelay=1)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=2)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=0)
    print(data)

    # setTimer              number HH:MM   days   output   repeat action
    # setTimer                1    12:30 -1--1-1     1       1      on
    data=humanToTimers(data='1 12:15 -1--1-1 1 1 on', nRelays=1)
    print(data)

    data=humanToTimers(data='1 disable', nRelays=1)
    print(data)

    data=humanToTimers(data='1 enable', nRelays=1)
    print(data)

