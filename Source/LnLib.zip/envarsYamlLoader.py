#!/usr/bin/python
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 05-12-2022 16.54.11
#
# #############################################
__ln_version__="YamlLoader V2022-12-05_165411"

import  sys; sys.dont_write_bytecode=True
import  os
from types import SimpleNamespace
import json


from LoretoDict import LnDict

#####################################################
#  gv.mqttmonitor_runtime_dir
#  gv.envars_dir
#####################################################
def setup(gVars):
    global gv, logger
    gv=gVars
    logger                  = gv.logger
    envars_dir              = gv.envars_dir
    mqttmonitor_runtime_dir = gv.mqttmonitor_runtime_dir





##########################################################################
# keypath is string whith keys separated by dot
#       key1.key2.....keyn
# cast is the returned dictionary type (lortodict, OrderedDict, ...)
##########################################################################
def loadYamlFile(filename, keypath: str=None, cast: dict=dict):
    import yaml
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            content=f.read() # single string
    else:
        logger.caller('File: %s not found', filename)
        sys.exit(1)

    my_data=yaml.load(content, Loader=yaml.SafeLoader)

    if keypath:
        ptr=my_data
        keypath=keypath.split('.')
        for key in keypath:
            if key in ptr:
                ptr=ptr[key]
            else:
                logger.caller('key %s (from keypath: %s) not found', key, keypath)
                ptr=None
                break

        my_data=ptr

    if 'lndict' in str(cast).lower():  #  by Loreto:  18-11-2022 12.02.54
        return cast(my_data)
    else:
        return my_data


def mariaDB_data(keypath: str=None, cast: dict=dict):
    filename=f"${gv.envars_dir}/yaml/mariadb.yaml"
    data=loadYamlFile(filename=filename, keypath=keypath, cast=cast)
    return data





###############################################
# per i bot, partendo dal gruppo risaliamo al nome del bot associato
# return:
#  {
#     'group_name': 'LnBot_xxxx',
#     'chat_id': -111111,
#     'type': 'group',
#     'bot_name': 'LnBot',
#     'token': 'xxxx:yyyyyy'
#   }
###############################################
def retrieveBotData(group_name):
    myBots=telegramGroup_data(keypath="telegram", cast=LnDict)

    bot=myBots.first_key(pattern=group_name, cut=True, return_value=True, default=None)
    if bot:
        bot_name=bot["bot_name"]
        bot["token"]=myBots[f"bots.{bot_name}.token"]

    return bot


###############################################
#
###############################################
def telegramGroup_data(keypath: str=None, cast: dict=dict):
    filename=f"{gv.envars_dir}/yaml/telegramGroups_V1.1.yaml"
    data=loadYamlFile(filename=filename, keypath=keypath, cast=cast)
    return data




def mqttBroker(broker_name: str):
    filename=f"{gv.envars_dir}/yaml/Mqtt_Brokers.yaml"
    data=loadYamlFile(filename=filename, keypath=f"brokers.{broker_name}")
    return data






    #################################################
    # Load device json file
    # created by mqttmonitor.py
    #################################################
def mqttmonitorDevice(device_name: str, cast: dict=dict):
    filename=f'{gv.mqttmonitor_runtime_dir}/{device_name}.json'
    device={}
    if os.path.exists(filename) and os.stat(filename).st_size>0:
        with open(filename, 'r') as fin:
            device=json.load(fin)

    return device

