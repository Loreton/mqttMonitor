#!/usr/bin/python
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

import sys; sys.dont_write_bytecode=True
import time
import datetime


##########################################
#
##########################################
class nullLogger():
    def dummy(title, *args, **kwargs):
        # import yaml
        # if title: print(title)
        # if args: print(yaml.dump(args, indent=4))
        # if kwargs: print(yaml.dump(kwargs, indent=4) )
        pass
    critical=error=warning=info=debug=dummy



def test():
    import time
    token1='tele';token2='STATE'

    t = time.process_time()
    for j in range(1000000):
        [token1, token2]==['tele', 'STATE']
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    t = time.process_time()
    for j in range(1000000):
        token1=='tele' and token2=='STATE'
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    t = time.process_time()
    for j in range(1000000):
        token1 + token2=='tele' + 'STATE'
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    t = time.process_time()
    for j in range(1000000):
        f'{token1}.{token2}'=='tele.STATE'
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    sys.exit()



class TimerLN(object):
    """Timer to simplify timing of execution."""

    # logger arriva già con il pointer al livello es.. logger=logger.debug
    def __init__(self, name, default_time=0, start=False, logger=nullLogger()):
        self.logger=logger

        self.now=time.time() # seconds in epoch time
        self.name=name
        self.default_value=default_time

        self.stop()
        if start:
            self.start(seconds=default_time)
        self.log(text_message='init')

    def start(self, seconds=0):
        self.stop()
        self.now=time.time()
        self.timer_value=seconds if int(seconds)>0 else self.default_value
        self.start_time=time.time()
        self.log(text_message='started')

    def stop(self):
        self.timer_value=self.default_value
        self.start_time=0
        self.log(text_message='stopped')

    restart=start

    def is_running(self):
        self.now=time.time()
        elapsed=int(self.now-self.start_time)
        if elapsed > self.timer_value:
            self.log(text_message='exausted')
            return False
        else:
            self.log(text_message='running')
            return True



    def is_exausted(self, logger=None):
        running=self.is_running()
        return (not running)




    def log(self, *, text_message="", logger=None):
        mylogger=logger if logger else self.logger.trace
        mylogger("Timer name: %s - %s", self.name, text_message, stacklevel=3)
        elapsed=int(self.now-self.start_time)
        remaining=self.timer_value-elapsed
        mylogger("   elapsed/remaining: %s / %s", int(elapsed), int(remaining), stacklevel=3)







if __name__ == '__main__':
    # t1=Timer().start(5)
    # time.sleep(1)
    # t2=Timer().set(3)

    t1=Timer()
    t2=Timer()

    if myBot.mqtt_publish_timer.is_active():
        if myBot.mqtt_publish_timer.is_ended():
            saved_data=myBot.mqtt_publish_timer.stop()

    print()
    print("t1.is_running    ", t1.is_running())
    print("t2.is_running    ", t2.is_running())
    t1.start(5)
    time.sleep(1)
    t2.set(3)

    print()
    time.sleep(1)
    print("t1.elapsed_msec  ", t1.elapsed_msec())
    print("t2.elapsed_msec  ", t2.elapsed_msec())

    print()
    time.sleep(1)
    print("t1.elapsed_msec  ", t1.elapsed_msec())
    print("t2.elapsed_msec  ", t2.elapsed_msec())

    print("t2.stop          ", t2.stop())
    print()
    print("t1.is_running    ", t1.is_running())
    print("t2.is_running    ", t2.is_running())

    print()
    time.sleep(1)
    print("t1.is_running    ", t1.is_running())
    print("t1.elapsed_msec  ", t1.elapsed_msec())
    print("t2.elapsed_msec  ", t2.elapsed_msec())

    print()
    time.sleep(1)
    print("t1.is_running    ", t1.is_running())
    print("t1.elapsed_msec  ", t1.elapsed_msec())
    print("t2.elapsed_msec  ", t2.elapsed_msec())
