# -*- coding: utf-8 -*-

from benedict.dicts.base.base_dict import BaseDict

__all__ = ["BaseDict"]
