# -*- coding: utf-8 -*-

from benedict.dicts.io import io_util
from benedict.dicts.io.io_dict import IODict

__all__ = ["IODict", "io_util"]
