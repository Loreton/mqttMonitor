# -*- coding: utf-8 -*-

from benedict.dicts.keypath import keypath_util
from benedict.dicts.keypath.keypath_dict import KeypathDict

__all__ = ["KeypathDict", "keypath_util"]
