# -*- coding: utf-8 -*-

from benedict.dicts.parse import parse_util
from benedict.dicts.parse.parse_dict import ParseDict

__all__ = ["ParseDict", "parse_util"]
