# -*- coding: utf-8 -*-

from benedict.utils import type_util

__all__ = ["type_util"]
