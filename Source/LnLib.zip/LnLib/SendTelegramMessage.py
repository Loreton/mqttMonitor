#!/usr/bin/python
#
# updated by ...: Loreto Notarantonio
# Date .........: 22-11-2022 20.12.09
#

import  sys; sys.dont_write_bytecode = True
import  os
# import logging; logger=logging.getLogger(__name__)

import requests
import yaml, json
import socket; hostname=socket.gethostname()
if __name__ == '__main__':
    sys.path.insert(0, 'Source/LnLib')

from LnDict import LoretoDict


###############################################
# keypath is string whith keys separated by dot
#       key1.key2.....keyn
# cast is the returned dictionary type (lortodict, OrderedDict, ...)
###############################################
def loadYamlFile(filename, cast: dict=dict, keypath: str=None):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            content=f.read() # single string
    else:
        logger.error('File: %s not found', filename)
        sys.exit(1)

    my_data=yaml.load(content, Loader=yaml.SafeLoader)

    if keypath:
        ptr=my_data
        keypath=keypath.split('.')
        for key in keypath:
            ptr=ptr[key]

        my_data=ptr

    if 'loretodict' in str(cast).lower():  #  by Loreto:  18-11-2022 12.02.54
        return cast(my_data)
    else:
        return my_data




###############################################
# per i bot, partendo dal gruppo risaliamo al nome del bot associato
###############################################
def retrieveBotData(group_name):
    myBots=loadYamlFile(os.path.expandvars("${ln_ENVARS_DIR}/yaml/telegramGroups_V1.1.yaml"), cast=LoretoDict, keypath=f"telegram")
    bot=myBots.first_key(pattern=group_name, cut=True, return_value=True, default=None)

    if bot:
        bot_name=bot["bot_name"]
        bot["token"]=myBots["bots"][bot_name]["token"]

    return bot






######################################################################################
# ref:
######################################################################################
def formatMsg(d: dict, caller: bool=False, parse_mode: str=None, sort_keys=False, indent=4):
    xx=yaml.dump(d, indent=indent, sort_keys=sort_keys, default_flow_style=False)
    return xx

    if caller:
        if parse_mode=='HTML':
            data=f"<b>caller: {hostname}</b><br>"
        elif parse_mode=='MARKDOWN':
            data=f"**caller: {hostname}**\n"
        else:
            data=f"caller: {hostname}\n"
    else:
        caller=''


    return f"{caller}{xx}"




######################################################################################
# ref:
#       https://stackoverflow.com/questions/49327296/how-to-send-bold-text-using-telegram-python-bot
#       https://github.com/python-telegram-bot/python-telegram-bot/wiki/Code-snippets#message-formatting-bold-italic-code-
#       bot.send_message(chat_id=chat_id,
#                text="*bold* _italic_ `fixed width font` [link](http://google.com)\.",
#                parse_mode=telegram.constants.ParseMode.MARKDOWN_V2)
#
#       bot.send_message(chat_id=chat_id,
#                text='<b>bold</b> <i>italic</i> <a href="http://google.com">link</a>.',
#                parse_mode=telegram.constants.ParseMode.HTML)
######################################################################################
def sendMsg(group_name: str, message: dict, my_logger, parse_mode='MARKDOWN', caller=False):
    global logger
    logger=my_logger

    bot=retrieveBotData(group_name=group_name)
    bot_name=bot["bot_name"]
    token=bot["token"]
    chat_id=bot["chat_id"]

    # import pdb; pdb.set_trace(); pass # by Loreto
    if isinstance(message, dict):
        message=formatMsg(d=message, caller=caller)

    url = f"https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={message}"

    logger.warning('url:  %s',   url)
    if bot_name and token and chat_id:
        try:
            response = requests.get(url).json()
            logger.info('   response: %s',   response)
        except (Exception) as ex:
            logger.error('     exception:   %s',   str(ex))

    else:
        logger.error('command cannot be executed....missing some value!')
        _d=LoretoDict(bot)
        logger.error('bot data: %s',   _d.to_json())


if __name__ == '__main__':
    sys.path.insert(0, 'Source/LnLib')
    data=retrieveBotData('LnBot_Mqtt_Client')
    print(data)
