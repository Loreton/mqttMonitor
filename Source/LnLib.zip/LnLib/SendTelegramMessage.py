#!/usr/bin/python
#
# updated by ...: Loreto Notarantonio
# Date .........: 28-11-2022 17.36.37
#

import  sys; sys.dont_write_bytecode = True
import  os
# import logging; logger=logging.getLogger(__name__)

import requests
import yaml, json
import socket; hostname=socket.gethostname()
if __name__ == '__main__':
    sys.path.insert(0, 'Source/LnLib')

from LnDict import LoretoDict


###############################################
# keypath is string whith keys separated by dot
#       key1.key2.....keyn
# cast is the returned dictionary type (lortodict, OrderedDict, ...)
###############################################
def loadYamlFile(filename, cast: dict=dict, keypath: str=None):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            content=f.read() # single string
    else:
        logger.error('File: %s not found', filename)
        sys.exit(1)

    my_data=yaml.load(content, Loader=yaml.SafeLoader)

    if keypath:
        ptr=my_data
        keypath=keypath.split('.')
        for key in keypath:
            ptr=ptr[key]

        my_data=ptr

    if 'loretodict' in str(cast).lower():  #  by Loreto:  18-11-2022 12.02.54
        return cast(my_data)
    else:
        return my_data




###############################################
# per i bot, partendo dal gruppo risaliamo al nome del bot associato
###############################################
def retrieveBotData(group_name):
    myBots=loadYamlFile(os.path.expandvars("${ln_ENVARS_DIR}/yaml/telegramGroups_V1.1.yaml"), cast=LoretoDict, keypath=f"telegram")
    bot=myBots.first_key(pattern=group_name, cut=True, return_value=True, default=None)

    if bot:
        bot_name=bot["bot_name"]
        bot["token"]=myBots["bots"][bot_name]["token"]

    return bot


###########################################
# Bold:      Double * = **hello world**
# Italic:    Double _ = __hello world__
# Monospace: Triple ` = ```hello world```
# Strike through: Double ~ = ~~hello world~~;
###########################################
#    html_replacements_dict = {
#        '"': '&quot;',   # double quote &#34;
#        "'": '&apos;',   # single quote &#39;
#        # ":":   '&#58;',  # colon
#        # "-":   '&#45;',  # minus
#        # " ":   '&#32;',  # space
#        # "\n":   '&#13;', # carriage-return
#    }
#
#    # string=string.translate(str.maketrans(replacements_dict))
#    # print(string)
#    BS=ord('\\')
#    BS=chr(92)

def checkParseMode(*, message, parse_mode, caller):
    SQ="'"
    DQ='"'

    if parse_mode is None:
        parse_mode=''
        if caller:
            message=f"from: {hostname}\n{message}"

    elif parse_mode.lower()=='markdown':
        parse_mode='&parse_mode=MARKDOWN'
        if caller:
            message=f"from: *{hostname}:*\n{message}" # italic + bold non riesco

    elif parse_mode.lower()=='html':
        ### ref: https://core.telegram.org/bots/api#html-style
        parse_mode='&parse_mode=HTML'
        # message=message.replace(SQ, '&#39;') # NON funzionano
        # message=message.replace(DQ, '&#34;')
        message=message.replace(SQ, '')
        message=message.replace(DQ, '')

        if caller:
            # message=f"from: <b>{hostname}</b>\n{message}" # bold OK
            # message=f"from: <em>{hostname}</em>\n{message}" # italic OK
            # message=f"from: <b><i>{hostname}</i></b>\n{message}" # italic + bold
            message=f"from: <i><b>{hostname}</b></i>\n{message}" # italic + bold

    else:
        parse_mode=''
        if caller:
            message=f"from: {hostname}\n{message}"


    ### non l'ho ancora ben capito ma ci deve essere qualche problema con gli apici all'interno del messaggio ed il parse mode....
    if SQ in message or DQ in message:
        parse_mode=''

    return message, parse_mode





######################################################################################
# ref:
#       https://stackoverflow.com/questions/49327296/how-to-send-bold-text-using-telegram-python-bot
#       https://github.com/python-telegram-bot/python-telegram-bot/wiki/Code-snippets#message-formatting-bold-italic-code-
######################################################################################
def sendMsg(group_name: str, message: dict, my_logger, parse_mode: str=None, caller=False, notify=False):
    global logger
    logger=my_logger

    bot=retrieveBotData(group_name=group_name)
    if not bot:
        legger.error('Cannot retrieve BOT data for group_name: %s', group_name)
        return

    bot_name=bot["bot_name"]
    token=bot["token"]
    chat_id=bot["chat_id"]


    if isinstance(message, dict):
        message=yaml.dump(message, indent=4, sort_keys=False, default_flow_style=False)

    notification=f"&disable_notification={not notify}"
    # notification=""

    message, parse_mode=checkParseMode(parse_mode=parse_mode, message=message, caller=caller)




    url=f"https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={message}{parse_mode}{notification}"

    logger.notify('url:  %s',   url)

    if bot_name and token and chat_id:
        try:
            response=requests.get(url).json()
            ### response: {'ok': False, 'error_code': 400, 'description': "Bad Request: can't parse entities: Can't find end of the entity starting at byte offset 493"}
            ### esponse: {'ok': True, 'result': {'messag....
            if response['ok']:
                logger.info('   response: %s',   response)
            else:
                logger.error('   response: %s',   response)

        except (Exception) as ex:
            logger.error('     exception:   %s',   str(ex))





    else:
        logger.error('command cannot be executed....missing some value!')
        _d=LoretoDict(bot)
        logger.error('bot data: %s',   _d.to_json())


if __name__ == '__main__':
    sys.path.insert(0, 'Source/LnLib')
    data=retrieveBotData('LnBot_Mqtt_Client')
    print(data)
