#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 09-01-2023 11.49.13
#
import  sys; sys.dont_write_bytecode = True
import os
import json, yaml
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timedelta
from benedict import benedict
from benedict.utils import type_util
import time

if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Utils')

from LnSunTime import sunTime_casetta
from LnTime import seconds_diff_datetime
from LnUtils import is_integer_in_range
import Tasmota_Human_Converter as THC


##########################################
#
##########################################
class nullLogger():
    def dummy(title, *args, **kwargs):
        pass
    critical=trace=error=notify=function=warning=info=debug=caller=dummy




class TasmotaClass:
    def __init__(self, device_name: str, runtime_dir: str, logger):
        self.logger = logger
        self.device_name = device_name

        self.device_file_json=f"{runtime_dir}/{self.device_name}.json"
        self.device_file_yaml=f"{runtime_dir}/{self.device_name}.yaml"


        ### lettura file oppure default dict
        loreto_data=self.loadDeviceFile()

        ### convert to benedict
        self.full_device=benedict(loreto_data)

        ### add deviceDB
        self.full_device[self.device_name]={}

        ### create fast pointers
        self.loretoDB=self.full_device['Loreto']
        self.deviceDB=self.full_device[device_name]
        if not 'STATE' in self.loretoDB: self.loretoDB['STATE']={}
        if not 'STATE' in self.deviceDB: self.deviceDB['STATE']={}

        self.set_relays(self.loretoDB['relays'])

        self.telegramNotification(seconds=.1)
        self.timerForSavingData(seconds=0.1)



    ###################################################################
    # Carichiamo solo i dati sommari sotto la key: Loreto
    ###################################################################
    def loadDeviceFile(self, filename: str=None):
        if not filename:
            filename=self.device_file_json

        base_device=f"""
            Loreto:
                file_out: {filename}
                last_update: "2011-12-13T01:02:03"
                device_name: {self.device_name}
                topic_name:  {self.device_name}
                modello: ""
                firmware: ""
                STATE:
                    Time: "2022-12-16T11:40:27"
                    Uptime: N/A
                    UptimeSec: 0
                    Heap: 25
                    SleepMode: Dynamic
                    Sleep: 50
                    LoadAvg: 19
                    MqttCount: 3
                    POWER1: N/A
                    Wifi:
                        AP: 1
                        SSId: N/A
                        BSSId: N/A
                        Channel: 10
                        Mode: N/A
                        RSSI: 1
                        Signal: -1
                        LinkCount: 2
                        Downtime: N/A

                NET:
                    IPAddress: N/A
                    Gateway: N/A
                    Subnetmask: N/A
                    DNSServer1: N/A
                    DNSServer2: N/A
                    Mac: N/A

                relays:         [1, 0, 0, 0, 0, 0, 0, 0 ]
                friendly_names:  ["Relay_01", "Relay_02", "Relay_03", "Relay_04", "Relay_05", "Relay_06", "Relay_07", "Relay_08"]
                PulseTime:
                    "Set":       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
                    "Remaining": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
        """
                # Wifi: {dict()}

        device=None
        if os.path.exists(filename) and os.stat(filename).st_size>0:
            with open(filename, 'r') as fin:
                device=json.load(fin)
                if not 'Loreto' in device:
                    device=None

        if not device:
            device=yaml.load(base_device, Loader=yaml.SafeLoader)

        return device



    ##################################################################
    ##################################################################
    #    U P D A T E    functions
    ##################################################################
    ##################################################################




    ################################################
    ### add/update payload to device
    ### crea entry con la key richiesta
    ################################################
    def updateDevice(self, key_path: str, data: dict, writeFile=False):
        self.logger.notify("updating device: %s", dict)

        if not isinstance(data, dict):
            self.logger.warning("data is not dictionary: %s", data)
            return

        if not key_path:
            keys=list(data.keys())

            ### aggiungiamola a LoretoDB
            if len(keys)==1:
                single_key='SingleKey'

                if 'POWER' in single_key:
                    self.updateLoreto_POWER(data=data)

                else:
                    if single_key not in self.loretoDB:
                        self.loretoDB[single_key]=benedict()

                    self.loretoDB[single_key].update(data)

            elif 'Time' in data and 'Wifi' in data:
                key_path='STATE' ### è uno state che arriva solo al momento della connect al broker

            else:
                self.logger.caller('should not occurs', stacklevel=1)
                self.logger.caller('payload: %s', data.to_yaml())
                import pdb; pdb.set_trace(); pass # by Loreto
                return



        if key_path:
            if key_path not in self.deviceDB:
                self.deviceDB[key_path]=benedict()

            self.deviceDB[key_path].update(data)


        ### aggiorniamo anche il loretoDB  lo STATE visto che

        if key_path=='STATE':
            self.logger.notify("updating STATE: %s", data)
            self.loretoDB['STATE'].update(data)
            self.loretoDB['last_update']=data['Time']


        elif 'StatusSTS' in data: ### StatusSTS==STATE
            self.logger.notify("updating StatusSTS: %s", data)
            statusSTS=data['StatusSTS']
            self.loretoDB['STATE'].update(statusSTS)
            self.deviceDB['STATE'].update(statusSTS)
            self.loretoDB['last_update']=statusSTS['Time']

        elif 'StatusNET' in data:
            self.logger.notify("updating StatusNET: %s", data)
            net=data['StatusNET']
            self.loretoDB["NET"].update(data['StatusNET'])


        elif key_path=='Config':
            self.updateLoreto_Config(data=data)

        self.savingDataOnFile(forceWrite=True)



    ################################################################
    #
    ################################################################
    def updateLoreto_POWER(self, data: dict):
        self.logger.notify("updating Loreto_power: %s", data)
        for relay in range(self.relays):
            key=f'POWER{relay+1}'
            if key in data:
                self.loretoDB['STATE'][key]=data[key]



    ################################################################
    # {"PulseTime1":{"Set":0,"Remaining":0}}
    # {"PulseTime":{"Set":[111,0,0,0,0...],"Remaining":[0,0,0...]
    ################################################################
    def updateLoreto_PulseTime(self, key_name: str, data: dict):

        loreto_set=self.loretoDB['PulseTime.Set']
        loreto_remaining=self.loretoDB['PulseTime.Remaining']

        ### copiamo solo i pulsetime relativi al numero di relays
        if key_name=='PulseTime':
            self.loretoDB['PulseTime.Set']=data['PulseTime.Set'][:self.relays]
            self.loretoDB['PulseTime.Remaining']=data['PulseTime.Remaining'][:self.relays]

        ### modifichiamo il singolo Set[x]
        else:
            relay_nr=int(key_name[-1])-1
            if relay_nr in range(self.relays):
                loreto_set[relay_nr]       = data[key_name]['Set']
                loreto_remaining[relay_nr] = data[key_name]['Remaining']



    ################################################################
    #
    ################################################################
    def updateLoreto_SSID(self, data: dict):
        self.loretoDB['SSID']=data



    ################################################################
    #
    ################################################################
    def updateLoreto_Config(self, data: dict):
        if 'sn' in data:
            pass
        else:
            _dict=self.loretoDB
            _dict['relays']           = [x for x in data['rl'] if x == 1]
            _dict['friendly_names']   = [x for x in data['fn'] if (x != '' and x != None)]
            _dict['device_name']      = data['dn']
            _dict['topic_name']       = data['t']
            _dict['modello']          = data['md']
            _dict['firmware']         = data['sw']


            _dict['NET.IPAddress']        = data['ip']
            _dict['NET.Mac']              = data['mac'] # formato senza punti ... da modificare



    ################################################################
    # Blocca le notifiche verso telegram
    # Utile quando si inviano diversi comandi al device
    ################################################################
    def telegramNotification(self, seconds: float=0) -> bool:
        if seconds:
            self.telegram_notification=time.time() + seconds

        remaining=self.telegram_notification-time.time()
        self.logger.info("telegramNotification ramaining secs: %s", remaining)
        return ( remaining <= 0)



    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def timerForSavingData(self, seconds: float=0) -> bool:
        if seconds:
            self.save_file_timer=time.time() + seconds
        remaining=time.time()-self.save_file_timer
        self.logger.notify('timerForSavingData remaining: %s', remaining)
        return ( remaining > 0)


    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def savingDataOnFile(self, forceWrite=False):
        if self.timerForSavingData() or forceWrite:
            self.logger.notify('updating file: %s', self.device_file_json)
            self.full_device.to_json(filepath=self.device_file_json, indent=4, sort_keys=False)
            self.full_device.to_yaml(filepath=self.device_file_yaml, indent=4, sort_keys=False)
            self.timerForSavingData(seconds=60) ### reload timer
        else:
            self.logger.notify("file %s will not be saved due to timerForSavingData still active.", self.device_file_json)


    ################################################################
    #
    ################################################################
    def set_relays(self, data: list):
        self.loretoDB['relays']=[x for x in data if x == 1]





    ##################################################################
    ##################################################################
    #    R E T R I E V E    functions
    ##################################################################
    ##################################################################






    def getDeviceDB(self, keypath: str=None) -> dict:
        return self.deviceDB.get(keypath)



    @property
    def relays(self) -> int:
        try:
            return len(self.loretoDB['relays'])
        except (Exception) as exc:
            self.logger.caller('%s - %s', self.device_name, exc)

    # @property
    def friendlyNames(self, relay_nr: int=0):
        fn=[]
        for index in range(self.relays):
            fn.append(self.loretoDB['friendly_names'][index])

        if relay_nr in range(1, self.relays+1):
            return fn[relay_nr]
        return fn



    ################################################################
    #
    ################################################################
    def relayStatus(self, relay_nr: int):
        if relay_nr in range(1, self.relays+1):
            status=self.full_device[f'Loreto.STATE.POWER{relay_nr}']
            if status:
                return status
            else:
                self.logger.error('%s - relay_nr: %s/%s', self.device_name, relay_nr, self.relays)
        else:
            return 'N/A'




    ####################################################################
    ### info varie
    ####################################################################
    def deviceName(self):
        return self.device_name





    ####################################################################
    ### info varie
    ####################################################################
    def Info(self):
        data=self.loretoDB

        d=dict()

        if 'T' in data['last_update']:

            dt_last_update=datetime.strptime(data['last_update'], "%Y-%m-%dT%H:%M:%S")
            dt_now=datetime.now()
            diff_time=seconds_diff_datetime(dt_now, dt_last_update) ### dt1-dt2

            if diff_time > 60:
                d['Last Update OLD']= {
                            "date": "<b>" + dt_last_update.strftime("%d-%m-%Y") + "</b>",
                            "time": "<b>" + dt_last_update.strftime("%H-%M-%S") + "</b>",
                            }
            else:
                d['Last Update']= {
                            "date": dt_last_update.strftime("%d-%m-%Y"),
                            "time": dt_last_update.strftime("%H-%M-%S"),
                            }

            d['firmware'] = data["firmware"]
            d['modello']  = data["modello"]

            # timeit.timeit('var1 + var2 + var3', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)
            # timeit.timeit('f"{var1}{var2}{var3}"', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)

        return d


    ####################################################################
    ### preparazione stato networking
    ### {"IPAddress1":"0.0.0.0 (192.168.1.103)","IPAddress2":"192.168.1.1","IPAddress3":"255.255.255.0","IPAddress4":"192.168.1.9","IPAddress5":"1.1.1.1"}
    ####################################################################
    def net_status(self, payload: dict={}):

        _dict={}

        if payload:
            ip=payload['IPAddress1']
            ip=ip.split('(')[1]
            ip=ip.split(')')[0]
            _dict={
                "IPAddress": ip,
                "Gateway":   payload["IPAddress2"],
                "SubMask":   payload["IPAddress3"],
                "DNS1":      payload["IPAddress4"],
                "DNS2":      payload["IPAddress5"],
                }


        else:
            data=self.loretoDB['NET']
            if data:
                keys=[ "IPAddress",
                        "Gateway",
                        "Subnetmask",
                        "DNSServer1",
                        "DNSServer2",
                        "Mac",
                    ]

                _dict={}
                for key in keys:
                    value=self.loretoDB['NET'][key]
                    _dict[key]=value

        return _dict



    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def wifi(self):
        data=self.loretoDB['STATE.Wifi']

        wifi={}
        keys=[  "AP",
                "SSId",
                "BSSId",
                "Channel",
                "Mode",
                "RSSI",
                "Signal",
                ]

        for key in keys:
            value=self.loretoDB['STATE.Wifi'][key]
            wifi[key]=value


        return wifi




    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def mqtt(self):


        _dict={}

        data=self.deviceDB.get('STATUS.StatusMQT')
        if data:
            for k,v in data.items():
                _dict[k]={v}

            _dict={"MQTT": _dict }

        return _dict


    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def firmware(self):

        _dict={}

        data=self.deviceDB.get('STATUS.StatusFWR')

        if data:
            for k,v in data.items():
                _dict[k]=v

            _dict={"Firmware": _dict }

        return _dict

    ####################################################################
    ### preparazione stato PulseTime
    ####################################################################
       #----------------------------------------------
    def pulseTimeToHuman(self, relay_nr: int):
        # return THC.pulseTimeToHuman(dev_data=self.loretoDB['PulseTime'], relay_nr=relay_nr, milliseconds=milliseconds, strip_leading=strip_leading)
        return THC.pulseTimeToHuman(dev_data=self.loretoDB['PulseTime'], relay_nr=relay_nr, strip_leading=True)


    ####################################################################
    ### preparazione staato timers
    ####################################################################
       #----------------------------------------------
    def timersToHuman(self, relay_nr: int):
        return THC.timersToHuman(dev_data=self.deviceDB.get('TIMERS'), relay_nr=relay_nr)







if __name__ == '__main__':
    device=TasmotaClass(device_name='topic_name', runtime_dir='/tmp', logger=nullLogger())
    # sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    # from suntimes_LN import sunTime_casetta
    args=[2, '600']
    # ret=checkRelayNumber(arg=args[0], nRelays=1)
    # ret=humanToPulseTime(args=[1, '600'], nRelays=1)
    # print(ret)

    # ret=humanToPulseTime(args=[0, '600'], nRelays=1)
    # print(ret)

    # ret=humanToPulseTime(args=[2, '600'], nRelays=1)
    # print(ret)


    # data=pulseTimeToHuman(value=1000)
    # print(data)

    # data=timersToHuman(data=TIMERS, outputRelay=1)
    # print(data)
    # data=timersToHuman(data=TIMERS, outputRelay=2)
    # print(data)
    # data=timersToHuman(data=TIMERS, outputRelay=0)
    # print(data)

    # setTimer               number HH:MM   days   output   repeat action
    # setTimer                 1    12:30  -1--1-1     1       r|n      on
    data=sys.argv[1]
    # data=device.setTimer(data='1 ena 21:15 -1--1-1     5       r        on', nRelays=1)
    data=device.setTimer(data=data, nRelays=1)
    print(data)

    # data=device.setTimer(data='1 ena', nRelays=1)
    # print(data)

    # data=device.setTimer(data='1 dis', nRelays=1)
    # print(data)
