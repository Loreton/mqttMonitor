#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 05-12-2022 17.07.45
#
import  sys; sys.dont_write_bytecode = True
import os
import json, yaml
from pathlib import Path
from types import SimpleNamespace

from datetime import timedelta
import time
# from LnLib.TimeLN import millisecs_to_HMS_ms
from LnSunTime import sunTime_casetta
from LoretoDict import LnDict


class TasmotaClass:
    def __init__(self, device_name: str, runtime_dir: str, logger):
        self.logger = logger
        self.device_name = device_name

        self.device_file_json=f"{runtime_dir}/{self.device_name}.json"
        self.device_file_yaml=f"{runtime_dir}/{self.device_name}.yaml"


        self.full_device=self.loadDeviceFile()
        if not self.device_name in self.full_device:
            self.full_device[self.device_name]=dict() # initialize

        self.device=self.full_device[self.device_name]
        self.loreto=self.full_device['Loreto']


        # self.loreto['notification_timer']=time.time() # azzeriamo il timer
        # self.loreto['save_file_timer']=time.time() # azzeriamo  il timer
        self.relaysNumber(self.loreto['relays'])
        self.friendlyNames(self.loreto['friendly_names'])

        self.telegramNotification(seconds=.1)
        self.saveFileTimer(seconds=0.1)



    '''
    def toJsonFile(self, filename, replace=False):
        d=self.full_device
        json_data=json.dumps(d, indent=4, sort_keys=False, separators=(',', ': '), default=str)
        return self.writeTextFile(data=json_data, file_out=filename, replace=replace)



    ######################################################
    # -
    ######################################################
    def writeTextFile(self, *, data, file_out: (str, os.PathLike) , replace=False):
        self.logger.debug('writing file: %s', file_out)
        fileError=True
        file_out=Path(file_out)

        if file_out.exists() and replace is False:
            fWRITE=False
        else:
            fWRITE=True

        if isinstance(data, list):
            data='\n'.join(data)

        if fWRITE:
            os.makedirs(file_out.parent,  exist_ok=True)
            with open(file_out, "w") as f:
                f.write(f'{data}\n')
            fileError=False
        else:
            self.logger.warning('ERROR: file %s already exists.', file_out )

        return fileError
    '''


    ###################################################################
    #
    ###################################################################
    def loadDeviceFile(self, filename: str=None, ):
        if not filename:
            filename=self.device_file_json

        base_device=f"""
            Loreto:
                file_out: {filename}
                last_update: "2011-12-13T01:02:03"
                device_name: {self.device_name}
                topic_name:  {self.device_name}
                modello: ""
                firmware: ""
                mac1: ""
                POWER1: N/A
                POWER2: N/A
                Mac: N/A
                IPAddress: N/A
                Gateway: N/A
                Wifi: {dict()}
                relays:         [1, 0, 0, 0, 0, 0, 0, 0 ]
                friendly_names:  ["Relay1", "Relay2", "Relay3", "Relay4", "Relay5", "Relay6", "Relay7", "Relay8"]
                PulseTime:
                    "Set":       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
                    "Remaining": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
        """

        if os.path.exists(filename) and os.stat(filename).st_size>0:
            with open(filename, 'r') as fin:
                device=json.load(fin)
        else:
            device=yaml.load(base_device, Loader=yaml.SafeLoader)


        return device


    ################################################
    ### add/update payload to device
    ### crea una entry con il suffix
    ################################################
    def updateGeneric(self, suffix: str, data: dict, writeFile=False):
        _ptr=self.device

        if suffix in _ptr and isinstance(data, dict) and isinstance(_ptr[suffix], dict):
            try:
                _ptr[suffix].update(data)
            except (AttributeError) as exc:
                print(str(exc))
                print("topic:        ",  topic)
                print("data:         "  ,  data)
                print("suffix:       ",  suffix)
                print("device[suffix]:", _ptr[suffix])
                os.kill(int(os.getpid()), signal.SIGTERM)
        else:
            _ptr[suffix]=data


        if self.saveFileTimer():
            self.logger.notify('updating file: %s', self.device_file_json)
            dummyLnDict=LnDict()

            dummyLnDict.toJsonFile(d=self.full_device, filename=self.device_file_json, indent=4, sort_keys=False, replace=True)
            dummyLnDict.toYamlFile(d=self.full_device, filename=self.device_file_yaml, indent=4, sort_keys=False, replace=True)
            self.saveFileTimer(seconds=120)



    ################################################################
    #
    ################################################################
    def updateSTATUS5(self, data: dict):
        # _ptr=self.device['STATUS5']['StatusNET']
        _ptr=data['StatusNET']
        self.loreto['IPAddress']  = _ptr['IPAddress']
        self.loreto['Mac']        = _ptr['Mac']
        self.loreto['Gateway']    = _ptr['Gateway']
        self.loreto['DNSServer1'] = _ptr['DNSServer1']
        self.loreto['DNSServer2'] = _ptr['DNSServer2']


    ################################################################
    #
    ################################################################
    def updateSTATUS10(self, data: dict):
        # _ptr=self.device['STATUS10']['StatusSNS']
        _ptr=data['StatusSNS']
        self.loreto['last_update']=_ptr['Time']


    ################################################################
    #
    ################################################################
    def updateSTATUS11(self, data: dict):
        # _ptr=self.device['STATUS11']['StatusSTS']
        _ptr=data['StatusSTS']
        self.loreto['last_update']=_ptr['Time']
        self.loreto['Wifi']=_ptr['Wifi']
        self.updatePOWER(_ptr)






    ################################################################
    #
    ################################################################
    def updatePOWER(self, data: dict):
        for rl in range(1, self.relaysNumber()+1):
            key=f'POWER{rl}'
            if key in data:
                self.loreto[key]=data[key]
                fn=self.friendlyNames()[rl-1]
                self.loreto[fn]=data[key]


    ################################################################
    #
    ################################################################
    def updatePulseTime(self, data: dict):
        # self.loreto['PulseTime'].update(data['PulseTime'])
        n_relays=self.relaysNumber()
        self.loreto['PulseTime']['Set']=(data['PulseTime']['Set'][:n_relays])
        self.loreto['PulseTime']['Remaining']=(data['PulseTime']['Remaining'][:n_relays])

        # _set=data['PulseTime']['Set']
        # fn=friendlyNames()

        # _set=[x for x in data if x == 1]
        # for relay in range(self.relaysNumber()):
        #     self.loreto['PulseTime']['Remaining'][relay]=(data['PulseTime']['Remaining'][relay])

    ################################################################
    #
    ################################################################
    def updateSSID(self, data: dict):
        self.loreto['SSID']=data

    ################################################################
    #
    ################################################################
    def updateSensorsSN(self, data: dict):
        _ptr=data['sn']
        self.loreto['last_update']=_ptr['Time']

    ################################################################
    #
    ################################################################
    def updateSensorsRL(self, data: dict):
        self.relaysNumber(data['rl'])
        self.friendlyNames(data['fn'])

        self.loreto['ip_address']       = data['ip']
        self.loreto['device_name']      = data['dn']
        self.loreto['topic_name']       = data['t']
        self.loreto['modello']          = data['md']
        self.loreto['firmware']         = data['sw']
        self.loreto['mac1']             = data['mac'] # formato senza punti ... da modificare


    ################################################################
    #
    ################################################################
    def updateSTATE(self, data: dict):
        self.loreto['last_update']=data['Time']
        self.loreto['Wifi']=data['Wifi']
        self.updatePOWER(data)



    ################################################################
    #
    ################################################################
    def updateTIMERS(self, data: dict):
        if not 'RESULT' in self.device:
            self.device['RESULT']={}

        self.device['RESULT'].update(data)




    ################################################################
    # Blocca le notifiche verso telegram
    # Utile quando si inviano diversi comandi al device
    ################################################################
    def telegramNotification(self, seconds: float=0) -> list:
        if seconds:
            self.telegram_notification=time.time() + seconds

        return ( time.time()-self.telegram_notification > 0)



    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def saveFileTimer(self, seconds: float=0) -> list:
        if seconds:
            self.save_file_timer=time.time() + seconds

        return ( time.time()-self.save_file_timer > 0)


    ################################################################
    #
    ################################################################
    def friendlyNames(self, data: list=[]) -> list:
        if data:
            fn=[x for x in data if (x != '' and x != None)]
            self.loreto['friendly_names']=fn

        return self.loreto['friendly_names']


    ################################################################
    #
    ################################################################
    def relaysNumber(self, data: list=[]):
        if data:
            self.loreto['relays']=[x for x in data if x == 1]

        return len(self.loreto['relays'])



    ################################################################
    #
    ################################################################
    def relayStatus(self, relay_nr: int, italic=False):
        italicB='<i>' if italic else ''
        italicE='</i>' if italic else ''

        if relay_nr in range(1, self.relaysNumber()+1):
            return italicB + self.loreto[f'POWER{relay_nr}'] + italicE
        else:
            return 'N/A'











    ####################################################################
    ### info varie
    ####################################################################
    def deviceName(self, italic=False):
        italicB='<i>' if italic else ''
        italicE='</i>' if italic else ''

        return italicB + self.device_name + italicE




    ####################################################################
    ### info varie
    ####################################################################
    def Info(self, italic=False):
        data=self.loreto
        italicB='<i>' if italic else ''
        italicE='</i>' if italic else ''

        d=dict()
        if 'T' in data['last_update']:
            _date, _time=data['last_update'].split('T')

            d['device_name'] = italicB + data['device_name'] + italicE
            d['Last Update']= {
                        "date": italicB + _date + italicE,
                        "time": italicB + _time + italicE
                        }
            d['firmware'] = italicB + data['firmware'] + italicE
            d['modello'] = italicB + data['modello']  + italicE


        return d






    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def wifi(self, italic=False):
        data=self.loreto['Wifi']
        italicB='<i>' if italic else ''
        italicE='</i>' if italic else ''

        wifi={}
        if data:
            wifi["SSId"]      = f"{italicB}{data['SSId']}{italicE}"
            wifi["BSSId"]     = f"{italicB}{data['BSSId']}{italicE}"
            wifi["RSSI"]      = f"{italicB}{data['RSSI']}{italicE}"
            wifi["Signal"]    = f"{italicB}{data['Signal']}{italicE}"

            wifi["Mac"]       = f"{italicB}{self.loreto['Mac']}{italicE}"
            wifi["IPAddress"] = f"{italicB}{self.loreto['IPAddress']}{italicE}"


        return wifi




    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def mqtt(self, italic=False):
        italicB='<i>' if italic else ''
        italicE='</i>' if italic else ''

        _dict={}
        data=None

        if 'STATUS6' in self.device:
            data=self.device["STATUS6"]
            if 'StatusMQT' in data:
                data=data["StatusMQT"]

        if data:
            _dict={"MQTT": {
                                'Host': f"{italicB}{data['MqttHost']}{italicE}",
                                'Port': f"{italicB}{data['MqttPort']}{italicE}",
                                'User': f"{italicB}{data['MqttUser']}{italicE}",
                                'Client': f"{italicB}{data['MqttClient']}{italicE}",
                            }
                    }

        return _dict

    ####################################################################
    ### preparazione stato PulseTime
    ####################################################################
       #----------------------------------------------
    def pulseTimeToHuman(self, relay_nr: int, italic=False) -> int:
        #-----------------------------------------------
        def millisecs_to_HMS_ms(milliseconds, strip_leading=False):
            s, ms = divmod(milliseconds, 1000)
            m, s = divmod(s, 60)
            h, m = divmod(m, 60)

            hours=int(h)
            minutes=int(m)
            seconds=int(s)
            milliseconds=int(ms)

            ret_val=f'{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:01}'
            if strip_leading:
                if h==0 and minutes==0:
                    ret_val=f'{seconds:02}.{milliseconds:01}'
                elif h==0:
                    ret_val=f'{minutes:02}:{seconds:02}.{milliseconds:01}'

            return ret_val
        #-----------------------------------------------

        def pulsetime_to_ms(value):
            if value<=111:
                seconds=int(value/10)
                milliseconds=(value/10)*1000
            else:
                seconds=int(value-100)
                milliseconds=(value-100)*1000
            return milliseconds

        #-----------------------------------------------

        italicB='<i>' if italic else ''
        italicE='</i>' if italic else ''
        pulsetime_set="?"
        pulsetime_remaining="?"

        if 'PulseTime' in self.loreto:
            ptr=self.loreto["PulseTime"]
            if 'Set' in ptr:
                SET=self.loreto["PulseTime"]["Set"]
                _ms=pulsetime_to_ms(SET[relay_nr])
                pulsetime_value=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)

                REMAINING=self.loreto["PulseTime"]["Remaining"]
                _ms=pulsetime_to_ms(REMAINING[relay_nr])
                pulsetime_remaining=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)

                '''
                SET=self.loreto[f'PulseTime.Set']
                _ms=pulsetime_to_ms(SET[relay_nr])
                pulsetime_value=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)

                REMAINING=self.loreto[f'PulseTime.Remaining']
                _ms=pulsetime_to_ms(REMAINING[relay_nr])
                pulsetime_remaining=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)
                '''


        return italicB + pulsetime_value + italicE, italicB + pulsetime_remaining + italicE





    ####################################################################
    #
    # {"PulseTime":{"Set":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"Remaining":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}}
    #
    #   PulseTime<x>:   Display the amount of PulseTime remaining on the corresponding Relay<x>
    #           0 / OFF = disable use of PulseTime for Relay<x>
    #           1..111 = set PulseTime for Relay<x> in 0.1 second increments
    #           112..64900 = set PulseTime for Relay<x>, offset by 100, in 1 second increments.
    #           Add 100 to desired interval in seconds, e.g.,
    #           PulseTime 113 = 13 seconds and PulseTime 460 = 6 minutes (i.e., 360 seconds)
    #           <value> Set the duration to keep Relay<x> ON when Power<x> ON command is issued.
    #           After this amount of time, the power will be turned OFF.
    #
    ####################################################################
    def humanToPulseTime(self, args: list, nRelays: int) -> SimpleNamespace:
        """ setPulseTime <relay> <seconds>  -->  pulsetime<relay> <pt_units>
            setPulseTime <relay> <MM:SS>    -->  pulsetime<relay> <pt_units>
        """
        #-------------------------------------------------
        def secondsToPulseTime(seconds: float) -> int:
            seconds=float(seconds)
            if seconds<=11.1:
                pulsetime_value=seconds*10
            else:
                pulsetime_value=float(seconds)+100

            return float(pulsetime_value)
        #-------------------------------------------------


        msg=None
        if len(args)>1:
            ret=checkRelayNumber(arg=args[0], nRelays=nRelays)
            if ret.err_msg:
                return ret
            else:
                relay=ret.relay

            if isinstance(args[1], (int, float)):
                value=secondsToPulseTime(seconds=args[1])

            else:
                try: ### if passed as seconds
                    value=secondsToPulseTime(seconds=float(args[1]))

                except (ValueError):
                    try:
                        mm, ss=args[1].split(':')
                    except (Exception) as exc:
                        msg=f"ERROR evaluating seconds value '{args[1]}')"
                        value=-1

                    pt.value=secondsToPulseTime(seconds=float(mm)*60+float(ss))

        else:
            pt.msg='missing args...'


        pt=SimpleNamespace()
        pt.value=value
        pt.msg=msg
        pt.relay=relay
        return pt





    ####################################################################
    # "RESULT": {
    #         "Timers": "ON",
    #         "Timer1": {
    #             "Enable": 1,
    #             "Mode": 0,
    #             "Time": "01:00",
    #             "Window": 0,
    #             "Days": "1111111",
    #             "Repeat": 1,
    #             "Output": 1,
    #             "Action": 0
    #         },
    #
    # voglamo tradurlo in:
    #    Timers:
    #       T1.x: 17:21 on LMMGVSD sS   x rappresenta il relay di output
    #       T2.x: 22:30 off LMMGVSD   x rappresenta il relay di output
    ####################################################################
    def timersToHuman(self, relay_nr: int=0, italic=False) -> dict:
        # -----------------------------------
        def _convertWeekDays(val):
            _it_days='DLMMGVS' # tasmota days start from Sunday
            _en_days='SMTWTFS' # tasmota days start from Sunday
            _data=''
            for i in range(0, 7):
                _data+=_en_days[i] if val[i]=='1' else '_ '
            return _data[1:] + _data[0] # lets start from Monday



        # -----------------------------------
        def sum_offset(t0_time, offset):
            offset_HH, offset_MM=offset.split(':')
            offset_minutes=abs(int(offset_HH))*60+int(offset_MM)
            if offset_minutes==0:
                return t0_time

            t0_HH, t0_MM=t0_time.split(':')
            t0=timedelta(hours=int(t0_HH), minutes=int(t0_MM))
            ofs=timedelta(hours=int(offset_HH), minutes=int(offset_MM))

            if offset[0]=='-':
                new_time=t0-ofs
            else:
                new_time=t0+ofs

            return time.strftime("%H:%M", time.gmtime(new_time.total_seconds()))

        # -----------------------------------

        italicB='<i>' if italic else ''
        italicE='</i>' if italic else ''





        if relay_nr<1:
            relay_nr=list(range(1,16+1)) # possono essere massimo 16 timers
        else:
            relay_nr=[min(int(relay_nr), 16)] # per evitare > 16

        _action=['off', 'on', 'toggle', 'rule/blink']
        _mode=['clock time', 'sunrise', 'sunset']
        sunrise_time, sunset_time=sunTime_casetta(str_format='%H:%M')




        myTimers={}
        if not 'RESULT' in self.device:
            self.logger.caller("RESULT not in device: %s", self.device_name)
            return {}

        data=self.device['RESULT']
        if not data or not 'Timers' in data:
            self.logger.caller("data: %s", data)
            return myTimers

        areEnabled=(data['Timers']=="ON")


        if areEnabled:
            for name in data.keys():
                if not name.startswith('Timer'):
                    continue

                index=name.split('Timer')[1]
                if index.isdigit():
                    i=int(index)
                else:
                    continue

                timerx=data[f'Timer{i}']
                if timerx['Enable']==0:
                    continue

                output=int(timerx['Output'])
                if output not in relay_nr:
                    continue

                MODE=_mode[int(timerx['Mode'])]
                ACTION=_action[int(timerx['Action'])]
                REPEAT='YES' if timerx['Repeat']=='1' else 'NO'
                offset=timerx["Time"]
                DAYS=_convertWeekDays(timerx['Days'])
                RELAY=timerx['Output']

                if MODE == 'sunset':
                    onTime=' sS'
                    offset=timerx["Time"]
                    _time=sum_offset(t0_time=sunset_time,offset=offset)

                elif MODE == 'sunrise':
                    onTime=' sR'
                    _time=sum_offset(t0_time=sunrise_time,offset=offset)

                else:
                    onTime=''
                    _time=timerx["Time"]

                if italic:
                    myTimers[f't{i}.{output}']=f'{italicB}{_time} {ACTION.upper()} {DAYS}{onTime}{italicE}' # italic
                else:
                    myTimers[f't{i}.{output}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}'
        else:
            myTimers='Disabled'

        return myTimers









if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    from suntimes_LN import sunTime_casetta
    args=[2, '600']
    # ret=checkRelayNumber(arg=args[0], nRelays=1)
    ret=humanToPulseTime(args=[1, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[0, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[2, '600'], nRelays=1)
    print(ret)


    data=pulseTimeToHuman(value=1000)
    print(data)

    data=timersToHuman(data=TIMERS, outputRelay=1)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=2)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=0)
    print(data)

    # setTimer              number HH:MM   days   output   repeat action
    # setTimer                1    12:30 -1--1-1     1       1      on
    data=humanToTimers(data='1 12:15 -1--1-1 1 1 on', nRelays=1)
    print(data)

    data=humanToTimers(data='1 disable', nRelays=1)
    print(data)

    data=humanToTimers(data='1 enable', nRelays=1)
    print(data)
