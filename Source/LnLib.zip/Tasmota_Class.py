#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 11-12-2022 13.15.35
#
import  sys; sys.dont_write_bytecode = True
import os
import json, yaml
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timedelta
import time

from LnSunTime import sunTime_casetta
from LnTime import seconds_diff_datetime
from LoretoDict import LnDict



class TasmotaClass:
    def __init__(self, device_name: str, runtime_dir: str, logger):
        self.logger = logger
        self.device_name = device_name

        self.device_file_json=f"{runtime_dir}/{self.device_name}.json"
        self.device_file_yaml=f"{runtime_dir}/{self.device_name}.yaml"

        self.italicB='<i>'
        self.italicE='</i>'

        ### lettura file oppure default dict
        device=self.loadDeviceFile()
        if not device_name in device:
            device[device_name]=dict() # initialize

        ### convert to LoretoDict
        self.full_device=LnDict(device)

        self.set_relays(self.full_device['Loreto.relays'])

        self.telegramNotification(seconds=.1)
        self.timerForSavingData(seconds=0.1)



    ###################################################################
    #
    ###################################################################
    def loadDeviceFile(self, filename: str=None, cast: dict=dict()):
        if not filename:
            filename=self.device_file_json

        base_device=f"""
            Loreto:
                file_out: {filename}
                last_update: "2011-12-13T01:02:03"
                device_name: {self.device_name}
                topic_name:  {self.device_name}
                modello: ""
                firmware: ""
                mac1: ""
                POWER1: N/A
                Mac: N/A
                IPAddress: N/A
                Gateway: N/A
                Wifi: {dict()}
                relays:         [1, 0, 0, 0, 0, 0, 0, 0 ]
                friendly_names:  ["Relay1", "Relay2", "Relay3", "Relay4", "Relay5", "Relay6", "Relay7", "Relay8"]
                PulseTime:
                    "Set":       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
                    "Remaining": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
        """

        if os.path.exists(filename) and os.stat(filename).st_size>0:
            with open(filename, 'r') as fin:
                device=json.load(fin)
        else:
            device=yaml.load(base_device, Loader=yaml.SafeLoader)

        return device if isinstance(cast, dict) else cast(device)



    ##################################################################
    ##################################################################
    #    U P D A T E    functions
    ##################################################################
    ##################################################################




    ################################################
    ### add/update payload to device
    ### crea entry con la key richiesta
    ################################################
    def updateDevice(self, main_key_path: str, data: dict, writeFile=False):

        if not isinstance(data, dict):
            self.logger.warning("data is not dictionary: %s", data)
            return
        self.full_device.set_keypath(keypath=main_key_path, value=data, create=True)


        ### aggiorniamo anche il wifi e lo STATE visto che StatusSTS==STATE

        if 'StatusSTS' in data:
            statusSTS=data['StatusSTS']
            self.full_device['Loreto']['last_update']=statusSTS['Time']
            self.full_device['Loreto']['Wifi'].update(statusSTS['Wifi'])
            if not 'STATE' in self.full_device[self.device_name]:
                self.full_device[self.device_name]['STATE']={}

            self.full_device[self.device_name]['STATE'].update(statusSTS)








    ################################################################
    #
    ################################################################
    def updateLoreto_POWER(self, data: dict):
        _loreto_dict=self.full_device['Loreto']

        for relay in range(self.relays):
            key=f'POWER{relay+1}'
            if key in data:
                _loreto_dict[key]=data[key]
                fn=self.friendlyNames[relay] ### get relative friendly_name
                _loreto_dict[fn]=data[key]   ### set power status for friendly_name


    ################################################################
    # {"PulseTime2":{"Set":0,"Remaining":0}}
    # {"PulseTime":{"Set":[111,0,0,0,0...],"Remaining":[0,0,0...]
    ################################################################
    def updateLoreto_PulseTime(self, pt_key: str, data: dict):
        loreto_pulsetime_set=self.full_device['Loreto.PulseTime.Set']
        loreto_pulsetime_remaining=self.full_device['Loreto.PulseTime.Remaining']

        ### copiamo l'intero Set
        if pt_key=='PulseTime':
            Set=data['PulseTime.Set']
            Remaining=data['PulseTime.Remaining']
            values=[]
            for relay_nr in range(self.relays):
                loreto_pulsetime_set[relay_nr]       = Set[relay_nr]
                loreto_pulsetime_remaining[relay_nr] = Remaining[relay_nr]


        ### modifichiamo il singolo Set[x]
        else:
            relay_nr=int(pt_key[-1])-1
            loreto_pulsetime_set[relay_nr]       = data[pt_key]['Set']
            loreto_pulsetime_remaining[relay_nr] = data[pt_key]['Remaining']




    ################################################################
    #
    ################################################################
    def updateLoreto_SSID(self, data: dict):
        self.full_device['Loreto']['SSID']=data

    ################################################################
    #
    ################################################################
    def updateLoreto_SensorsSN(self, data: dict):
        self.full_device['Loreto']['last_update']=data['sn.Time']


    ################################################################
    #
    ################################################################
    def updateLoreto_SensorsRL(self, data: dict):
        _dict=self.full_device['Loreto']

        _dict['relays']           = [x for x in data['rl'] if x == 1]
        _dict['friendly_names']   = [x for x in data['fn'] if (x != '' and x != None)]
        _dict['ip_address']       = data['ip']
        _dict['device_name']      = data['dn']
        _dict['topic_name']       = data['t']
        _dict['modello']          = data['md']
        _dict['firmware']         = data['sw']
        _dict['mac1']             = data['mac'] # formato senza punti ... da modificare


    ################################################################
    #
    ################################################################
    def updateLoreto_STATE(self, data: dict):
        _dict=self.full_device['Loreto']

        _dict['last_update']=data['Time']
        _dict['Wifi']=data['Wifi']



    ################################################################
    # Blocca le notifiche verso telegram
    # Utile quando si inviano diversi comandi al device
    ################################################################
    def telegramNotification(self, seconds: float=0) -> bool:
        if seconds:
            self.telegram_notification=time.time() + seconds

        remaining=self.telegram_notification-time.time()
        self.logger.info("telegramNotification ramaining secs: %s", remaining)
        return ( remaining <= 0)



    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def timerForSavingData(self, seconds: float=0) -> bool:
        if seconds:
            self.save_file_timer=time.time() + seconds
        return ( time.time()-self.save_file_timer > 0)


    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def savingDataOnFile(self, forceWrite=False):
        if self.timerForSavingData() or forceWrite:
            self.logger.notify('updating file: %s', self.device_file_json)
            dummyLnDict=LnDict()
            dummyLnDict.toJsonFile(d=self.full_device, filename=self.device_file_json, indent=4, sort_keys=False, replace=True)
            dummyLnDict.toYamlFile(d=self.full_device, filename=self.device_file_yaml, indent=4, sort_keys=False, replace=True)
            self.timerForSavingData(seconds=60) ### reload timer
        else:
            self.logger.notify("file %s will not be saved due to timerForSavingData still active.", self.device_file_json)


    ################################################################
    #
    ################################################################
    def set_relays(self, data: list):
        self.full_device['Loreto.relays']=[x for x in data if x == 1]





    ##################################################################
    ##################################################################
    #    R E T R I E V E    functions
    ##################################################################
    ##################################################################






    @property
    def relays(self) -> int:
        return len(self.full_device['Loreto.relays'])

    @property
    def friendlyNames(self) -> list:
        data=self.full_device['Loreto.friendly_names']
        return data[:self.relays]




    ################################################################
    #
    ################################################################
    def relayStatus(self, relay_nr: int, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        if relay_nr in range(1, self.relays+1):
            status=self.full_device[f'Loreto.POWER{relay_nr}']
            if status:
                return f'{italicB}{status}{italicE}'
            else:
                self.logger.error('%s - relay_nr: %s/%s', self.device_name, relay_nr, self.relays)
        else:
            return 'N/A'




    ####################################################################
    ### info varie
    ####################################################################
    def deviceName(self, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        return f"{italicB}{self.device_name}{italicE}"
        # return italicB + self.device_name + italicE




    ####################################################################
    ### info varie
    ####################################################################
    def Info(self, italic=False):
        data=self.full_device['Loreto']
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        d=dict()

        if 'T' in data['last_update']:

            dt_last_update=datetime.strptime(data['last_update'], "%Y-%m-%dT%H:%M:%S")
            dt_now=datetime.now()
            diff_time=seconds_diff_datetime(dt_now, dt_last_update) ### dt1-dt2

            if diff_time > 60:
                d['Last Update OLD']= {
                            "date": "<b>" + dt_last_update.strftime("%d-%m-%Y") + "</b>",
                            "time": "<b>" + dt_last_update.strftime("%H-%M-%S") + "</b>",
                            }
            else:
                d['Last Update']= {
                            "date": italicB + dt_last_update.strftime("%d-%m-%Y") + italicE,
                            "time": italicB + dt_last_update.strftime("%H-%M-%S") + italicE,
                            }
            d['firmware'] = f'{italicB}{data["firmware"]}{italicE}'
            d['modello']  = f'{italicB}{data["modello"]}{italicE}'

            # timeit.timeit('var1 + var2 + var3', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)
            # timeit.timeit('f"{var1}{var2}{var3}"', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)

        return d


    ####################################################################
    ### preparazione stato networking
    ### {"IPAddress1":"0.0.0.0 (192.168.1.103)","IPAddress2":"192.168.1.1","IPAddress3":"255.255.255.0","IPAddress4":"192.168.1.9","IPAddress5":"1.1.1.1"}
    ####################################################################
    def net_status(self, payload: dict={}, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''
        _dict={}

        if payload:
            ip=payload['IPAddress1']
            ip=ip.split('(')[1]
            ip=ip.split(')')[0]
            _dict={
                "IPAddress": ip,
                "Gateway":   f'{italicB}{payload["IPAddress2"]}{italicE}',
                "SubMask":   f'{italicB}{payload["IPAddress3"]}{italicE}',
                "DNS1":      f'{italicB}{payload["IPAddress4"]}{italicE}',
                "DNS2":      f'{italicB}{payload["IPAddress5"]}{italicE}',
                }


        else:
            data=self.full_device[f'{self.device_name}.StatusNET']
            if data:
                _dict={
                    "Hostname":  f'{italicB}{data["Hostname"]}{italicE}',
                    "IPAddress": f'{italicB}{data["IPAddress"]}{italicE}',
                    "Gateway":   f'{italicB}{data["Gateway"]}{italicE}',
                    "SubMask":   f'{italicB}{data["Subnetmask"]}{italicE}',
                    "DNS1":      f'{italicB}{data["DNSServer1"]}{italicE}',
                    "DNS2":      f'{italicB}{data["DNSServer2"]}{italicE}',
                    "Mac":       f'{italicB}{data["Mac"]}{italicE}',
                    }



        return _dict



    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def wifi(self, italic=False):
        data=self.full_device['Loreto.Wifi']
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        wifi={}
        if data:
            wifi["SSId"]      = f"{italicB}{data['SSId']}{italicE}"
            wifi["BSSId"]     = f"{italicB}{data['BSSId']}{italicE}"
            wifi["RSSI"]      = f"{italicB}{data['RSSI']}{italicE}"
            wifi["Signal"]    = f"{italicB}{data['Signal']}{italicE}"

            wifi["Mac"]       = f"{italicB}{self.full_device['Loreto.Mac']}{italicE}"
            wifi["IPAddress"] = f"{italicB}{self.full_device['Loreto.IPAddress']}{italicE}"


        return wifi




    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def mqtt(self, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        _dict={}

        data=self.full_device[f'{self.device_name}.StatusMQT']
        if data:
            _dict={"MQTT": {
                                'Host': f"{italicB}{data['MqttHost']}{italicE}",
                                'Port': f"{italicB}{data['MqttPort']}{italicE}",
                                'User': f"{italicB}{data['MqttUser']}{italicE}",
                                'Client': f"{italicB}{data['MqttClient']}{italicE}",
                            }
                    }

        return _dict


    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def firmware(self, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        _dict={}

        data=self.full_device[f'{self.device_name}.StatusFWR']
        if data:
            for k,v in data.items():
                _dict[k]=f'{italicB}{v}{italicE}'

            _dict={"Firmware": _dict }

        return _dict

    ####################################################################
    ### preparazione stato PulseTime
    ####################################################################
       #----------------------------------------------
    def pulseTimeToHuman(self, index: int, italic=False) -> int:

        #-----------------------------------------------
        def millisecs_to_HMS_ms(milliseconds, strip_leading=False):
            s, ms = divmod(milliseconds, 1000)
            m, s = divmod(s, 60)
            h, m = divmod(m, 60)
            hours=int(h)
            minutes=int(m)
            seconds=int(s)
            # milliseconds=int(ms)
            milliseconds = f'.{int(ms):01}' if ms>0 else ''

            ret_val=f'{hours:02}:{minutes:02}:{seconds:02}{milliseconds}'
            if strip_leading:
                if h==0 and minutes==0:
                    ret_val=f'{seconds:02}{milliseconds}'
                elif h==0:
                    ret_val=f'{minutes:02}:{seconds:02}{milliseconds}'


            return ret_val

        #-----------------------------------------------
        def pulsetime_to_ms(value):
            if value<=111:
                seconds=int(value/10)
                milliseconds=(value/10)*1000
            else:
                seconds=int(value-100)
                milliseconds=(value-100)*1000
            return milliseconds
        #-----------------------------------------------


        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''
        pulsetime_set="?"
        pulsetime_remaining="?"


        ptr=self.full_device['Loreto.PulseTime']
        if ptr:
            SET=self.full_device["Loreto.PulseTime.Set"]
            _ms=pulsetime_to_ms(SET[index])
            pulsetime_value=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)

            REMAINING=self.full_device["Loreto.PulseTime.Remaining"]
            _ms=pulsetime_to_ms(REMAINING[index])
            pulsetime_remaining=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)



        # return italicB + pulsetime_value + italicE, italicB + pulsetime_remaining + italicE
        return f"{italicB}{pulsetime_value}{italicE}", f'{italicB}{pulsetime_remaining}{italicE}'





    ####################################################################
    #
    # {"PulseTime":{"Set":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"Remaining":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}}
    #
    #   PulseTime<x>:   Display the amount of PulseTime remaining on the corresponding Relay<x>
    #           0 / OFF = disable use of PulseTime for Relay<x>
    #           1..111 = set PulseTime for Relay<x> in 0.1 second increments
    #           112..64900 = set PulseTime for Relay<x>, offset by 100, in 1 second increments.
    #           Add 100 to desired interval in seconds, e.g.,
    #           PulseTime 113 = 13 seconds and PulseTime 460 = 6 minutes (i.e., 360 seconds)
    #           <value> Set the duration to keep Relay<x> ON when Power<x> ON command is issued.
    #           After this amount of time, the power will be turned OFF.
    #
    ####################################################################
    def humanToPulseTime(self, args: list, nRelays: int) -> SimpleNamespace:
        """ setPulseTime <relay> <seconds>  -->  pulsetime<relay> <pt_units>
            setPulseTime <relay> <MM:SS>    -->  pulsetime<relay> <pt_units>
        """
        #-------------------------------------------------
        def secondsToPulseTime(seconds: float) -> int:
            seconds=float(seconds)
            if seconds<=11.1:
                pulsetime_value=seconds*10
            else:
                pulsetime_value=float(seconds)+100

            return float(pulsetime_value)
        #-------------------------------------------------


        msg=None
        if len(args)>1:
            ret=checkRelayNumber(arg=args[0], nRelays=nRelays)
            if ret.err_msg:
                return ret
            else:
                relay=ret.relay

            if isinstance(args[1], (int, float)):
                value=secondsToPulseTime(seconds=args[1])

            else:
                try: ### if passed as seconds
                    value=secondsToPulseTime(seconds=float(args[1]))

                except (ValueError):
                    try:
                        mm, ss=args[1].split(':')
                    except (Exception) as exc:
                        msg=f"ERROR evaluating seconds value '{args[1]}')"
                        value=-1

                    pt.value=secondsToPulseTime(seconds=float(mm)*60+float(ss))

        else:
            pt.msg='missing args...'


        pt=SimpleNamespace()
        pt.value=value
        pt.msg=msg
        pt.relay=relay
        return pt





    ####################################################################
    # "RESULT": {
    #         "Timers": "ON",
    #         "Timer1": {
    #             "Enable": 1,
    #             "Mode": 0,
    #             "Time": "01:00",
    #             "Window": 0,
    #             "Days": "1111111",
    #             "Repeat": 1,
    #             "Output": 1,
    #             "Action": 0
    #         },
    #
    # voglamo tradurlo in:
    #    Timers:
    #       T1.x: 17:21 on LMMGVSD sS   x rappresenta il relay di output
    #       T2.x: 22:30 off LMMGVSD   x rappresenta il relay di output
    ####################################################################
    def timersToHuman(self, relay_nr: int=0, italic=False) -> dict:
        # -----------------------------------
        def _convertWeekDays(val):
            _it_days='DLMMGVS' # tasmota days start from Sunday
            _en_days='SMTWTFS' # tasmota days start from Sunday
            _data=''
            for i in range(0, 7):
                _data+=_en_days[i] if val[i]=='1' else '_ '
            return _data[1:] + _data[0] # lets start from Monday



        # -----------------------------------
        def sum_offset(t0_time, offset):
            offset_HH, offset_MM=offset.split(':')
            offset_minutes=abs(int(offset_HH))*60+int(offset_MM)
            if offset_minutes==0:
                return t0_time

            t0_HH, t0_MM=t0_time.split(':')
            t0=timedelta(hours=int(t0_HH), minutes=int(t0_MM))
            ofs=timedelta(hours=int(offset_HH), minutes=int(offset_MM))

            if offset[0]=='-':
                new_time=t0-ofs
            else:
                new_time=t0+ofs

            return time.strftime("%H:%M", time.gmtime(new_time.total_seconds()))

        # -----------------------------------

        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''





        if relay_nr<1:
            relay_nr=list(range(1,16+1)) # possono essere massimo 16 timers
        else:
            relay_nr=[min(int(relay_nr), 16)] # per evitare > 16

        _action=['off', 'on', 'toggle', 'rule/blink']
        _mode=['clock time', 'sunrise', 'sunset']
        sunrise_time, sunset_time=sunTime_casetta(str_format='%H:%M')




        myTimers={}

        '''
        "TIMERS": {
            "Timers": "ON",
            "Timer1": {....
        '''
        dev_data=self.full_device[self.device_name]
        if not dev_data or not 'TIMERS' in dev_data:
            self.logger.caller("data: %s", dev_data)
            return "N/A"



        data=dev_data['TIMERS']
        areEnabled=(data['Timers']=="ON")

        if areEnabled:
            for name in data.keys():
                if not name.startswith('Timer'):
                    continue

                index=name.split('Timer')[1]
                if index.isdigit():
                    i=int(index)
                else:
                    continue

                timerx=data[f'Timer{i}']
                if timerx['Enable']==0:
                    continue

                output=int(timerx['Output'])
                if output not in relay_nr:
                    continue

                MODE=_mode[int(timerx['Mode'])]
                ACTION=_action[int(timerx['Action'])]
                REPEAT='YES' if timerx['Repeat']=='1' else 'NO'
                offset=timerx["Time"]
                DAYS=_convertWeekDays(timerx['Days'])
                RELAY=timerx['Output']

                if MODE == 'sunset':
                    onTime=' sS'
                    offset=timerx["Time"]
                    _time=sum_offset(t0_time=sunset_time,offset=offset)

                elif MODE == 'sunrise':
                    onTime=' sR'
                    _time=sum_offset(t0_time=sunrise_time,offset=offset)

                else:
                    onTime=''
                    _time=timerx["Time"]

                if italic:
                    myTimers[f't{i}.{output}']=f'{italicB}{_time} {ACTION.upper()} {DAYS}{onTime}{italicE}' # italic
                else:
                    myTimers[f't{i}.{output}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}'
        else:
            myTimers='Disabled'

        return myTimers









if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    from suntimes_LN import sunTime_casetta
    args=[2, '600']
    # ret=checkRelayNumber(arg=args[0], nRelays=1)
    ret=humanToPulseTime(args=[1, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[0, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[2, '600'], nRelays=1)
    print(ret)


    data=pulseTimeToHuman(value=1000)
    print(data)

    data=timersToHuman(data=TIMERS, outputRelay=1)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=2)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=0)
    print(data)

    # setTimer              number HH:MM   days   output   repeat action
    # setTimer                1    12:30 -1--1-1     1       1      on
    data=humanToTimers(data='1 12:15 -1--1-1 1 1 on', nRelays=1)
    print(data)

    data=humanToTimers(data='1 disable', nRelays=1)
    print(data)

    data=humanToTimers(data='1 enable', nRelays=1)
    print(data)
