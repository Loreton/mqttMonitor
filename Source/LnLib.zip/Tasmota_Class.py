#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 17-12-2022 10.26.16
#
import  sys; sys.dont_write_bytecode = True
import os
import json, yaml
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timedelta
from benedict import benedict
import time

from LnSunTime import sunTime_casetta
from LnTime import seconds_diff_datetime
# from LoretoDict import LnDict



class TasmotaClass:
    def __init__(self, device_name: str, runtime_dir: str, logger):
        self.logger = logger
        self.device_name = device_name

        self.device_file_json=f"{runtime_dir}/{self.device_name}.json"
        self.device_file_yaml=f"{runtime_dir}/{self.device_name}.yaml"

        self.italicB='<i>'
        self.italicE='</i>'


        ### lettura file oppure default dict
        loreto_data=self.loadDeviceFile()

        ### convert to benedict
        self.full_device=benedict(loreto_data)

        ### add deviceDB
        self.full_device[self.device_name]={}

        ### create fast pointers
        self.loretoDB=self.full_device['Loreto']
        self.deviceDB=self.full_device[device_name]
        if not 'STATE' in self.loretoDB: self.loretoDB['STATE']={}
        if not 'STATE' in self.deviceDB: self.deviceDB['STATE']={}

        self.set_relays(self.loretoDB['relays'])

        self.telegramNotification(seconds=.1)
        self.timerForSavingData(seconds=0.1)



    ###################################################################
    # Carichiamo solo i dati sommari sotto la key: Loreto
    ###################################################################
    def loadDeviceFile(self, filename: str=None):
        if not filename:
            filename=self.device_file_json

        base_device=f"""
            Loreto:
                file_out: {filename}
                last_update: "2011-12-13T01:02:03"
                device_name: {self.device_name}
                topic_name:  {self.device_name}
                modello: ""
                firmware: ""
                STATE:
                    Time: "2022-12-16T11:40:27"
                    Uptime: N/A
                    UptimeSec: 0
                    Heap: 25
                    SleepMode: Dynamic
                    Sleep: 50
                    LoadAvg: 19
                    MqttCount: 3
                    POWER1: N/A
                    Wifi:
                        AP: 1
                        SSId: N/A
                        BSSId: N/A
                        Channel: 10
                        Mode: N/A
                        RSSI: 1
                        Signal: -1
                        LinkCount: 2
                        Downtime: N/A

                NET:
                    IPAddress: N/A
                    Gateway: N/A
                    Subnetmask: N/A
                    DNSServer1: N/A
                    DNSServer2: N/A
                    Mac: N/A

                relays:         [1, 0, 0, 0, 0, 0, 0, 0 ]
                friendly_names:  ["Relay_01", "Relay_02", "Relay_03", "Relay_04", "Relay_05", "Relay_06", "Relay_07", "Relay_08"]
                PulseTime:
                    "Set":       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
                    "Remaining": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
        """
                # Wifi: {dict()}

        device=None
        if os.path.exists(filename) and os.stat(filename).st_size>0:
            with open(filename, 'r') as fin:
                device=json.load(fin)
                if not 'Loreto' in device:
                    device=None

        if not device:
            device=yaml.load(base_device, Loader=yaml.SafeLoader)

        return device



    ##################################################################
    ##################################################################
    #    U P D A T E    functions
    ##################################################################
    ##################################################################




    ################################################
    ### add/update payload to device
    ### crea entry con la key richiesta
    ################################################
    def updateDevice(self, key_path: str, data: dict, writeFile=False):

        if not isinstance(data, dict):
            self.logger.warning("data is not dictionary: %s", data)
            return

        if not key_path:
            keys=list(data.keys())

            ### aggiungiamola a LoretoDB
            if len(keys)==1:
                single_key='SingleKey'

                if 'POWER' in single_key:
                    self.updateLoreto_POWER(data=data)

                else:
                    if single_key not in self.loretoDB:
                        self.loretoDB[single_key]=benedict()

                    self.loretoDB[single_key].update(data)

            elif 'Time' in data and 'Wifi' in data:
                key_path='STATE' ### è uno state che arriva solo al momento della connect al broker

            else:
                self.logger.caller('should not occurs', stacklevel=1)
                self.logger.caller('payload: %s', data.to_yaml())
                import pdb; pdb.set_trace(); pass # by Loreto
                return



        if key_path:
            if key_path not in self.deviceDB:
                self.deviceDB[key_path]=benedict()

            self.deviceDB[key_path].update(data)


        ### aggiorniamo anche il loretoDB  lo STATE visto che

        if key_path=='STATE':
            self.loretoDB['STATE'].update(data)
            self.loretoDB['last_update']=data['Time']


        elif 'StatusSTS' in data: ### StatusSTS==STATE
            statusSTS=data['StatusSTS']
            self.loretoDB['STATE'].update(statusSTS)
            self.deviceDB['STATE'].update(statusSTS)
            self.loretoDB['last_update']=statusSTS['Time']

        elif 'StatusNET' in data:
            net=data['StatusNET']
            self.loretoDB["NET"].update(data['StatusNET'])


        elif key_path=='Config':
            self.updateLoreto_Config(data=data)

        self.savingDataOnFile()







    ################################################################
    #
    ################################################################
    def updateLoreto_POWER(self, data: dict):
        for relay in range(self.relays):
            key=f'POWER{relay+1}'
            if key in data:
                self.loretoDB['STATE'][key]=data[key]



    ################################################################
    # {"PulseTime1":{"Set":0,"Remaining":0}}
    # {"PulseTime":{"Set":[111,0,0,0,0...],"Remaining":[0,0,0...]
    ################################################################
    def updateLoreto_PulseTime(self, key_name: str, data: dict):

        loreto_set=self.loretoDB['PulseTime.Set']
        loreto_remaining=self.loretoDB['PulseTime.Remaining']

        ### copiamo solo i pulsetime relativi al numero di relays
        if key_name=='PulseTime':
            self.loretoDB['PulseTime.Set']=data['PulseTime.Set'][:self.relays]
            self.loretoDB['PulseTime.Remaining']=data['PulseTime.Remaining'][:self.relays]

        ### modifichiamo il singolo Set[x]
        else:
            relay_nr=int(key_name[-1])-1
            if relay_nr in range(self.relays):
                loreto_set[relay_nr]       = data[key_name]['Set']
                loreto_remaining[relay_nr] = data[key_name]['Remaining']



    ################################################################
    #
    ################################################################
    def updateLoreto_SSID(self, data: dict):
        self.loretoDB['SSID']=data



    ################################################################
    #
    ################################################################
    def updateLoreto_Config(self, data: dict):
        if 'sn' in data:
            pass
        else:
            _dict=self.loretoDB
            _dict['relays']           = [x for x in data['rl'] if x == 1]
            _dict['friendly_names']   = [x for x in data['fn'] if (x != '' and x != None)]
            _dict['device_name']      = data['dn']
            _dict['topic_name']       = data['t']
            _dict['modello']          = data['md']
            _dict['firmware']         = data['sw']


            _dict['NET.IPAddress']        = data['ip']
            _dict['NET.Mac']              = data['mac'] # formato senza punti ... da modificare



    ################################################################
    # Blocca le notifiche verso telegram
    # Utile quando si inviano diversi comandi al device
    ################################################################
    def telegramNotification(self, seconds: float=0) -> bool:
        if seconds:
            self.telegram_notification=time.time() + seconds

        remaining=self.telegram_notification-time.time()
        self.logger.info("telegramNotification ramaining secs: %s", remaining)
        return ( remaining <= 0)



    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def timerForSavingData(self, seconds: float=0) -> bool:
        if seconds:
            self.save_file_timer=time.time() + seconds
        remaining=time.time()-self.save_file_timer
        self.logger.notify('timerForSavingData remaining: %s', remaining)
        return ( remaining > 0)


    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def savingDataOnFile(self, forceWrite=False):
        if self.timerForSavingData() or forceWrite:
            self.logger.notify('updating file: %s', self.device_file_json)
            self.full_device.to_json(filepath=self.device_file_json, indent=4, sort_keys=False)
            self.full_device.to_yaml(filepath=self.device_file_yaml, indent=4, sort_keys=False)
            self.timerForSavingData(seconds=60) ### reload timer
        else:
            self.logger.notify("file %s will not be saved due to timerForSavingData still active.", self.device_file_json)


    ################################################################
    #
    ################################################################
    def set_relays(self, data: list):
        self.loretoDB['relays']=[x for x in data if x == 1]





    ##################################################################
    ##################################################################
    #    R E T R I E V E    functions
    ##################################################################
    ##################################################################






    @property
    def relays(self) -> int:
        try:
            return len(self.loretoDB['relays'])
        except (Exception) as exc:
            self.logger.caller('%s - %s', self.device_name, exc)

    # @property
    def friendlyNames(self, relay_nr: int=0):
        fn=[]
        for index in range(self.relays):
            fn.append(self.loretoDB['friendly_names'][index])

        if relay_nr in range(1, self.relays+1):
            return fn[relay_nr]
        return fn



        # try:
        #     data=self.loretoDB['friendly_names']
        #     return data[relay_nr]
        # except (Exception) as exc:
        #     self.logger.caller('%s - %s', self.device_name, exc)




    ################################################################
    #
    ################################################################
    def relayStatus(self, relay_nr: int, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        if relay_nr in range(1, self.relays+1):
            status=self.full_device[f'Loreto.STATE.POWER{relay_nr}']
            if status:
                return f'{italicB}{status}{italicE}'
            else:
                self.logger.error('%s - relay_nr: %s/%s', self.device_name, relay_nr, self.relays)
        else:
            return 'N/A'




    ####################################################################
    ### info varie
    ####################################################################
    def deviceName(self, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        return f"{italicB}{self.device_name}{italicE}"
        # return italicB + self.device_name + italicE




    ####################################################################
    ### info varie
    ####################################################################
    def Info(self, italic=False):
        data=self.loretoDB
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        d=dict()

        if 'T' in data['last_update']:

            dt_last_update=datetime.strptime(data['last_update'], "%Y-%m-%dT%H:%M:%S")
            dt_now=datetime.now()
            diff_time=seconds_diff_datetime(dt_now, dt_last_update) ### dt1-dt2

            if diff_time > 60:
                d['Last Update OLD']= {
                            "date": "<b>" + dt_last_update.strftime("%d-%m-%Y") + "</b>",
                            "time": "<b>" + dt_last_update.strftime("%H-%M-%S") + "</b>",
                            }
            else:
                d['Last Update']= {
                            "date": italicB + dt_last_update.strftime("%d-%m-%Y") + italicE,
                            "time": italicB + dt_last_update.strftime("%H-%M-%S") + italicE,
                            }
            d['firmware'] = f'{italicB}{data["firmware"]}{italicE}'
            d['modello']  = f'{italicB}{data["modello"]}{italicE}'

            # timeit.timeit('var1 + var2 + var3', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)
            # timeit.timeit('f"{var1}{var2}{var3}"', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)

        return d


    ####################################################################
    ### preparazione stato networking
    ### {"IPAddress1":"0.0.0.0 (192.168.1.103)","IPAddress2":"192.168.1.1","IPAddress3":"255.255.255.0","IPAddress4":"192.168.1.9","IPAddress5":"1.1.1.1"}
    ####################################################################
    def net_status(self, payload: dict={}, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''
        _dict={}

        if payload:
            ip=payload['IPAddress1']
            ip=ip.split('(')[1]
            ip=ip.split(')')[0]
            _dict={
                "IPAddress": ip,
                "Gateway":   f'{italicB}{payload["IPAddress2"]}{italicE}',
                "SubMask":   f'{italicB}{payload["IPAddress3"]}{italicE}',
                "DNS1":      f'{italicB}{payload["IPAddress4"]}{italicE}',
                "DNS2":      f'{italicB}{payload["IPAddress5"]}{italicE}',
                }


        else:
            data=self.loretoDB['NET']
            if data:
                keys=[ "IPAddress",
                        "Gateway",
                        "Subnetmask",
                        "DNSServer1",
                        "DNSServer2",
                        "Mac",
                    ]

                _dict={}
                for key in keys:
                    value=self.loretoDB['NET'][key]
                    _dict[key]=f'{italicB}{value}{italicE}'

        return _dict



    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def wifi(self, italic=False):
        data=self.loretoDB['STATE.Wifi']
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        wifi={}
        keys=[  "AP",
                "SSId",
                "BSSId",
                "Channel",
                "Mode",
                "RSSI",
                "Signal",
                ]

        for key in keys:
            value=self.loretoDB['STATE.Wifi'][key]
            wifi[key]=f'{italicB}{value}{italicE}'


        # if data:
        #     wifi["SSId"]      = f"{italicB}{data['SSId']}{italicE}"
        #     wifi["BSSId"]     = f"{italicB}{data['BSSId']}{italicE}"
        #     wifi["RSSI"]      = f"{italicB}{data['RSSI']}{italicE}"
        #     wifi["Signal"]    = f"{italicB}{data['Signal']}{italicE}"
        #     wifi["Mac"]       = f"{italicB}{self.loretoDB['Mac']}{italicE}"
        #     wifi["IPAddress"] = f"{italicB}{self.loretoDB['IPAddress']}{italicE}"


        return wifi




    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def mqtt(self, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''


        _dict={}

        # data=self.deviceDB['STATUS.StatusMQT']
        data=self.deviceDB.get('STATUS.StatusMQT')
        if data:
            for k,v in data.items():
                _dict[k]=f'{italicB}{v}{italicE}'

            _dict={"MQTT": _dict }
            '''
            _dict={"MQTT": {
                                'Host': f"{italicB}{data['MqttHost']}{italicE}",
                                'Port': f"{italicB}{data['MqttPort']}{italicE}",
                                'User': f"{italicB}{data['MqttUser']}{italicE}",
                                'Client': f"{italicB}{data['MqttClient']}{italicE}",
                            }
                    }
            '''

        return _dict


    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def firmware(self, italic=False):
        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''

        _dict={}

        # data=self.deviceDB['STATUS.StatusFWR']
        data=self.deviceDB.get('STATUS.StatusFWR')

        if data:
            for k,v in data.items():
                _dict[k]=f'{italicB}{v}{italicE}'

            _dict={"Firmware": _dict }

        return _dict

    ####################################################################
    ### preparazione stato PulseTime
    ####################################################################
       #----------------------------------------------
    def pulseTimeToHuman(self, index: int, italic=False) -> int:

        #-----------------------------------------------
        def millisecs_to_HMS_ms(milliseconds, strip_leading=False):
            s, ms = divmod(milliseconds, 1000)
            m, s = divmod(s, 60)
            h, m = divmod(m, 60)
            hours=int(h)
            minutes=int(m)
            seconds=int(s)
            # milliseconds=int(ms)
            milliseconds = f'.{int(ms):01}' if ms>0 else ''

            ret_val=f'{hours:02}:{minutes:02}:{seconds:02}{milliseconds}'
            if strip_leading:
                if h==0 and minutes==0:
                    ret_val=f'{seconds:02}{milliseconds}'
                elif h==0:
                    ret_val=f'{minutes:02}:{seconds:02}{milliseconds}'


            return ret_val

        #-----------------------------------------------
        def pulsetime_to_ms(value):
            if value<=111:
                seconds=int(value/10)
                milliseconds=(value/10)*1000
            else:
                seconds=int(value-100)
                milliseconds=(value-100)*1000
            return milliseconds
        #-----------------------------------------------


        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''
        pulsetime_set="?"
        pulsetime_remaining="?"


        ptr=self.loretoDB['PulseTime']
        if ptr:
            SET=self.full_device["Loreto.PulseTime.Set"]
            _ms=pulsetime_to_ms(SET[index])
            pulsetime_value=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)

            REMAINING=self.full_device["Loreto.PulseTime.Remaining"]
            _ms=pulsetime_to_ms(REMAINING[index])
            pulsetime_remaining=millisecs_to_HMS_ms(milliseconds=_ms, strip_leading=True)



        # return italicB + pulsetime_value + italicE, italicB + pulsetime_remaining + italicE
        return f"{italicB}{pulsetime_value}{italicE}", f'{italicB}{pulsetime_remaining}{italicE}'





    ####################################################################
    #
    # {"PulseTime":{"Set":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"Remaining":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}}
    #
    #   PulseTime<x>:   Display the amount of PulseTime remaining on the corresponding Relay<x>
    #           0 / OFF = disable use of PulseTime for Relay<x>
    #           1..111 = set PulseTime for Relay<x> in 0.1 second increments
    #           112..64900 = set PulseTime for Relay<x>, offset by 100, in 1 second increments.
    #           Add 100 to desired interval in seconds, e.g.,
    #           PulseTime 113 = 13 seconds and PulseTime 460 = 6 minutes (i.e., 360 seconds)
    #           <value> Set the duration to keep Relay<x> ON when Power<x> ON command is issued.
    #           After this amount of time, the power will be turned OFF.
    #
    ####################################################################
    def humanToPulseTime(self, args: list, nRelays: int) -> SimpleNamespace:
        """ setPulseTime <relay> <seconds>  -->  pulsetime<relay> <pt_units>
            setPulseTime <relay> <MM:SS>    -->  pulsetime<relay> <pt_units>
        """
        #-------------------------------------------------
        def secondsToPulseTime(seconds: float) -> int:
            seconds=float(seconds)
            if seconds<=11.1:
                pulsetime_value=seconds*10
            else:
                pulsetime_value=float(seconds)+100

            return float(pulsetime_value)
        #-------------------------------------------------


        msg=None
        if len(args)>1:
            ret=checkRelayNumber(arg=args[0], nRelays=nRelays)
            if ret.err_msg:
                return ret
            else:
                relay=ret.relay

            if isinstance(args[1], (int, float)):
                value=secondsToPulseTime(seconds=args[1])

            else:
                try: ### if passed as seconds
                    value=secondsToPulseTime(seconds=float(args[1]))

                except (ValueError):
                    try:
                        mm, ss=args[1].split(':')
                    except (Exception) as exc:
                        msg=f"ERROR evaluating seconds value '{args[1]}')"
                        value=-1

                    pt.value=secondsToPulseTime(seconds=float(mm)*60+float(ss))

        else:
            pt.msg='missing args...'


        pt=SimpleNamespace()
        pt.value=value
        pt.msg=msg
        pt.relay=relay
        return pt





    ####################################################################
    # "RESULT": {
    #         "Timers": "ON",
    #         "Timer1": {
    #             "Enable": 1,
    #             "Mode": 0,
    #             "Time": "01:00",
    #             "Window": 0,
    #             "Days": "1111111",
    #             "Repeat": 1,
    #             "Output": 1,
    #             "Action": 0
    #         },
    #
    # voglamo tradurlo in:
    #    Timers:
    #       T1.x: 17:21 on LMMGVSD sS   x rappresenta il relay di output
    #       T2.x: 22:30 off LMMGVSD   x rappresenta il relay di output
    ####################################################################
    def timersToHuman(self, relay_nr: int=0, italic=False) -> dict:
        # -----------------------------------
        def _convertWeekDays(val):
            _it_days='DLMMGVS' # tasmota days start from Sunday
            _en_days='SMTWTFS' # tasmota days start from Sunday
            separator='_ '
            _data=''
            for i in range(0, 7):
                _data+=_en_days[i] if val[i]=='1' else separator
            # if not sep in _data:
            #     _data='daily'
            return _data[1:] + _data[0] # lets start from Monday



        # -----------------------------------
        def sum_offset(t0_time, offset):
            offset_HH, offset_MM=offset.split(':')
            offset_minutes=abs(int(offset_HH))*60+int(offset_MM)
            if offset_minutes==0:
                return t0_time

            t0_HH, t0_MM=t0_time.split(':')
            t0=timedelta(hours=int(t0_HH), minutes=int(t0_MM))
            ofs=timedelta(hours=int(offset_HH), minutes=int(offset_MM))

            if offset[0]=='-':
                new_time=t0-ofs
            else:
                new_time=t0+ofs

            return time.strftime("%H:%M", time.gmtime(new_time.total_seconds()))

        # -----------------------------------

        italicB=self.italicB if italic else ''
        italicE=self.italicE if italic else ''





        if relay_nr<1:
            relay_nr=list(range(1,16+1)) # possono essere massimo 16 timers
        else:
            relay_nr=[min(int(relay_nr), 16)] # per evitare > 16

        _action=['off', 'on', 'toggle', 'rule/blink']
        _mode=['clock time', 'sunrise', 'sunset']
        sunrise_time, sunset_time=sunTime_casetta(str_format='%H:%M')




        myTimers={}

        '''
        "TIMERS": {
            "Timers": "ON",
            "Timer1": {....
        '''
        dev_data=self.deviceDB
        if not dev_data or not 'TIMERS' in dev_data:
            self.logger.caller("data: %s", dev_data)
            return "N/A"



        data=dev_data['TIMERS']
        areEnabled=(data['Timers']=="ON")

        if areEnabled:
            for name in data.keys():
                if not name.startswith('Timer'):
                    continue

                index=name.split('Timer')[1]
                if index.isdigit():
                    i=int(index)
                else:
                    continue

                timerx=data[f'Timer{i}']
                if timerx['Enable']==0:
                    continue

                output=int(timerx['Output'])
                if output not in relay_nr:
                    continue

                MODE=_mode[int(timerx['Mode'])]
                ACTION=_action[int(timerx['Action'])]
                REPEAT='YES' if timerx['Repeat']=='1' else 'NO'
                offset=timerx["Time"]
                DAYS=_convertWeekDays(timerx['Days'])
                RELAY=timerx['Output']

                if MODE == 'sunset':
                    onTime=' sS'
                    offset=timerx["Time"]
                    _time=sum_offset(t0_time=sunset_time,offset=offset)

                elif MODE == 'sunrise':
                    onTime=' sR'
                    _time=sum_offset(t0_time=sunrise_time,offset=offset)

                else:
                    onTime=''
                    _time=timerx["Time"]

                fOutput=False
                if fOutput:
                    myTimers[f't{i}.{output}']=f'{italicB}{_time} {ACTION.upper()} {DAYS}{onTime}{italicE}' ### con Output indicator
                else:
                    myTimers[f't{i}']=f'{italicB}{_time} {ACTION.upper()} {DAYS}{onTime}{italicE}' # italic
                # if italic:
                #     if fOutput:
                #         myTimers[f't{i}.{output}']=f'{italicB}{_time} {ACTION.upper()} {DAYS}{onTime}{italicE}' ### con Output indicator
                #     else:
                #         myTimers[f't{i}']=f'{italicB}{_time} {ACTION.upper()} {DAYS}{onTime}{italicE}' # italic
                # else:
                #     if fOutput:
                #         myTimers[f't{i}.{output}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}' ### con Output indicator
                #     else:
                #         myTimers[f't{i}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}'
        else:
            myTimers='Disabled'

        return myTimers









if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    from suntimes_LN import sunTime_casetta
    args=[2, '600']
    # ret=checkRelayNumber(arg=args[0], nRelays=1)
    ret=humanToPulseTime(args=[1, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[0, '600'], nRelays=1)
    print(ret)

    ret=humanToPulseTime(args=[2, '600'], nRelays=1)
    print(ret)


    data=pulseTimeToHuman(value=1000)
    print(data)

    data=timersToHuman(data=TIMERS, outputRelay=1)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=2)
    print(data)
    data=timersToHuman(data=TIMERS, outputRelay=0)
    print(data)

    # setTimer              number HH:MM   days   output   repeat action
    # setTimer                1    12:30 -1--1-1     1       1      on
    data=humanToTimers(data='1 12:15 -1--1-1 1 1 on', nRelays=1)
    print(data)

    data=humanToTimers(data='1 disable', nRelays=1)
    print(data)

    data=humanToTimers(data='1 enable', nRelays=1)
    print(data)
