#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 17-12-2022 08.32.37

import sys; sys.dont_write_bytecode=True
import os
import yaml, json
from collections import OrderedDict
from pathlib import Path
# from LoretoDict import LnDict; lndict=LnDict()
import zipfile, io
from benedict import benedict

##########################################
#
##########################################
class nullLogger():
    def dummy(title, *args, **kwargs):
        pass
    critical=trace=error=notify=function=warning=info=debug=caller=dummy

logger=nullLogger()


### mi trovo anche i nomi dei file per mariadb, brokers, etc....
def setup(*, gVars):
    global gv, logger
    gv=gVars
    logger=gv.logger

############################################
# Supporta anche l'esecuzione come zip
############################################
class LoadYamlFile_Class(object):
    def __init__(self, filename: str, search_paths=[], resolve_vars: bool=False, resolve_include: bool=False):

        self.logger=logger
        self.search_paths=search_paths
        script_path=Path(sys.argv[0]).resolve()

        """ check it its a zip file """
        if zipfile.is_zipfile(script_path):
            self.zipFile=script_path
            self.zFile=zipfile.ZipFile(self.zipFile, "r")
            self.zFileNamelist=self.zFile.namelist()

        else:
            self.zFile=None
            self.zFileNamelist=[]

        filepath=Path(filename).resolve()
        ### aggiungiamo un paio di path nel search...
        self.search_paths.append('')
        self.search_paths.append(str(filepath.parent))

        self.flatten_sep='/'
        self.keypath_sep='.'

        self.my_dict=self.read_file(filename, resolve_vars=resolve_vars)
        self.my_dict=benedict(self.my_dict)

        if resolve_include:
            self.resolve_include(resolve_vars=resolve_vars)


    ##############################################
    # retrieve data
    ##############################################
    def get_dict(self, keypath: str=None):
        if keypath:
            return self.my_dict[keypath]
        return self.my_dict


    #################################################################
    #
    #################################################################
    def read_file(self, filename: str, resolve_vars: bool=True):
        ### it's on filesystem
        self.logger.debug('reding file: %s', filename)
        for path in self.search_paths:
            content=None
            filepath=os.path.join(path, filename)
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    content=f.read() # single string
                break

            ### it's inside zipfile
            elif filepath in self.zFileNamelist:
                buffer=io.BytesIO(self.zFile.read(filepath))
                content=buffer.read()
                break

        if not content:
            self.logger.error('File: %s not found', filepath)
            sys.exit(1)

        ### resolve env vars
        content=os.path.expandvars(content)

        ### convert to dict
        if isinstance(content, dict):
            my_dict=content
        else:
            my_dict=yaml.load(content, Loader=yaml.SafeLoader)

        if resolve_vars:
            my_dict=self.resolve_vars(my_dict) # risolve le variabili interne del nuovo file

        ### utile se si vuole gestire il singolo file
        return my_dict



    #============================================
    #- _!include: conf/lnprofile.yaml
    #- il nuovo file andrà nella root del dict
    #- tested: OK
    #============================================
    def resolve_include(self, d: dict={}, resolve_vars: bool=True):
        if not d: d=self.my_dict

        fFOUND=True
        while fFOUND:
            fFOUND=False
            flat_dict=d.flatten(separator=self.flatten_sep)
            for keypath, value in flat_dict.items():
                if keypath.endswith("include_files"): # ex: _!include: conf/lnprofile.yaml
                    fFOUND=True
                    if not self.flatten_sep in keypath:
                        keypath=self.flatten_sep+keypath # insert separator
                    parent, last_key = keypath.rsplit(self.flatten_sep, 1)

                    ptr=d[parent]     # ptr to parent
                    del ptr[last_key]                  # remove include_files entry
                    for filename in value:
                        data=self.read_file(filename, resolve_vars=resolve_vars)
                        _dict={parent: data}
                        d.merge(_dict, overwrite=False, concat=True)



    # ----------------------------------------------
    # - process all keys for:
    #      include#section_name
    #       The section_name will be included in the replacing the option include#
    #
    # - and all values for:
    #      @@_get.key1.key2...
    # ----------------------------------------------
    def resolve_vars(self, d: dict={}) -> dict:
        if not d: d=self
        pfx_generic='${'
        pfx_get='${get:'
        pfx_get_dict='${get_dict:'
        pfx_get_list='${get_list:'
        pfx_env='${env:'

        if not isinstance(d, benedict):
            d=benedict(d, keypath_separator=self.keypath_sep)
        flat_dict=d.flatten(separator=self.flatten_sep)

        for keypath, value in flat_dict.items():
            if isinstance(value, str):
                if pfx_generic in value:
                    keypath=keypath.replace(self.flatten_sep, self.keypath_sep)
                    # self._resolve_envars(prefix=pfx_env, d=ln_dict, keypath=keypath, value=value)
                    self._resolve_get(prefix=pfx_get, d=d, keypath=keypath, value=value)
                    self._resolve_get_dict(prefix=pfx_get_dict, d=d, keypath=keypath, value=value)

        return d




    # ------------------------------
    def _split_var(self, value, prefix, suffix):
        left_data, rest = value.split(prefix, 1)
        var_name, rest = rest.split(suffix, 1)
        return left_data, var_name, rest
    # ------------------------------

    # ------------------------------
    # folders=/tmp/${env:main.MyData}/file.txt
    # ------------------------------
    def _resolve_envars(self, prefix, d, keypath, value):
        value=os.path.expandvars(value)
        while prefix in value:
            left_data, var_name, rest=self._split_var(value=value, prefix=prefix, suffix="}")
            env_value=os.environ[var_name]
            value=left_data+env_value+rest # importante impostarlo per poter usire dal loop
            value=d.set_keypath(keypath, value)


    # ------------------------------
    # folders=${get_dict:main.MyData}
    # folders._!_remove_this_key=${get_dict:main.MyData}  remove_this_key will be removed
    # folders=/tmp/${get:main.MyData}
    # folders=/tmp/${get:main.MyData}/file.txt
    # ------------------------------
    def _resolve_get_dict(self, prefix, d, keypath, value):
        if prefix in value:
            left_data, kp_pointer, rest=self._split_var(value=value, prefix=prefix, suffix="}")
            base_data=d[kp_pointer]

            if keypath.endswith('remove_this_key'):
                parent_path, key_to_be_removed = keypath.rsplit(d.keypath_separator, 1)
                dest_ptr=d[parent_path] # ptr to parent
                del dest_ptr[key_to_be_removed]                  # remove xxxx_dummy_key entry
                keypath=parent_path
            else:
                dest_ptr=d[keypath]

                ### gioco per non fare override della destinazione, quindi dest_ptr->base_data
            # z= base_data | dest_ptr  # merge with override and create new dict
            # d[keypath]={}
            # d[keypath].update(z)
            dest_ptr.merge(base_data, overwrite=False, concat=False)




    # ------------------------------
    # folders=${get:main.MyData}
    # folders=/tmp/${get:main.MyData}
    # folders=/tmp/${get:main.MyData}/file.txt
    # ------------------------------
    def _resolve_get(self, prefix, d, keypath, value):
        fChanged=False
        while prefix in value:
            fChanged=True
            left_data, keypath_from, rest=self._split_var(value=value, prefix=prefix, suffix="}")
            new_value=d[keypath_from]
            value=f'{left_data}{new_value}{rest}'

        if fChanged:
            d[keypath]=value

    # ------------------------------
    # folders=/tmp/${get_parent:-2.MyData}/file.txt
    # ------------------------------
    def resolve_parent(self, d: dict) -> dict:
        prefix='${get_parent:'

        # ln_dict=LnDict(d)
        # flat_dict=ln_dict.flattenT1a(value_str=prefix, explode_list=True)
        flat_dict=d.flatten(value_strings=prefix, explode_list=True)
        for keypath, value in flat_dict.items():
            if isinstance(value, str):
                value=os.path.expandvars(value) # resolve env variables
                while prefix in value:
                    left_data, var_name, rest=self._split_var(value=value, prefix=prefix, suffix="}")

                    """get parent level... (first qualifier, negative number)
                    """
                    parent, *rel_path=var_name.split('.')
                    token=keypath.split('.')
                    full_keypath=token[:int(parent)] + rel_path
                    ptr_value=d.get_keypath(keypath=full_keypath)
                    value=left_data + ptr_value + rest
                    d.set_keypath(keypath, value)
        return ln_dict







def mariaDB_data(keypath: str=None, cast: dict=dict):
    filename=f"${gv.envars_dir}/yaml/mariadb.yaml"
    data=loadYamlFile(filename=filename, keypath=keypath, cast=cast)
    return data






###############################################
# per i bot, partendo dall'alias risaliamo al nome del bot associato
# return:
#  channel_alias or group_alias:
#      LnPi22_channel:
#          chat_id: -1001508748849
#          group_name: LnPi22_channel
#          type: channel
#          bot_name: LnChannelBot
#
# is_channel: force search only on channels
###############################################
def retrieveBotData(*, alias_name: str, is_channel: bool=False):
    data=telegramGroup_data(keypath='telegram')

    if is_channel==False and alias_name in data['groups'].keys():
        bot=data['groups'][alias_name]

    elif alias_name in data['channels'].keys():
        bot=data['channels'][alias_name]

    else:
        bot={}

    if bot:
        bot_name=bot["bot_name"]
        bot["token"]=data['bots'][bot_name]["token"]

    return bot


###############################################
#
###############################################
def telegramGroup_data(keypath: str=None):
    filepath=gv.telegram_groups_file
    config=LoadYamlFile_Class(filepath)
    return config.get_dict(keypath=keypath)




def mqttBroker(broker_name: str):
    filepath=gv.brokers_file
    config=LoadYamlFile_Class(filepath)
    return config.get_dict(keypath=f"brokers.{broker_name}")






    #################################################
    # Load device json file
    # created by mqttmonitor.py
    #################################################
def retrieveMqttMonitorDevice(device_name: str):
    filename=f'{gv.mqttmonitor_runtime_dir}/{device_name}.json'
    device={}
    if os.path.exists(filename) and os.stat(filename).st_size>0:
        with open(filename, 'r') as fin:
            device=json.load(fin)

    return device
