#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 08-07-2024 18.42.06
#
# ####################################################################################################################

import  sys; sys.dont_write_bytecode=True
import os
from types import SimpleNamespace

import sqlite3
import inspect
import json
import shlex

import collections
from pathlib import Path
from benedict import benedict

if __name__ == '__main__':
    sys.path.insert(0, os.path.expandvars('${HOME}/GIT-REPO/Python/lnPyLib/Logger'))
    sys.path.insert(0, os.path.expandvars('${HOME}/GIT-REPO/Python/lnPyLib/Utils'))
    sys.path.insert(0, os.path.expandvars('${HOME}/GIT-REPO/Python/lnPyLib/SQLite'))
    import LnUtils
    import dictUtils
    from  ColoredLogger_V103 import setColoredLogger, testLogger, getColors_dict; C=getColors_dict()


INFO = 1
# from SQLiteTable_Class import SQLiteTable_Class
import SQLiteTable_Class



#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.logger.caller(__name__)
    SQLiteTable_Class.setup(gVars=gv)




###############################################################################
# DB_Class - DB_Class - DB_Class - DB_Class - DB_Class - DB_Class - DB_Class -
###############################################################################
class SQLiteDB_Class:
    dbFiles={"field_file_name": "value_connection"}

    def __init__(self, *, db_filename: str, logger, create: bool=False, check_same_thread=True):
        self.logger=logger
        self.logger.caller(__name__)
        self.dbfilename=Path(db_filename).resolve()
        self.total_errors=0



        self.connection=self.openDB(create=create, check_same_thread=check_same_thread)



        # ***********************************************
        # * OpenDBase
        # - Connecting to the database file
        # ***********************************************
    def openDB(self, create: bool=False, check_same_thread=True):
        self.logger.caller(__name__)

        #================================================
        def checkDBFile(create: bool):
            self.logger.caller(__name__)
            dbDir = self.dbfilename.parent

            if create:
                dbDir.mkdir(parents=True, exist_ok=True)

                if self.dbfilename.is_file():
                    self.logger.info("DBFile already exists: %s", self.dbfilename)
                    msg = f"""      DBFile {self.dbfilename} already exists - are you sure to replace it\n\n      [Y]es"""
                    choice = self.keyb_prompt(text_msg=msg, validKeys=["y", "pass_back"], exitKeys=["q", "x"])
                    if choice.lower() == 'y':
                        self.logger.info("deleting: %s", self.dbfilename )
                        self.dbfilename.unlink()

            else:
                if not self.dbfilename.exists():
                    self.logger.error(f"il file:\n      %s\n non esiste.", self.dbfilename)
                    msg = f"""      DBFile {self.dbfilename} not exists - create it?\n\n      [Y]es"""
                    choice = self.keyb_prompt(text_msg=msg, validKeys=["y", "pass_back"], exitKeys=["q", "x"])
                    if choice.lower() == 'y':
                        pass
                    else:
                        sys.exit(1)


        #================================================

                if self.dbfilename.is_file():
                    self.logger.info("DBFile already exists: %s", self.dbfilename)
                    if create==True:
                        msg = f"""      DBFile {self.dbfilename} already exists - are you sure to replace it\n\n      [Y]es"""
                        choice = self.keyb_prompt(text_msg=msg, validKeys=["y", "pass_back"], exitKeys=["q", "x"])
                        if choice.lower() == 'y':
                            self.logger.info("deleting: %s", self.dbfilename )
                            self.dbfilename.unlink()



        checkDBFile(create=create)
        self.logger.info("connecting to DBase: %s", self.dbfilename)
        try:
            connection = sqlite3.connect(self.dbfilename, check_same_thread=check_same_thread)
            # connection = sqlite3.connect(self.dbfilename, detect_types=sqlite3.PARSE_DECLTYPES)
        except Exception as why:
            print (str(why))
            sys.exit()


        return connection



    # ***********************************************
    # * struct  = create table if not exists ${Table.name} (
    # *                    "Type"              STRING  NOT NULL,
    # *                    "Author Name"       STRING  NOT NULL
    # *                )
    # * tested on: 25-02-2024 17.13.55
    # ***********************************************
    def createTable(self, *, table_name: str, struct: str, create: bool=False):
        self.logger.caller(__name__)

        if not struct:
            self.logger.error("Table Structure data is missing.")
            sys.exit(1)
        tables=self.getTableList()

        fCreate=create
        if table_name in tables and create==True: # remove current table
            msg = f"""      {table_name} table already exists - are you sure to replace it?\n      [Y]es"""
            choice = self.keyb_prompt(text_msg=msg, validKeys=["y", "pass_back"], exitKeys=["q", "x"])
            if choice.lower() != 'y':
                fCreate=False
                self.logger.info("table: %s has not been replaced!", table_name)

        if fCreate:
            self.Execute(f"DROP TABLE if exists  {table_name}")
            self.Commit()
            ret=self.Execute(f"CREATE TABLE if not exists {table_name} {struct}")
            if ret.rcode>0:
                self.logger.critical("Error creating Table %s", table_name)
                sys.exit(ret.rcode)


        self.Commit()           #  aggiorna il dictionary della struttura




    # ***********************************************
    #   columns:
    #        01_bot_name:          TEXT NOT NULL
    #        02_username:          TEXT
    #        03_link:              TEXT
    #        04_token:             TEXT
    #
    # ***********************************************
    def dict_to_sqlStruc___(self, d: dict):
        col=[]
        for col_name, attributes in d["columns"].items():
            col_name=col_name[3:] ### skip index number
            col.append(f'"{col_name}" {attributes}')

        table_struct = f'( {",".join(col)})'
        self.logger.notify("Table Structure: \n    %s", table_struct)

        return table_struct


    # ***********************************************
    #   columns:
    #        01_bot_name:          TEXT NOT NULL
    #        02_username:          TEXT
    #        03_link:              TEXT
    #        04_token:             TEXT
    #
    #        primary_keys:         device_name, mac
    #        unique:               ip, chat_id, external_domain
    #
    # ***********************************************
    def dict_to_sqlStruct(self, d: dict):
        col=[]
        uniques = ""
        pkeys = ""
        pkeys_cols = []
        uniques_cols = []
        columns_list = []

        for col_name, attributes in d["columns"].items():

            if col_name == "primary_keys":
                if not attributes: continue
                pkeys = f"PRIMARY KEY ({attributes})"
                pkeys_cols=attributes.split(",") # lista delle primary keys columns - PER CONTROLLO
                continue

            elif col_name == "unique":
                if not attributes: continue
                uniques = f"UNIQUE ({attributes})"
                uniques_cols=attributes.split(",") # lista delle unique columns - PER CONTROLLO
                continue

            else:
                col_name=col_name[3:] ### skip index number
                col.append(f'"{col_name}" {attributes}')
                columns_list.append(col_name) # lista delle columns - PER CONTROLLO


        """ CONTROLLO colonne """
        for col_name in pkeys_cols:
            if not col_name.strip() in columns_list:
                self.logger.critical("Primary key: %s is not a vaild column name", col_name)
                sys.exit(1)
        for col_name in uniques_cols:
            if not col_name.strip() in columns_list:
                self.logger.critical("Unique key: %s is not a vaild column name", col_name)
                sys.exit(1)
        """ CONTROLLO colonne """


        table_struct = f''' ( {",".join(col)}, {pkeys} {uniques} )'''
        self.logger.notify("Table Structure: \n    %s", table_struct)

        return table_struct


    ##############################################################
    # struct (
    #         device_name"  TEXT  NOT NULL PRIMARY KEY,
    #         device_type"  TEXT,
    #         mac"          TEXT     UNIQUE,
    #         ip"           TEXT      UNIQUE,
    #         bot_name"     TEXT,
    #         chat_id"      INTEGER UNIQUE,
    #         dhcp_action"  TEXT,
    #         leasetime"    TEXT,
    #         description"  TEXT
    #      )
    ##############################################################
    def sqlStruct_to_dict_type_01(self, sql_struct: str):
        fld_types = ["TEXT", "INTEGER", "BOOLEAN", "BLOB", "JSON" ]

        self.logger.caller(__name__)
        cmd, struct=sql_struct.split("(", 1)
        struct=struct.strip(")")
        struct=struct.replace(" NOT NULL", "NOT_NULL")
        struct=" ".join(struct.split()) ### elimina eventuali multiple blanks

        uniques=[]
        primary_keys=[]
        struct_dict=self._myDict()
        struct_dict["columns"] = self._myDict()

        for col_items in struct.split(","):
            field=shlex.split(col_items)

            col_name=field[0].lower()
            field=field[1:]

            struct_dict["columns"][col_name] = self._myDict()
            ptr=struct_dict["columns"][col_name]

            ptr['name'] = col_name
            ptr['type'] = "UNDEFINED"
            ptr["isUnique"] = False
            ptr["isPrimaryKey"] = False
            ptr["canBeNULL"] = False

            if "DEFAULT" in field:
                x = field.index("DEFAULT")
                if x >= 0:
                    ptr["DEFAULT"] = field[x+1]

            for item in field:
                if item in fld_types:
                    ptr['type']= item
                elif item == "UNIQUE":
                    ptr["isUnique"] = True
                elif item == "PRIMARY":
                    ptr["isPrimaryKey"] = True
                elif item == "NOT_NULL":
                    ptr["canBeNULL"] = True

        return struct_dict







    ###############################################################
    #  struct (
    #        broker_name     text NOT_NULL,
    #        url             text,
    #        port            integer,
    #        tls             integer,
    #        username        text,
    #        password        text,
    #        keepalive       integer,
    #        bind_address    text,
    #
    #        PRIMARY KEY  (name1, name3)
    #        UNIQUE  (name1, name2)
    #    );
    #   si può avere una primary_key unica composta da più colonne
    ###############################################################
    def sqlStruct_table_constraint_to_dict(self, sql_struct: str):
        self.logger.caller(__name__)
        fld_types = ["TEXT", "INTEGER", "BOOLEAN", "BLOB", "JSON" ]

        def getSubstring(data, lString, rString):
            pos1 = data.find(lString)
            if pos1>=0:
                pos2 = data.find(rString, pos1)
                found_data=data[pos1:pos2+1]
                rest_data = data[:pos1] + data[pos2+1:]
                # print(found_data)
                found_data = found_data.split("(")[1].split(")")[0]
                found_data = found_data.replace(",", " ")
            else:
                found_data = ""
                rest_data = data
            return found_data.split(), rest_data

        ### ---- defaults

        struct=sql_struct.split("(", 1)[1].rsplit(")", 1)[0] ### get data between first "(" and last ")"
        struct=" ".join(struct.split()) ### elimina eventuali multiple blanks

        ### get unique and primary_keys
        unique_cols, struct = getSubstring(data=struct, lString="UNIQUE", rString=")")
        pkeys_cols, struct  = getSubstring(data=struct, lString="PRIMARY KEY", rString=")")

        struct_dict=self._myDict()
        struct_dict["columns"] = self._myDict()

        items = struct.lower().split(",")
        for item in items:
            field=shlex.split(item)
            if not field: continue
            col_name=field[0]
            struct_dict["columns"][col_name] = self._myDict()
            ptr=struct_dict["columns"][col_name]

            ptr['type'] = "UNDEFINED"
            ptr["canBeNULL"] = False

            ptr['name']             = col_name
            ptr['isUnique']         = True if col_name in unique_cols else False
            ptr['isPrimaryKey']     = True if col_name in pkeys_cols else False

            ptr['canBeNULL'] = True
            ptr['defaultVAL'] = None
            for inx, word in enumerate(field):
                if word.upper() in fld_types:
                    ptr['type'] = word.upper()

                elif word in ["not", "null"]:
                    ptr['canBeNULL'] = False

                elif word == "DEFAULT":
                    ptr['defaultVAL']=field[x+1] # valore successivo

            # print(ptr.py())
        return struct_dict





    # ***********************************************
    # *
    # ***********************************************
    def getTableClass(self, table_name: str, *, struct: (str, dict)=None, create: bool=False, fStructValidation=True):
        self.logger.caller(__name__)

        tables=self.getTableList()
        if struct:
            if isinstance(struct, dict):
                sql_struct=self.dict_to_sqlStruct(d=struct) # convert in SQL string
            else:
                sql_struct = struct
        else:
            fStructValidation=False

        if create:
            self.createTable(table_name=table_name, struct=sql_struct, create=True)

        elif table_name not in tables:
            self.createTable(table_name=table_name, struct=sql_struct, create=True)

        elif table_name in tables:
            pass

        else:
            self.logger.error("table: %s not found in database", table_name)
            sys.exit(1)

        _table_class=SQLiteTable_Class.SQLiteTable_Class(DB=self, table_name=table_name)

            ### validation table struct
        if fStructValidation:
            self.logger.info("validation of table structure...")
            # struct_dict=self.sqlStruct_to_dict_type_01(sql_struct=sql_struct)
            struct_dict=self.sqlStruct_table_constraint_to_dict(sql_struct=sql_struct)
            struct_table=_table_class.readStruct()
            isOK=(struct_table==struct_dict)
            if isOK:
                self.logger.info("table [%s]: DB table structure is equal to expected structure", table_name)
            else:
                self.logger.error("table [%s]: DB table structure is NOT equal to expected structure", table_name)
                print(struct_table["columns"].keys())
                print(struct_dict["columns"].keys())
                sys.exit(1)

        return _table_class








    # ***********************************************
    # *
    # ***********************************************
    def _myDict(self, d: dict={}):
        self.logger.caller(__name__)
        if d:
            return benedict(d, keyattr_enabled=True, keyattr_dynamic=False)
            return dict(d)
        else:
            return benedict(keyattr_enabled=True, keyattr_dynamic=False)
            return dict()

    # ***********************************************
    # *
    # ***********************************************
    def _getCursor(self):
        self.logger.caller(__name__)
        return self.connection.cursor()


    # ***********************************************
    # *
    # ***********************************************
    def Close(self):
        self.logger.caller(__name__)
        # self.Commit()
        self.connection.close()



    # ***********************************************
    # *
    # ***********************************************
    def Commit(self):
        self.logger.caller(__name__)
        self.logger.info('Committing...')
        self.connection.commit()


    # ***********************************************
    # *
    # ***********************************************
    def getTableList(self):
        self.logger.caller(__name__)
        tableListQuery = "SELECT * FROM sqlite_master WHERE type='table' ORDER BY Name"
        cur = self._getCursor()
        cur.execute(tableListQuery)
        tables = cur.fetchall()
            # --- Get struct of Tables:
        _list=[]
        for table in tables:
            _list.append(table[1])
        return _list




    # ***********************************************
    # *
    # ***********************************************
    def Execute(self, command: str, *, fCOMMIT: bool=False, ignoreCase: bool=False, stacklevel: int=1) -> SimpleNamespace:
        self.logger.caller(__name__)
        saved_total_changes=self.connection.total_changes
        self.logger.debug("SQL_command: %s", command)
        ret=SimpleNamespace(
                rcode=0,
                cursor=None,
                data=None,
                total_changes=0)


        try:
            cur=self._getCursor()
            data=cur.execute(command)
            row_count=cur.rowcount
            rcode=0
            # self.logger.info('row count: %s', row_count)
            self.logger.debug('returned_data: %s', data)

        except (Exception) as why:
            self.logger.critical("%s: ... problem: %s", self.dbfilename, why, exc_info=True)
            ret.rcode=1
            ret.data=None
            self.total_errors+=1
            sys.exit(1)
            return ret

        ret=SimpleNamespace(
                rcode=rcode,
                cursor=cur,
                data=data,
                total_changes=self.connection.total_changes-saved_total_changes )

        if fCOMMIT and ret.rcode==0:
            self.Commit()
        return ret




    #######################################################
    # validKeys["pass_back"] pass any choice to back bat exitKeys
    #######################################################
    def keyb_prompt(self, *, text_msg: str, validKeys: list=["y", "n"], exitKeys: list=["x", "q"]):
        self.logger.caller(__name__)
        text_msg+= " - [" + '|'.join(exitKeys) + "]quit ->: "
        if "ENTER" in exitKeys  or "enter" in exitKeys: exitKeys.append("")
        if "ENTER" in validKeys or "enter" in validKeys: validKeys.append("")

        while True:
            choice=input(text_msg).lower()
            if choice in exitKeys: # diamo priorità all'uscita
                print("Exiting on user request.")
                sys.exit(0)

            elif choice in validKeys:
                break

            elif "pass_back" in validKeys:
                break

            else:
                print('\n... please enter some valid key:', validKeys, "or exit key:", exitKeys)

        return choice



        # ***********************************************
        # *
        # ***********************************************
    def Version(self, fPRINT=False):
        self.logger.caller(__name__)
        cur = self._getCursor()
        cur.execute('SELECT SQLITE_VERSION()')
        # version = cur.fetchone()
        version = f"SQLite version: {cur.fetchone()}"
        if fPRINT:
            print (version)

        return version
















##########################################################################
# https://github.com/borntyping/python-colorlog/blob/main/doc/example.py
##########################################################################
def setup_logger(logger_name: str="simple_logger", logger_level: str="info", colored=True):
    import logging

    my_levels={
        "critical": 50,
        "caller": 45,
        "error": 40,
        "notify": 33,
        "warning": 30,
        "function": 25,
        "info": 20,
        "debug": 10,
        "trace": 5,
        "notset": 0,
    }


    # --------- Adding NOTIFY level -------------------
    def addNotifyLevel(level):
        logging.NOTIFY=level
        def _notify(logger, message, *args, **kwargs):
            self.logger.caller(__name__)
            if logger.isEnabledFor(logging.NOTIFY):
                logger._log(logging.NOTIFY, message, args, **kwargs)
        logging.Logger.notify = _notify
        logging.addLevelName(logging.NOTIFY, "NOTIFY")
    # --------- Adding NOTIFY level -------------------

    # create logging formatter
    if colored:
        from colorlog import ColoredFormatter
        formatter = ColoredFormatter(
            "%(cyan)s%(asctime)s %(blue)s[%(module)s.%(funcName)s:%(lineno)4s] %(log_color)s[%(levelname)4s] : %(log_color)s%(message)s",
            datefmt="%H:%M:%S",
            reset=True,
            log_colors={
                'TRACE':    'blue',
                'DEBUG':    'cyan',
                'NOTIFY':   'fg_bold_cyan',
                'INFO':     'green',
                'FUNCTION': 'fg_bold_yellow',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CALLER':   'red',
                'CRITICAL': 'red,bg_white',
            },
        )


    else:
        formatter=logging.Formatter(
            fmt="%(asctime)s [%(module)s.%(funcName)s:%(lineno)4s] [%(levelname)4s] : %(message)s",
            datefmt="%H:%M:%S",
            style="%"
            )


    addNotifyLevel(level=my_levels["notify"])

    # create logger
    logger = logging.getLogger(logger_name)
    logger.setLevel("DEBUG")

    # create console handler
    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(formatter)
    consoleHandler.setLevel(logger_level.upper())

    # Add console handler to logger
    logger.addHandler(consoleHandler)

    logger.propagate = False # se messo a True mi trovo due righe di log, una colorata e l'altra no.

    return logger





def db_data():
    data=SimpleNamespace()



    data.struct="""
        columns:
            01_device_name:       TEXT  NOT NULL PRIMARY KEY
            02_device_type:       TEXT
            03_mac:               TEXT  UNIQUE
            04_ip:                TEXT  UNIQUE
            05_bot_name:          TEXT
            06_chat_id:           INTEGER UNIQUE
            07_dhcp_action:       TEXT
            08_leasetime:         TEXT
            09_tls:               BOOLEAN DEFAULT false
            09_dictionary:        BLOB
            10_description:       TEXT
        """

    data.records="""
            Crepuscolare:
                device_name:    Crepuscolare
                device_type:    tasmota
                mac:            DC:4F:22:BE:44:45
                ip:             192.168.1.114
                bot_name:       LnBot
                chat_id:        677540507
                dhcp_action:    reservation
                leasetime:      1h
                tls:            True
                dictionary:
                    ciao: uno
                    lista:
                        - uno
                        - due
                    dict1:
                        sub02:
                            - ciao1
                            - ciao2
                description:    ex_SonOff_Basic

    """




    data.db_filename="/home/loreto/Downloads/SQLite_test/test_01.db"
    data.table_name="SQLlite_test"

    return data

#################################################################
#   M   A   I   N
#################################################################

if __name__ == '__main__':
    from pathlib import Path
    import yaml



    # logger=setup_logger()
    logger=setColoredLogger(logger_name="sqlite_test",
                            console_logger_level="info",
                            file_logger_level="critical",
                            logging_dir=None, # no filehandler
                            threads=False,
                            create_logging_dir=False)

    logger.info('------- Starting -----------')

    '''
    ref: https://www.sqlitetutorial.net/sqlite-unique-constraint/
        UNIQUE constraint can have multiple NULL values.
        Primary keys must contain unique values. A primary key column cannot have NULL values.
    '''
    data=db_data()
    struct=yaml.load(data.struct, Loader=yaml.FullLoader)
    records=yaml.load(data.records, Loader=yaml.FullLoader)

        #================= open/create DB  ==================
    myDB=SQLiteDB_Class(db_filename=data.db_filename, create=False, logger=logger)
    myDB.Version(fPRINT=True)

    #================= open/create devicesDB table  ==================
    myTable=myDB.getTableClass(table_name=data.table_name, struct=struct)


    ### load table with devicesDB data
    for name, device in records.items():
        print(name)
        myTable.putRecord(new_record=device, fCOMMIT=True) ### ...working on this
    logger.notify("total changes: %s", myTable.totalChanges())

    rec=myTable.get_AllRecords(keyed_dict=True)
    import pdb; pdb.set_trace();trace=True # by Loreto
    rec=myTable.readRecord(whereString="device_name=Crepuscolare")
    logger.info("database: %s", myDB.dbfilename)

    myDB.Close(); sys.exit()
    sys.exit()