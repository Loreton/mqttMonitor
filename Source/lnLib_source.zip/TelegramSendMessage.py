#!/usr/bin/python3
#
# updated by ...: Loreto Notarantonio
# Date .........: 11-10-2023 16.37.16
#

import sys; sys.dont_write_bytecode = True
import os
import requests
import socket
from types import SimpleNamespace
import json, yaml
from pathlib import Path
import zipfile, io

try:    ### ref: https://realpython.com/python-yaml/#yaml-syntax
    from yaml import CSafeLoader as SafeLoader, CFullLoader as FullLoader
except ImportError:
    print('....no yaml C class')
    from yaml import SafeLoader, FullLoader

this=sys.modules[__name__]
this.filedata={}


#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    # gv.hostname=socket.gethostname().split()[0]


###############################################################
# group_name: if None {hostname}_channel will be used
###############################################################
def send___(tgData: dict, msg_text: str=None, caller=True):
    if caller:
        json_data=json.dumps({gv.hostname: {'msg': msg_text}}, indent=4, sort_keys=False)
        message=yaml.dump(yaml.load(json_data, Loader=FullLoader), indent=4, sort_keys=False, default_flow_style=False)

    elif isinstance(message, dict):
        json_data=json.dumps(msg_text, indent=4, sort_keys=False)
        message=yaml.dump(yaml.load(json_data, Loader=FullLoader), indent=4, sort_keys=False, default_flow_style=False)

    else:
        message=msg_text



    url = f'''https://api.telegram.org/bot{tgData.bot_token}/sendMessage?chat_id={tgData.chat_id}&text={message}'''
    gv.logger.info('     bot_name:   %s',   ttgData.bot_name)
    gv.logger.info('     group_name: %s',   tgData.name)
    gv.logger.info('     chat_id:    %s',   tgData.chat_id)

    if tgData.bot_name and tgData.bot_token:
        result=requests.get(url).json() # this sends the message
        gv.logger.notify(result)
    else:
        gv.logger.error('     command cannot be executed....missing some values!')




###############################################################
#
###############################################################
# def send_html(tg_group: dict, message: (dict, str), caller: bool=False, notify: bool=False):
    # assert isinstance(tg_group, dict)
def send_html(tg_group: (str, dict), message: (dict, str), caller: bool=False, notify: bool=False):
    assert isinstance(tg_group, (dict))
    # if isinstance(tg_group, dict):
    #     pass
    # else:
    #     tg_group=gv.devicesDB.getDeviceInstance(dev_name=tg_group)


    ns=SimpleNamespace()
    ns.italicB="<i>"
    ns.italicE="</i>"
    ns.boldB="<b>"
    ns.boldE="</b>"
    ns.sQ="'"
    ns.dQ='"'

    ### ---------------------------------------------
    def html_parse_mode(message: str):
        parse_mode='&parse_mode=HTML'
        message=message.replace(ns.sQ, '')
        message=message.replace(ns.dQ, '')

        if caller:
            message=f"from: {ns.italicB}{ns.boldB}{gv.hostname}{ns.boldE}{ns.italicE}\nname: {ns.boldB}{ns.italicB}{tg_group.name}{ns.italicE}{ns.boldE}\n\n{message}" # italic + bold

        return message, parse_mode
    ### ---------------------------------------------

    if tg_group.bot_name and tg_group.bot_token and tg_group.chat_id:

        ### -----------------------------
        ### serve a mettere le main key in bold
        ### si può toglere se serve
        if isinstance(message, dict):
            keys=list(message.keys())
            message=yaml.dump(message, indent=4, sort_keys=False, default_flow_style=False)

        else:
            parse_mode=None
            keys=[]

        for key in keys:
            message=message.replace(key, f'{ns.boldB}{key}{ns.boldE}')
        ### -----------------------------

        notification=f"&disable_notification={not notify}"

        gv.logger.notify('     message:    %s',   message)
        message, parse_mode=html_parse_mode(message=message)

        ### non l'ho ancora ben capito ma ci deve essere qualche problema con gli apici all'interno del messaggio ed il parse mode....
        if ns.sQ in message or ns.dQ in message:
            parse_mode=''



        url=f"https://api.telegram.org/bot{tg_group.bot_token}/sendMessage?chat_id={tg_group.chat_id}&text={message}{parse_mode}{notification}"
        gv.logger.info('     bot_name:   %s',   tg_group.bot_name)
        gv.logger.info('     group_name: %s',   tg_group.name)
        gv.logger.info('     chat_id:    %s',   tg_group.chat_id)
        gv.logger.notify('     message with tags:    %s',   message)


        try:
            response=requests.get(url).json()
            ### response: {'ok': False, 'error_code': 400, 'description': "Bad Request: can't parse entities: Can't find end of the entity starting at byte offset 493"}
            ### esponse: {'ok': True, 'result': {'messag....
            if response['ok']:
                gv.logger.info('   response: %s',   response)
            else:
                gv.logger.error('   response: %s',   response)
                gv.logger.caller('url:  %s',   url, stacklevel=1)


        except (Exception) as ex:
            gv.logger.error('     exception:   %s',   str(ex))

    else:
        gv.logger.error('command cannot be executed....missing some values!')
        _d=benedict(tg_group, keyattr_enabled=True, keyattr_dynamic=False)
        gv.logger.error('bot data: %s',   _d.to_json())






#################################
#
#################################
def setupLogger():
    import logging
    logging.basicConfig(level=logging.DEBUG,
                        format='[%(levelname)4s] - [%(module)s.%(funcName)s:%(lineno)4s]: %(message)s',
                        )

    logger = logging.getLogger('example_logger')
    return logger


###############################################
#
###############################################
if __name__ == '__main__':
    logger=setupLogger()
    ### - get application info from deviceDB
    if (appl_device := gv.devicesDB.getDeviceInstance(dev_name=gv.tg_group_name)):
        assert appl_device.type=="application"
        appl_tg=appl_device.tg
    else:
        self-logger.error("%s NOT found in devicesDB.", gv.tg_group_name)
        sys.exit(1)

    TSM.send_html(tg_group=appl_device.tg, message="application has been started!", caller=True, notify=True)
