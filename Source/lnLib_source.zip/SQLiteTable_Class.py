#!/usr/bin/env python3
#!/usr/bin/env python3
# -*- coding: iso-8859-15 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 08-07-2024 18.42.48
#
# ####################################################################################################################

import  sys; sys.dont_write_bytecode=True
import os
from types import SimpleNamespace
import pickle
import base64
from pathlib import Path
import json
import   shlex

import collections
from benedict import benedict

INFO = 1



#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.logger.caller(__name__)





##################################################################################################
##################################################################################################
##################################################################################################
# tableClasse
# tableClasse
# tableClasse
##################################################################################################
##################################################################################################
##################################################################################################

class SQLiteTable_Class():
    profile="Tabella"

    def __init__(self, *, DB, table_name: str):
        # super().__init__(db_filename=db_filename, logger=logger, create=create)

        self.db=DB
        self.logger=DB.logger
        self.logger.caller(__name__)
        self.total_errors=0
        self.total_changes=0
        self.list_prefix="_isList_"

        # self.req_primary_keys=primary_keys

        ### impostazione caratteristiche della tabella
        self.table_name=table_name


        self.struct_dict  = self.readStruct()
        self.column_names = self.struct_dict.columns.keys()
        ptr=self.struct_dict.columns

        self.primary_keys = [c for c in self.column_names if ptr[c].isPrimaryKey]
        self.uniques = [c for c in self.column_names if ptr[c].isUnique]






    ##############################################################
    #  return example:
    #  col_name:
    #      name:            description
    #      isUnique:        false
    #      isPrimaryKey:    false
    #      canBeNULL:       true
    #      defaultVAL:      null
    #      type:            TEXT
    ##############################################################
    def readStruct(self) -> dict:
        self.logger.caller(__name__)

        ### get create table command
        ret=self.sqlExecute(f"""SELECT sql FROM sqlite_master WHERE name = '{self.table_name}';""")
        sql_struct=ret.cursor.fetchone()[0]
        ### convert it to dictionary
        return self.db.sqlStruct_table_constraint_to_dict(sql_struct)





        # ###################################################################
        # readRecord()
        #   - whereString example "ip not null"
        #   - legge il record
        #   - converte il record in dictionary
        #   - deserializza i vari campi ...se necessario
        # -
        #   - ritorna il record identificato dal whereString
        # ###################################################################
    def selectRecords(self, where: str=None, keyed_dict=False, expected_records: int=-1) -> (list, dict):
        self.logger.caller(__name__)

        # sql_command=f'SELECT * from {self.table_name} WHERE {whereString} COLLATE NOCASE'
        if where:
            sql_command=f'SELECT * from {self.table_name} WHERE {where}'
        else:
            sql_command=f'SELECT * from {self.table_name}'
        ret=self.sqlExecute(sql_command)
        if ret.rcode == 0:
            records=ret.cursor.fetchall()

            n_records = len(records)

            if  expected_records != -1:
                if  n_records == expected_records:
                    pass
                elif n_records == 0:
                    self.logger.warning("NO records found: %s", n_records)
                    records={}
                else:
                    self.logger.warning("records found: %s - EXPECTED: %s", n_records, expected_records)

            return self.recordsToDict(records=records, cursor_description=ret.cursor.description, keyed_dict=keyed_dict)
        else:
            return []





        # ###################################################################
        # readRecord()
        #   - legge il record
        #   - converte il record in dictionary
        #   - deserializza i vari campi ...se necessario
        #   - ritorna il record
        # -
        #   - ritorna il record identificato dal whereString
        # ###################################################################
    def getRecord(self, where: str, expected_records: int=1) -> dict:
        self.logger.caller(__name__)
        records = self.selectRecords(where=where, keyed_dict=False, expected_records=expected_records)
        return records[0] if records else {}








        # ###################################################################
        #   input: list of records
        #   - deserializza le varie colonne ...se necessario
        #   - converte il record in dictionary
        #   - ritorna il dict_record(s) oppure list_of_records[]
        # ###################################################################
    def recordsToDict(self, records: list, cursor_description, keyed_dict: bool=False) -> (list, dict):
        self.logger.caller(__name__)
        pri_key=self.primary_keys[0]
        list_of_records=[]
        dict_of_records={}

        """https://copyprogramming.com/howto/sqlite-and-python-return-a-dictionary-using-fetchone"""
        for row in records:
            d=dict(zip([c[0] for c in cursor_description], row))
            record=self.record_deserialize(d)

            record=benedict(record, keyattr_enabled=True, keyattr_dynamic=False)
            self.logger.debug(record)

            if keyed_dict:
                key=record[pri_key]
                dict_of_records[key]=record
            else:
                list_of_records.append(benedict(record, keyattr_enabled=True, keyattr_dynamic=False))


        ### - return data
        if keyed_dict:
            return benedict(dict_of_records, keyattr_enabled=True, keyattr_dynamic=False)

        return list_of_records


        # ###################################################################
        # - per ogni campo del record cerca di capire se deve essere
        # - de-serializzato o mneo
        # ###################################################################
    def record_deserialize(self, record: dict) -> SimpleNamespace:
        self.logger.caller(__name__)

            # ================================================
            # -----------------------------------------------
        def deserialize_field_data(colname, data):
            value=data
            if data:
                ptr = self.struct_dict["columns"][colname]

                if not "type" in ptr.keys():
                    print("type key non esiste per la col:", colname)
                    print("value", value)
                    import pdb; pdb.set_trace();trace=True # by Loreto
                    return value

                col_type=ptr["type"]
                if col_type in ["JSON"]:
                    value=self.JSON(data, deserialize=True)

                elif col_type in ["BLOB"]:
                    value=self.BLOB(data, deserialize=True)

                elif col_type in ["BOOLEAN"]:
                    value=self.BOOLEAN(data)

                elif col_type in ["TEXT"]:
                    value=self.TEXT(data, deserialize=True)

            return value
            # -----------------------------------------------
            # ================================================

        _rec={}
        for colname in record.keys():
            value=record[colname]
            value=deserialize_field_data(colname=colname, data=value)
            _rec[colname]=value
        return self.db._myDict(_rec)









        # ###################################################################
        # - ritorna tutti i records della tabella
        # ###################################################################
    def get_AllRecords(self, keyed_dict: bool=False) -> (list, dict):
        self.logger.caller(__name__)

        ret=self.db.Execute(f'SELECT * from {self.table_name}')
        records=ret.cursor.fetchall()
        self.logger.info("Total rows are:  %s", len(records))

        list_of_dict=self.recordsToDict(records=records, cursor_description=ret.cursor.description, keyed_dict=False)

        if keyed_dict:
            pri_key=self.primary_keys[0]

            _dict=benedict(keyattr_enabled=True, keyattr_dynamic=False)
            for record in list_of_dict:
                key=record[pri_key]
                _dict[key]=record

            return _dict

        return list_of_dict # default [{}, {}, ...]




        # ###################################################################
        # - Inserisce una riga (se non esiste) oppure fa update
        # - tested:  27-02-2024
        # - 1. fUpdate==True  se il rec esiste
        # - 1. fUpdate==False se il rec non esiste
        # ###################################################################
    # def insertUpdateRow(self, new_record, insert: bool=False, fCOMMIT: bool=False) -> int:
    def putRecord(self, new_record, fCOMMIT: bool=False) -> int:
        self.logger.caller("%s %s", __name__, self.table_name)
        self.logger.debug('New_Record: %s', new_record.toJson())
        whereString=self.PK_whereClause(new_record)

        cur_record: dict=self.getRecord(where=whereString, expected_records=1) # read current record - ritorna deserializzato


        ret: SimpleNamespace = self.prepareWriteData(new_record=new_record, cur_record=cur_record) # return setString, cols() and values()


        if not cur_record:
            fUpdate = False
        elif cur_record and ret.is_there_json_field:
            fUpdate = False # False indica INSERT
            """ purtroppo con i dati json, non mi funziona l'update (a meno che non lo metto in BLOB)
                pertanto dovrò forzare INSERT or REPLACE """
        else:
            fUpdate = True


        rcode=0


        # if new_record.broker_name=="ecplise":
        #     import pdb; pdb.set_trace();trace=True # by Loreto
        if fUpdate:
            # import pdb; pdb.set_trace();trace=True # by Loreto
            if ret.set == "":
                self.logger.info("table: [%s] where [%s] - no update needs", self.table_name, whereString)
                return 0

            self.logger.debug('Curr_Record: %s', cur_record.toYaml())
            # self.logger.notify("table: [%s] - updating record WHERE: %s", self.table_name, whereString)
            sql_command=f'UPDATE {self.table_name} SET {ret.set} WHERE {whereString};'
            self.logger.notify("table: [%s] - updating record sql_command: %s", self.table_name, sql_command)
            rc: SimpleNamespace = self.sqlExecute(sql_command, fCOMMIT=fCOMMIT)
            if rc.rcode>0:
                self.logger.error("%s: problems updating record", self.table_name)
                rcode=1

        else: # INSERT
            # import pdb; pdb.set_trace();trace=True # by Loreto
            if (len(ret.cols) == 0):
                self.logger.info("table: [%s] where [%s] - no update needs", self.table_name, whereString)
                return 0
            self.logger.notify("table: [%s] - inserting record WHERE: %s", self.table_name, whereString)
            sql_command = f'INSERT OR REPLACE into {self.table_name} {ret.cols} VALUES {ret.values};'
            rc: SimpleNamespace = self.sqlExecute(sql_command, fCOMMIT=fCOMMIT)
            if rc.rcode>0:
                rcode=1
                self.logger.error("table: [%s] - problems inserting/replacing record", self.table_name)
                import pdb; pdb.set_trace();trace=True # by Loreto

        return rcode





        ############################################################
        # covert dict to json
        ############################################################
    def JSON(self, data: dict, deserialize: bool=False) -> str:
        if deserialize:
            if data:
                return json.loads(data)
            return None
        else:
            return json.dumps(data)




        ############################################################
        # covert dict to json
        ############################################################
    def BOOLEAN(self, data: dict, deserialize: bool=False) -> str:
        value=False if int(data)==0 else True
        return value




    def TEXT(self, data: (str, list), deserialize: bool=False) -> (list, str):
        item_separator="__sep__"
        item_separator=", "
        list_prefix="_isList_"
        if deserialize:
            if data.startswith(list_prefix):
                data=data[len(list_prefix):].split(item_separator) ### return list
        else:
            if isinstance(data, list): ### put LIST prefix
                data=list_prefix + item_separator.join(data)

        return data


        ############################################################
        # covert data to base64
        # inserisce un prefisso con il datatype del dato che verrà
        #   rimosso nella fase di deserializzazione
        ############################################################
    def BLOB(self, data, deserialize: bool=False):
        encoding = "utf-8"

        if deserialize:
            _data=pickle.loads(base64.b64decode(data.encode(encoding)))
            data_type, _data=_data.split("__", 1)
            if data_type == "dict":
                _data=self.db._myDict(_data)

            return _data
        else:
            data_type=type(data).__name__

            _data=f"{data_type}__" + self.JSON(data, deserialize=False)
            return base64.b64encode(pickle.dumps(_data)).decode(encoding)




    '''
        # ###################################################################
        # - per ogni campo del record cerca di capire se deve essere
        # - serializzato o mneo
        # ###################################################################
    def record_serialize(self, record: dict) -> SimpleNamespace:
        self.logger.caller(__name__)

            # ================================================
            # -----------------------------------------------
        def serialize_field_data(colname, data):
            data_type=type(data).__name__
            col_type=self.struct_dict["columns"][colname]["type"]
            value = data
            if data:
                if data_type ==  "str":
                    if data.lower() in ["null", "-"]:
                        return None

                if col_type == "JSON":
                    value = self.JSON(data, deserialize=False)

                elif col_type == "BLOB":
                    value = self.BLOB(data, deserialize=False)

                elif col_type == "INTEGER":
                    value = int(data)

                elif col_type == "BOOLEAN":
                    value=self.BOOLEAN(data)

                elif col_type == "TEXT":
                    if data_type == "list":
                        value = self.TEXT(data, deserialize=False)

            return value

            # -----------------------------------------------
            # ================================================

        ser_rec={}
        for colname in record.keys():
            if colname in self.column_names:
                value=record[colname]
                value=serialize_field_data(colname=colname, data=value)
                ser_rec[colname]=value

        return self.db._myDict(ser_rec)
    '''


    ##############################################################
    # # Prepara il record per la scrittura
    ##############################################################
    def prepareWriteData(self, new_record: dict, cur_record: dict):


        # ================================================
        # -----------------------------------------------
        def serialize_field_data(colname, data):

            data_type=type(data).__name__
            col_type=self.struct_dict["columns"][colname]["type"]
            value = data
            if data:
                if data_type ==  "str":
                    if data.lower() in ["null", "-"]:
                        return None

                if data_type ==  "list":
                    value = self.TEXT(data, deserialize=False)

                elif col_type == "JSON":
                    value = self.JSON(data, deserialize=False)

                elif col_type == "BLOB":
                    value = self.BLOB(data, deserialize=False)

                elif col_type == "INTEGER":
                    value = int(data)

                elif col_type == "BOOLEAN":
                    value=self.BOOLEAN(data)

            return value

        # -----------------------------------------------
        def areEquals(new_val, cur_val):
            fEquals=False
            if col_type == "INTEGER":
                if new_val:
                    new_val = int(new_val)

            if new_val == cur_val:
                fEquals = True

            return fEquals

        # ================================================


        self.logger.caller(__name__)
        insert_cols, insert_values, update_set, whereList=[], [], [], []
        is_there_json_field=False

        if not cur_record == new_record:
            for col_name in self.column_names:
                if col_name == "maczz":
                    import pdb; pdb.set_trace();trace=True # by Loreto
                if col_name in new_record:
                    col_type=self.struct_dict["columns"][col_name]["type"]
                    value=new_record[col_name]
                    if value in [[], {}, ()]: # nel db lo inseriamo come null
                        value = None
                    if cur_record:
                        if areEquals(new_val=value, cur_val=cur_record[col_name]):
                            continue

                    value_ser=None
                    if value is None:
                        value_ser=None
                        string=f'"{col_name.strip()}"=NULL'

                    elif isinstance(value, bool):
                        value_ser=1 if value is True else 0
                        string=f'"{col_name.strip()}"="{int(value_ser)}"'

                    elif col_type == "INTEGER":
                        string=f'"{col_name.strip()}"="{int(value)}"'
                        value_ser=int(value)

                    elif value:
                        value_ser=serialize_field_data(col_name, value)
                        string=f'"{col_name.strip()}"="{value_ser}"'

                    else:
                        continue

                    update_set.append(string)

                    if value_ser: # @changed:  27-06-2024
                        insert_values.append(value_ser)
                        insert_cols.append(col_name)

                    if col_name in self.primary_keys:
                        whereList.append(string)
                    if col_type == "JSON":
                        is_there_json_field=True


        ret=SimpleNamespace()
        ret.where               = ' and '.join(whereList)
        ret.set                 = ', '.join(update_set)
        ret.cols                = tuple(insert_cols)
        ret.values              = tuple(insert_values)
        ret.is_there_json_field = is_there_json_field
        return ret




        # ###################################################################
        # - Creiamo una WHERE clause con i nomi delle primary_keys ed il record
        # - SELECT * FROM table where name = "xxxx" ;
        # ###################################################################
    def PK_whereClause(self, record):
        self.logger.caller(__name__)
        whereList=[]
        nulls=0
        for col_name in self.primary_keys:
            if col_name in record.keys():
                value=record[col_name]
                # if not value or value.lower() in ["null", "-"]:
                if value:
                    string=f'"{col_name.strip()}"="{value}"'
                else:
                    string = f"{col_name.strip()} is NULL"
                    nulls += 1
                whereList.append(string)

        whereString = ' and '.join(whereList)

        if nulls >= len(self.primary_keys): # 03-05-2024
            whereString = None
            self.logger.critical("impossibile creare la WHERE String in quanto tutte le primaryKeys sono NULL")
            import pdb; pdb.set_trace();trace=True # by Loreto
            sys.exit(1)

        return whereString






    ##############################################################
    # #
    ##############################################################
    def getStruct(self):
        self.logger.caller(__name__)
        return self.struct_dict

    ##############################################################
    # #
    ##############################################################
    def columnNames(self):
        self.logger.caller(__name__)
        return self.column_names

    ##############################################################
    # #
    ##############################################################
    def primaryKeys(self):
        self.logger.caller(__name__)
        return self.primary_keys


    ##############################################################
    # #
    ##############################################################
    def totalChanges(self):
        return self.total_changes


    ##############################################################
    # #
    ##############################################################
    def totalErrors(self):
        return self.total_errors


    ##############################################################
    # #
    ##############################################################
    def sqlExecute(self, command: str, **kwargs):
        ret: SimpleNamespace = self.db.Execute(command=command, **kwargs)
        if ret.rcode:
            self.total_errors+=1
        self.total_changes+=ret.total_changes
        return ret



    # ***********************************************
    # *
    # ***********************************************
    def Commit(self):
        self.db.Commit()
