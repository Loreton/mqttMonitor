#!/usr/bin/python
#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 17-05-2024 09.43.49
#
# ####################################################################################################################

import  sys; sys.dont_write_bytecode=True
import os
from types import SimpleNamespace
import pickle
import base64
from pathlib import Path
import json
import   shlex

import collections
from benedict import benedict

INFO = 1



#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.logger.info('Entering in function...')





##################################################################################################
##################################################################################################
##################################################################################################
# tableClasse
# tableClasse
# tableClasse
##################################################################################################
##################################################################################################
##################################################################################################

class SQLiteTable_Class():
    profile="Tabella"

    def __init__(self, *, DB, table_name: str):
        # super().__init__(db_filename=db_filename, logger=logger, create=create)

        self.db=DB
        self.logger=DB.logger
        self.logger.caller('Entering in function...')
        self.total_errors=0
        self.total_changes=0
        self.list_prefix="_isList_"

        # self.req_primary_keys=primary_keys

        ### impostazione caratteristiche della tabella
        self.table_name=table_name


        self.struct_dict  = self.readStruct()
        self.column_names = self.struct_dict.columns.keys()
        ptr=self.struct_dict.columns

        self.primary_keys = [c for c in self.column_names if ptr[c].isPrimaryKey]
        self.uniques = [c for c in self.column_names if ptr[c].isUnique]






    ##############################################################
    #  return example:
    #  col_name:
    #      name:            description
    #      isUnique:        false
    #      isPrimaryKey:    false
    #      canBeNULL:       true
    #      defaultVAL:      null
    #      type:            TEXT
    ##############################################################
    def readStruct(self) -> dict:
        self.logger.caller('Entering in function...')

        ### get create table command
        ret=self.sqlExecute(f"""SELECT sql FROM sqlite_master WHERE name = '{self.table_name}';""")
        sql_struct=ret.cursor.fetchone()[0]
        ### convert it to dictionary
        return self.db.sqlStruct_table_constraint_to_dict(sql_struct)





        # ###################################################################
        # readRecord()
        #   - whereString example "ip not null"
        #   - legge il record
        #   - converte il record in dictionary
        #   - deserializza i vari campi ...se necessario
        # -
        #   - ritorna il record identificato dal whereString
        # ###################################################################
    def selectRecords(self, where: str=None, keyed_dict=False, expected_records: int=-1) -> dict:
        self.logger.caller('Entering in function...')

        # sql_command=f'SELECT * from {self.table_name} WHERE {whereString} COLLATE NOCASE'
        if where:
            sql_command=f'SELECT * from {self.table_name} WHERE {where}'
        else:
            sql_command=f'SELECT * from {self.table_name}'
        ret=self.sqlExecute(sql_command)
        if ret.rcode == 0:
            records=ret.cursor.fetchall()

            n_records = len(records)

            if  expected_records != -1:
                if  n_records == expected_records:
                    pass
                elif n_records == 0:
                    self.logger.warning("NO records found: %s", n_records)
                    records={}
                else:
                    self.logger.warning("records found: %s - EXPECTED: %s", n_records, expected_records)

            return self.recordsToDict(records=records, cursor_description=ret.cursor.description, keyed_dict=keyed_dict)
        else:
            return {}





        # ###################################################################
        # readRecord()
        #   - legge il record
        #   - converte il record in dictionary
        #   - deserializza i vari campi ...se necessario
        #   - ritorna il record
        # -
        #   - ritorna il record identificato dal whereString
        # ###################################################################
    def getRecord(self, where: str) -> dict:
        self.logger.caller('Entering in function...')
        records = self.selectRecords(where=where, keyed_dict=False, expected_records=1)
        return records[0] if records else {}





        # ###################################################################
        #   input: list of records
        #   - deserializza le varie colonne ...se necessario
        #   - converte il record in dictionary
        #   - ritorna il dict_record(s) oppure list_of_records[]
        # ###################################################################
    def recordsToDict(self, records: list, cursor_description, keyed_dict: bool=False) -> (list, dict):
        self.logger.caller('Entering in function...')
        pri_key=self.primary_keys[0]
        list_of_records=[]
        dict_of_records={}

        """https://copyprogramming.com/howto/sqlite-and-python-return-a-dictionary-using-fetchone"""
        for row in records:
            d=dict(zip([c[0] for c in cursor_description], row))
            record=self.record_deserialize(d)

            record=benedict(record, keyattr_enabled=True, keyattr_dynamic=False)
            self.logger.debug(record)

            if keyed_dict:
                key=record[pri_key]
                dict_of_records[key]=record
            else:
                list_of_records.append(benedict(record, keyattr_enabled=True, keyattr_dynamic=False))


        ### - return data
        if keyed_dict:
            return benedict(dict_of_records, keyattr_enabled=True, keyattr_dynamic=False)

        return list_of_records







        # ###################################################################
        # - ritorna tutti i records della tabella
        # ###################################################################
    def get_AllRecords(self, keyed_dict: bool=False) -> (list, dict):
        self.logger.caller('Entering in function...')

        ret=self.db.Execute(f'SELECT * from {self.table_name}')
        records=ret.cursor.fetchall()
        self.logger.info("Total rows are:  %s", len(records))

        list_of_dict=self.recordsToDict(records=records, cursor_description=ret.cursor.description, keyed_dict=False)

        if keyed_dict:
            pri_key=self.primary_keys[0]

            _dict=benedict(keyattr_enabled=True, keyattr_dynamic=False)
            for record in list_of_dict:
                key=record[pri_key]
                _dict[key]=record

            return _dict

        return list_of_dict # default [{}, {}, ...]









        # ###################################################################
        # - Inserisce una riga (se non esiste) oppure fa update
        # - tested:  27-02-2024
        # ###################################################################
    def insertUpdateRow(self, new_record, insert: bool=False, fCOMMIT: bool=False) -> int:
        self.logger.caller('%s: Entering in function...', self.table_name)
        self.logger.debug('New_Record: %s', new_record.toYaml())
        whereString=self.PK_whereClause(new_record)

        rcode=0
        # read current record - ritorna deserializzato
        cur_record: dict=self.getRecord(where=whereString)

        # compare cur<>new and extract cols with different value (entrambi deserializzati)
        diff_cols: list=self.records_diff(new_record=new_record, cur_record=cur_record)

        # serialize new record
        ser_new_record: dict=self.record_serialize(record=new_record)

        # return setString, cols() and values()
        ret: SimpleNamespace = self.prepareWriteData(record=ser_new_record, diff_cols=diff_cols)

        if cur_record:
            self.logger.debug('Curr_Record: %s', cur_record.toYaml())
            if insert:
                self.logger.error("table: [%s] - key %s already exists.", self.table_name, whereString)
                return 1

            if ret.new_data:
                """
                    purtroppo con i dati json, non mi funziona l'update (a meno che non lo metto in BLOB)
                    ... pertanto dovrò forzare INSERT or REPLACE
                """
                if ret.is_there_json_field:
                    ret: SimpleNamespace = self.prepareWriteData(record=ser_new_record, diff_cols=self.column_names) ### ritorna tutti i campi
                    sql_command=f'INSERT or REPLACE into {self.table_name} {ret.cols} VALUES {ret.values};'
                    action="replacing"
                else:
                    sql_command=f'UPDATE {self.table_name} SET {ret.set} WHERE {whereString};'
                    action="updating"

                self.logger.warning("table: [%s] - %s record WHERE: %s", self.table_name, action, whereString)
                rc: SimpleNamespace = self.sqlExecute(sql_command, fCOMMIT=fCOMMIT)
                if rc.rcode>0:
                    self.logger.error("%s: problems inserting record", self.table_name)
                    rcode=1

            else:
                self.logger.info("table: [%s] - no needs for update", self.table_name)

        else:

            self.logger.warning("table: [%s] - inserting record WHERE: %s", self.table_name, whereString)
            sqlCommand = f'INSERT into {self.table_name} {ret.cols} VALUES {ret.values};'
            rc: SimpleNamespace = self.sqlExecute(sqlCommand, fCOMMIT=fCOMMIT)
            if rc.rcode>0:
                rcode=1
                self.logger.error("table: [%s] - problems inserting record", self.table_name)
                import pdb; pdb.set_trace();trace=True # by Loreto

        return rcode





        ############################################################
        # covert dict to json
        ############################################################
    def JSON(self, data: dict, deserialize: bool=False) -> str:
        if deserialize:
            if data:
                return json.loads(data)
            return None
        else:
            return json.dumps(data)




        ############################################################
        # covert dict to json
        ############################################################
    def BOOLEAN(self, data: dict, deserialize: bool=False) -> str:
        value=False if int(data)==0 else True
        return value





        ############################################################
        # covert json to dict
        ############################################################
    # def json_deserialize(self, data: dict) -> dict:
    #     if data:
    #         return json.loads(data)
    #     return None

        ############################################################
        # covert json to dict
        ############################################################
    # def text_deserialize(self, data: dict) -> dict:
    #     if data:
    #         if data.startswith("list__"):
    #             data=list(data[6:])
    #     return data

        ############################################################
        # serialize list or deselialize __list__(str)
        ############################################################
    # def list_de_serialize(self, data: (str, list), deserialize: bool=False, serialize: bool=False) -> (str, list):
    #     item_separator="__item_sep__"
    #     item_separator=", "

    #     if isinstance(data, str):
    #         data=data[len(self.list_prefix):].split(item_separator)
    #     elif isinstance(data, list):
    #         data=self.list_prefix + item_separator.join(data)

    #     return data

    def TEXT(self, data: (str, list), deserialize: bool=False) -> (list, str):
        item_separator="__sep__"
        item_separator=", "
        list_prefix="_isList_"
        if deserialize:
            if data.startswith(list_prefix):
                data=data[len(list_prefix):].split(item_separator) ### return list
        else:
            if isinstance(data, list): ### put LIST prefix
                data=list_prefix + item_separator.join(data)

        return data


        ############################################################
        # covert base64 to real data
        ############################################################
    # def _pickle_deserialize(self, data):
    #     encoding = "utf-8"
    #     _data=pickle.loads(base64.b64decode(data.encode(encoding)))
    #     data_type, _data=_data.split("__", 1)
    #     if data_type == "dict":
    #         _data=self.db._dictType(_data)

    #     return _data

        ############################################################
        # covert data to base64
        # inserisce un prefisso con il datatype del dato che verrà
        #   rimosso nella fase di deserializzazione
        ############################################################
    def BLOB(self, data, deserialize: bool=False):
        encoding = "utf-8"

        if deserialize:
            _data=pickle.loads(base64.b64decode(data.encode(encoding)))
            data_type, _data=_data.split("__", 1)
            if data_type == "dict":
                _data=self.db._dictType(_data)

            return _data
        else:
            data_type=type(data).__name__

            _data=f"{data_type}__" + self.JSON(data, deserialize=False)
            return base64.b64encode(pickle.dumps(_data)).decode(encoding)





        # ###################################################################
        # - per ogni campo del record cerca di capire se deve essere
        # - serializzato o mneo
        # ###################################################################
    def record_serialize(self, record: dict) -> SimpleNamespace:
        self.logger.caller('Entering in function...')

            # ================================================
            # -----------------------------------------------
        def serialize_field_data(colname, data):
            data_type=type(data).__name__
            col_type=self.struct_dict["columns"][colname]["type"]
            value = data
            if data:
                if data_type ==  "str":
                    if data.lower() in ["null", "-"]:
                        return None

                if col_type == "JSON":
                    value = self.JSON(data, deserialize=False)

                elif col_type == "BLOB":
                    value = self.BLOB(data, deserialize=False)

                elif col_type == "INTEGER":
                    # print(data)
                    # if data in ["None"]:
                    #     import pdb; pdb.set_trace();trace=True # by Loreto
                    #     value = None
                    # else:
                        value = int(data)

                elif col_type == "BOOLEAN":
                    value=self.BOOLEAN(data)

                elif col_type == "TEXT":
                    if data_type == "list":
                        value = self.TEXT(data, deserialize=False)


            return value
            # -----------------------------------------------
            # ================================================

        ser_rec={}
        for colname in record.keys():
            if colname in self.column_names:
                value=record[colname]
                value=serialize_field_data(colname=colname, data=value)
                ser_rec[colname]=value

        return self.db._dictType(ser_rec)


        # ###################################################################
        # - per ogni campo del record cerca di capire se deve essere
        # - de-serializzato o mneo
        # ###################################################################
    def record_deserialize(self, record: dict) -> SimpleNamespace:
        self.logger.caller('Entering in function...')

            # ================================================
            # -----------------------------------------------
        def deserialize_field_data(colname, data):
            value=data
            if data:
                ptr = self.struct_dict["columns"][colname]

                if not "type" in ptr.keys():
                    print("type key non esiste per la col:", colname)
                    print("value", value)
                    import pdb; pdb.set_trace();trace=True # by Loreto
                    return value

                col_type=ptr["type"]
                if col_type in ["JSON"]:
                    value=self.JSON(data, deserialize=True)

                elif col_type in ["BLOB"]:
                    value=self.BLOB(data, deserialize=True)

                elif col_type in ["BOOLEAN"]:
                    value=self.BOOLEAN(data)

                elif col_type in ["TEXT"]:
                    value=self.TEXT(data, deserialize=True)

            return value
            # -----------------------------------------------
            # ================================================

        _rec={}
        for colname in record.keys():
            value=record[colname]
            value=deserialize_field_data(colname=colname, data=value)
            _rec[colname]=value
        return self.db._dictType(_rec)








        ##############################################################
        # # Cerca di individuare tutte le colonne del nuovo record
        # # che hanno un valore diverso dal corrente record.
        ##############################################################
    def records_diff(self, new_record: dict, cur_record: dict={}) -> list:
        self.logger.caller('Entering in function...')
        if not cur_record:
            return self.column_names

        #=================================================================
        def are_equals(colname, cfield, nfield) -> bool:
            col_type=self.struct_dict["columns"][colname]["type"]
            are_eq=False

            # if colname=="chat_id":
            #     print(cfield)
            #     print(nfield)
            #     import pdb; pdb.set_trace();trace=True # by Loreto

            if cfield is None or nfield is None: # uno è None
                are_eq=True

            elif col_type in ["INTEGER", "BOOLEAN"]:
                try:
                    are_eq=int(cfield) == int(nfield)
                except:
                    self.logger.error("colname: %s - cfield: [%s] - nfield: [%s] one or both are not integer", colname, cfield, nfield)
                    import pdb; pdb.set_trace();trace=True # by Loreto

            elif cfield and nfield:
                are_eq=cfield == nfield

            elif cfield and nfield is None: # uno è None
                are_eq=False

            elif cfield is None and nfield: # uno è None
                are_eq=False



            if are_eq:
                self.logger.debug('columns named %s are equals: %s', colname, are_eq)
            else:
                self.logger.warning('columns named %s are not equals:\n    cur_record: %s\n    new_record: %s', colname, cfield, nfield)

            return are_eq
        #=================================================================


        diff_cols=[]
        for colname in self.column_names:
            if colname in new_record:
                new_value=new_record[colname]
                if isinstance(new_value, str):
                    if new_value.lower() in ["null", "-"]:
                        new_value=None
                elif isinstance(new_value, bool):
                    new_value = 1 if new_value is True else 0

                ### se sono uguali ...skip
                if eq:=are_equals(colname=colname, nfield=new_value, cfield=cur_record[colname]):
                    continue
                else:
                    diff_cols.append(colname)

        return diff_cols



    ##############################################################
    # # Prepara il record per la scrittura
    # # sono considerate solo le colonne in diff_cols
    # # il record lo consideriamo già serializzato quindi
    # #     pronto per essere scritto
    ##############################################################
    def prepareWriteData(self, record: dict, diff_cols: list):
        self.logger.caller('Entering in function...')

        cols, values, setList, whereList=[], [], [], []

        is_there_json_field=False
        for colname in diff_cols:
            if colname in record:
                col_type=self.struct_dict["columns"][colname]["type"]
                value=record[colname]

                if value is None:
                    continue

                elif isinstance(value, bool):
                    value=1 if value is True else 0
                    string=f'"{colname.strip()}"="{int(value)}"'

                elif col_type == "INTEGER":
                    string=f'"{colname.strip()}"="{int(value)}"'

                elif value:
                    string=f'"{colname.strip()}"="{value}"'

                else:
                    continue

                setList.append(string)
                cols.append(colname)
                values.append(value)

                if colname in self.primary_keys:
                    whereList.append(string)
                if col_type == "JSON":
                    is_there_json_field=True


        new_data=False if cols == [] else True

        ret=SimpleNamespace()
        ret.where=' and '.join(whereList)
        ret.set=', '.join(setList) if new_data else None
        ret.cols=tuple(cols) if new_data else None
        ret.values=tuple(values) if new_data else None
        ret.new_data=new_data
        ret.is_there_json_field=is_there_json_field

        return ret



        # ###################################################################
        # - Creiamo una WHERE clause con i dati delle primary_keys ed il record
        # - SELECT * FROM table where name = "replace" ;
        # ###################################################################
    def PK_whereClause(self, record):
        self.logger.caller('Entering in function...')
        whereList=[]
        nulls=0
        for colname in self.primary_keys:
            if colname in record.keys():
                value=record[colname]
                if not value or value.lower() in ["null", "-"]:
                    nulls += 1
                    string = f"{colname.strip()} is NULL"
                else:
                    string=f'"{colname.strip()}"="{value}"'
                whereList.append(string)

        whereString = ' and '.join(whereList)

        if nulls >= len(self.primary_keys): # 03-05-2024
            whereString = None
            self.logger.critical("impossibile creare la WHERE String in quanto tutte le primaryKeys sono NULL")
            import pdb; pdb.set_trace();trace=True # by Loreto
            sys.exit(1)

        return whereString






    ##############################################################
    # #
    ##############################################################
    def getStruct(self):
        self.logger.caller('Entering in function...')
        return self.struct_dict

    ##############################################################
    # #
    ##############################################################
    def columnNames(self):
        self.logger.caller('Entering in function...')
        return self.column_names

    ##############################################################
    # #
    ##############################################################
    def primaryKeys(self):
        self.logger.caller('Entering in function...')
        return self.primary_keys


    ##############################################################
    # #
    ##############################################################
    def totalChanges(self):
        return self.total_changes


    ##############################################################
    # #
    ##############################################################
    def totalErrors(self):
        return self.total_errors


    ##############################################################
    # #
    ##############################################################
    def sqlExecute(self, command: str, **kwargs):
        ret=self.db.Execute(command=command, **kwargs)
        if ret.rcode:
            self.total_errors+=1
        # if not ret.cursor:
        #     self.total_errors+=1
        #     self.logger.error()
        self.total_changes+=ret.total_changes
        return ret



    # ***********************************************
    # *
    # ***********************************************
    def Commit(self):
        self.db.Commit()
