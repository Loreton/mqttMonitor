#!/usr/bin/python
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 14-01-2024 08.00.51
#
# #############################################


import  sys; sys.dont_write_bytecode=True
this=sys.modules[__name__]

import  os
import json
import socket; hostname=socket.gethostname()
import json, yaml, functools
import zipfile, io
import timeit, time

from types import SimpleNamespace
from collections import OrderedDict
from pathlib import Path, PureWindowsPath, PurePosixPath, PosixPath
from typing import Any, IO
from benedict import benedict

if __name__ == '__main__':
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Utils")
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Logger")

import LnUtils

# this.filedata={}

#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.search_paths: list=gVars["search_paths"] if "search_paths" in gVars else ["conf"]





###################  I N I    ###########################################
###################  I N I    ###########################################
###################  I N I    ###########################################

############  INI Files ###############################
def ini_set():
    import configparser
    ini_config=configparser.ConfigParser(
                        allow_no_value=False,
                        delimiters=('=', ':'),
                        comment_prefixes=('#',';'),
                        inline_comment_prefixes=(';',),
                        strict=True,          # True: impone unique key/session
                        empty_lines_in_values=False,
                        default_section='DEFAULT',
                        # "interpolation": configparser.ExtendedInterpolation() # mi dà errore con le variabili
                        interpolation=configparser.BasicInterpolation()
                    )

    ini_config.optionxform = str        # mantiene il case nei nomi delle section e delle Keys (Assicurarsi che i riferimenti a vars interne siano case-sensitive)

    return ini_config



###################  Y  A  M  L   ###########################################
###################  Y  A  M  L   ###########################################
###################  Y  A  M  L   ###########################################

#####################################
# ref:
#       https://docs.gitlab.com/ee/ci/yaml/yaml_optimization.html
#       https://www.programcreek.com/python/example/11269/yaml.add_constructor
# Example:
#   xxx: !join_str [*lndisk_root, "/lnDisk/Users"]
#####################################
def join_str(loader, node):
    seq = loader.construct_sequence(node)
    return ''.join([str(i) for i in seq])


#####################################
# https://www.programcreek.com/python/example/11269/yaml.add_constructor
# Example:
#   xxx: !join_path [*lndisk_root, "lnDisk", "Users"] i vari item[1:] non devono avere '/' iniziale'
#####################################
def join_path(loader, node):
    seq = loader.construct_sequence(node)
    return os.path.join(*seq)



def common_include_file(filename):
    ### check for keypath
    _keypath=None
    if '#' in filename:
        filename, _keypath=filename.rsplit('#', 1)


    if not (content := this._read_file_content(filename)):
        return {}


    extension=Path(filename).suffix.lower()
    if extension=='.ini':
        _dict=this.load_ini(filename=filename, content=content)

    elif extension=='.json':
        _dict=this.load_json(filename=filename, content=content)

    elif extension=='.csv':
        _dict=this.load_csv(filepath=filename, content=content)

    else:
        _dict=yaml.load(content, Loader=yaml.FullLoader)

    if _keypath:
        _dict=this._get_keypath(d=_dict, keypath=_keypath)
        if _dict is None:
            gv.logger.caller("keypath: %s NOT found", _keypath)

    return _dict



#######################################################################
#  Include file referenced at node.
# Example:
#       rsync:
#           !include "rsync_options.yaml#rsync"

#######################################################################
def yaml_constructor_include(loader: yaml.Loader, node: yaml.Node):
    filename=node.value

    return this.common_include_file(filename)


#######################################################################
# Example:
#   profiles:
#        !include_merge ["lnprofile.yaml#xxxy", "lndata.yaml", "lndisk.yaml"]
#######################################################################
def yaml_constructor_include_merge(loader: yaml.Loader, node: yaml.Node):
    seq = loader.construct_sequence(node)

    _dict={}
    for filename in seq:
        f_dict=this.common_include_file(filename) # get content as dict
        _dict.update(f_dict) # update merge area

    return _dict





## register the tag handler
yaml.add_constructor('!join_str', join_str)
yaml.add_constructor('!join_path', join_path)
yaml.add_constructor('!include', this.yaml_constructor_include)
yaml.add_constructor('!include_merge', this.yaml_constructor_include_merge)

""" Other:

    key01:
        ln_merge_key_path: bots.LnCasettaBot  - get value from keypath: bots.LnCasettaBot and merge into key. ln_merge_key_path will be removed
        sub_key: xxx

        bot: ${!include_key_path} devices_db.bots.LnCasettaBot - get value from devices_db.bots.LnCasettaBot
    key02:
        key: ${!parent_name} - get "key02" name
        key: ${!parent_attr} [key] lvl
"""


###################  C O M M O N   ###########################################
###################  C O M M O N   ###########################################
###################  C O M M O N   ###########################################


##########################################################################
# keypath is string whith keys separated by dot
#       key1.key2.....keyn
# cast is the returned dictionary type (lortodict, OrderedDict, ...)
##########################################################################
def _check_zip():
    gv=SimpleNamespace()
    """ check it its a zip file """
    script_path=Path(sys.argv[0]).resolve()
    if zipfile.is_zipfile(script_path):
        gv.zFile=zipfile.ZipFile(script_path, "r")
        gv.zFileNamelist=gv.zFile.namelist()

    else:
        gv.zFile=None
        gv.zFileNamelist=[]

    return gv



#==========================================================
# keypath: "key1.key2.key3...." or ["key1", "key2", "key3"]
#==========================================================
def _get_keypath(d: dict={}, keypath: (str, list)=[]) -> dict:
    keypath_sep='.'
    ptr=d

    if isinstance(keypath, str):
        keypath=keypath.split(keypath_sep)

    for key in keypath:
        if key in ptr:
            ptr=ptr[key]

        else:
            ptr=None

    return ptr



###############################################
#
###############################################
def _read_file_content(filename: (str, PosixPath), search_paths: list=[]) -> str:
    gv.logger.info("File: %s - try loading", filename)
    #-----------------------
    def add_script_path():
        script_dir=Path(sys.argv[0]).absolute().parent
        if gv.OpSys=="Windows":
            script_dir=script_dir.parent

        new_paths=search_paths[:]

        for path in search_paths:
            new_paths.append(str(script_dir / path))
        new_paths.insert(0, '')
        new_paths=list(set(new_paths))  ### unique

        return new_paths


    fpath=Path(filename)
    #-- in caso di absolute path ---------------------
    if fpath.is_absolute():
        search_paths.insert(0, str(fpath.parent))
        filename=fpath.name   # set filename w/o path
    else:
        filename=Path(filename)


    search_paths=list(set(search_paths + gv.search_paths))
    _paths=add_script_path()

    lv=this._check_zip()

    content=None
    for path in _paths:
        ### - it's on filesystem
        filepath=Path(path) / filename
        gv.logger.debug("searching file: %s", filepath)

        # if filepath.exists():
        if filepath.is_dir():
            gv.logger.error("File: %s is a directory", filepath)
            return None

        elif filepath.is_file():
            with filepath.open(mode="r") as f:
                content=f.read() # single string
            break

        elif str(filepath) in lv.zFileNamelist:
            gv.logger.info("searching file: %s in zip", filepath)
            buffer=io.BytesIO(lv.zFile.read(str(filepath)))
            content=buffer.read()
            break

        ### - it's inside zipfile created by Linux
        elif gv and gv.OpSys=="Windows":
            filepath=PurePosixPath(filepath)
            if str(filepath) in lv.zFileNamelist:
                gv.logger.info("searching file: %s in zip", filepath)
                buffer=io.BytesIO(lv.zFile.read(str(filepath)))
                content=buffer.read()
                break

    if content:
        gv.logger.info("File: %s loaded", filepath)
    else:
        gv.logger.error("File: %s not found in paths: %s", filename, _paths)
        return None
        sys.exit(1)

    ### resolve env vars
    content=os.path.expandvars(content)
    return content







###################  C A L L E R S   ###########################################
###################  C A L L E R S   ###########################################
###################  C A L L E R S   ###########################################


###############################################
#
###############################################
def load_ini(filename: str=None, content: str=None, search_paths: list=[]):

    if not content:
        if not search_paths:
            search_paths=gv.search_paths
        # content=_read_file_content(filename=filename, search_paths=search_paths)
        if not (content := this._read_file_content(filename=filename, search_paths=search_paths)):
            return {}

    ### -----------------------------
    ### if it's a ini file
    ### -----------------------------
    ini_config=ini_set()
    ini_config.read_string(content)
    ini_dict = {}
    for section in ini_config.sections():
        ini_dict[section] = {}
        for option in ini_config.options(section):
            ini_dict[section][option] = ini_config.get(section, option)


    return ini_dict





###########################################################
# Remove all the passed keys
#   "xx*" all keys starting with "xx"
#   "xx" all keys named "xx"
###########################################################
def ___removeKeys(d: dict, keys=[]):
    def f(d, key, value):
        s_key=str(key)
        for prefix in prefixes:
            if s_key.startswith(prefix):
                # print(f"\ndict: {d} - key: {key} - value: {value}")
                gv.logger.notify("removing key: %s", key)
                del d[key]

        for keyname in keynames:
            if s_key==keyname:
                # print(f"\ndict: {d} - key: {key} - value: {value}")
                gv.logger.notify("removing key: %s", key)
                del d[key]


    prefixes=[x[:-1] for x in keys if x.endswith("*")]
    keynames=[x for x in keys if not x.endswith("*")]
    d.traverse(f)



###########################################################
# Remove all the keys starting with "__" string
###########################################################
def removeTemplates(d: dict):
    def f(d, key, value):
        # print(f"\ndict: {d} - key: {key} - value: {value}")
        # print(f"key: {key}")
        # print(d.keypaths(indexes=False))
        if str(key).startswith("__"):
            gv.logger.notify("removing key: %s", key)
            del d[key]
    d.traverse(f)


###############################################
#
###############################################
def load_yaml(filename: str=None, content: str=None, search_paths: list=[], to_dict: str=None, remove_templates: bool=True):
    # gv.logger.warning("loading file: %s", filename)
    # gv.logger.warning("loading content: %s", content)
    if not content:
        if not search_paths:
            search_paths=gv.search_paths
        if not (content := this._read_file_content(filename=filename, search_paths=search_paths)):
            return {}

    d=yaml.load(content, Loader=yaml.FullLoader)
    d1=benedict(d, keyattr_enabled=True, keyattr_dynamic=False)
    if remove_templates:
        this.removeTemplates(d=d1)

    if to_dict == "benedict":
        return d1
    else:
        return d


###############################################
#
###############################################
def load_json(filename: str=None, content: str=None, search_paths: list=[]) -> dict:
    if not content:
        # gv.logger.warning("loading file: %s", filename)
        if not search_paths:
            search_paths=gv.search_paths
        if not (content := this._read_file_content(filename=filename, search_paths=search_paths)):
            return {}

    return json.loads(content)






###############################################
#    C  S  V  -  C  S  V  -  C  S  V  -  C  S  V  -
###############################################
import csv
def load_csv(filepath: str, content: str=None, search_paths: list=[], csv_dict=True, comments=['#', ';'], exit_on_error=True, strip_value=False) -> list:
    from io import StringIO

    if not search_paths:
        search_paths=gv.search_paths

    if not content:
        gv.logger.info('reading file: %s', filepath)
        if not (content := this._read_file_content(filename=filepath, search_paths=search_paths)):
            return []


    if isinstance(content, bytes):
        buff=StringIO(content.decode('utf-8'))
    else:
        buff=StringIO(content)

    rows=[]
    if csv_dict:
        # return list of rows_dict
        csvreader=csv.DictReader(buff, skipinitialspace=True, delimiter=',', quotechar='"')
        first_field=csvreader.fieldnames[0]
        for row in csvreader:
            keys=list(row.keys())
            if keys[0][0] in comments: continue
            if strip_value:
                for key in keys:
                    row[key]=row[key].strip()
            rows.append(row)

    else:
        # return list of list/rows
        csvreader=csv.reader(buff, skipinitialspace=True, delimiter=',', quotechar='"')
        for row in csvreader:
            if row[0] in comments: continue
            if strip_value:
                for key in keys:
                    row[key]=row[key].strip()
            rows.append(row)


    return rows






###############################################
# risolve entry del tipo:
#   bot:        ${!include_key_path} devices_db.bots.LnCasettaBot
#   name:       ${up_parent.1}
#   group_name: ${parent.2.name}
# lparent sono i primi che devono essere risolti
# presume che il dictionary sia benedict
###############################################
def xcross_references_resolving(d: dict):

    # --------------------------------------------
    # - deve essere risolto come primo step, prima di poter essere richiamato da qualche parent.attr
    # --------------------------------------------
    def _resolve_lparent():
        keypaths=d.keypaths(indexes=True) ### inside lists
        for keypath in keypaths:
            value=d[keypath]

            if isinstance(value, (str)):
                prefix="${up_parent."; suffix="}"
                if match := LnUtils.regex_search(value, prefix, suffix, fLAST=True):
                    gv.logger.debug("%s Found on path: %s", "${up_parent.}", keypath)

                    parent_level=int(match.name)+1
                    parent_keyname=keypath.split('.')[-parent_level]
                    d[keypath]=parent_keyname



    def _resolve_parent():
        gv.logger.debug("%s Found on path: %s", "${parent.}", keypath)
        if "parent.1.characteristics.friendly_names" in value:
            xx=0
        parent_level, attr_name=match.name.split(".", 1) # attr_name può essere acnche un keypath a.b.c ma va implementato...
        parent_level=int(parent_level)

        parent_keypath=keypath.split('.')[:-parent_level] # get parrent pointer
        parent_keypath.append(attr_name) # get parrent pointer

        # ptr_val=d['.'.join(parent_keypath)] # read value pointed by variable
        ptr_val=d[parent_keypath] # read value pointed by variable - benedict legge anche keypath_list


        # rebuild value string 0:start_pos + new_val + end_pos:
        parts=[value[:match.start_pos]]
        parts.append(ptr_val)
        parts.append(value[match.end_pos:])
        parts = list(filter(None,parts))  # remove empty/null items
        # new_val=''.join(parts) # può essere solo str
        new_val=''.join([str(n) for n in parts]) # @changed:  03-11-2023

        d[keypath]=new_val # assign new value

    # --------------------------------------------


    #--- deve essere risolto come primo step
    _resolve_lparent()

    keypaths=d.keypaths(indexes=True) ### inside lists
    for keypath in keypaths:
        # print("----", keypath)
        # if not "merge_dict_no_overwrite" in d["main.profiles.ln_profile.remote_nodes.to_ext41.dirs_to_sync._dir0"]:
        #     import pdb; pdb.set_trace();trace=True # by Loreto
        try:
            value=d[keypath]
        except KeyError:
            last_key=keypath.split(".")[-1]
            if last_key in ["merge_dict_no_overwrite", "merge_dict_overwrite"]:
                gv.logger.debug("skipping key: %s (it's a xrox-reference-key )", keypath)


            continue # forse già rimosso perché è una mia chiave

        if not isinstance(value, (str)): continue

        prefix="${parent."; suffix="}"
        if match := LnUtils.regex_search(value, prefix, suffix, fLAST=True):
            _resolve_parent()


        elif keypath.endswith("merge_dict_no_overwrite"):
            """merge_dict_no_overwrite: bots.LnCasettaBot [full dictionary path to be retrieved ] """
            gv.logger.debug("%s Found on path: %s", "merge_dict_no_overwrite", keypath)
            new_val=d[value]
            parent_keypath=keypath.split('.')[:-1] ### remove last qualifier
            if isinstance(d[parent_keypath], dict):
                if isinstance(new_val, dict):
                    del d[keypath] ### remove item entry
                    temp_dict={}  # @Loreto:  04-12-2023
                    temp_dict.update(new_val)   # get new dictionary data
                    temp_dict.update(d[parent_keypath])   # get previous dictionary data to override new_val
                    d[parent_keypath].update(temp_dict)   # write merged data

                else:
                    gv.logger.error("Il path richiesto [%s] deve puntare ad un dictionary.", keypath)
            else:
                gv.logger.error("Il path receiver [%s] deve essere ad un dictionary.", parent_keypath)


        elif keypath.endswith("merge_dict_overwrite"):
            """merge_dict_on_keypath: bots.LnCasettaBot [full dictionary path to be retrieved ] """
            gv.logger.debug("%s Found on path: %s", "merge_dict_overwrite", keypath)
            new_val=d[value]
            parent_keypath=keypath.split('.')[:-1] ### remove last qualifier
            if isinstance(d[parent_keypath], dict):
                if isinstance(new_val, dict):
                    del d[keypath] ### remove item entry
                    d[parent_keypath].update(new_val)   # write merged data
                else:
                    gv.logger.error("Il path richiesto [%s] deve puntare ad un dictionary.", keypath)
            else:
                gv.logger.error("Il path receiver [%s] deve essere ad un dictionary.", parent_keypath)



        elif value.startswith("${!include_key_path}"):
            """bot: ${!include_key_path} bots.LnCasettaBot [full dictionary path to be retrieved ]"""
            gv.logger.debug("%s Found on path: %s", "${!include_key_path}", keypath)
            _, _key_path=value.split()
            new_val=d[_key_path]

            if isinstance(new_val, dict):
                d[keypath]={}
                d[keypath].update(new_val)
            else:
                d[keypath]=new_val


    #-----------------------------------------------
    #- Verify all pointers are resolved
    #-----------------------------------------------
    keypaths=d.keypaths(indexes=True) ### inside lists
    for keypath in keypaths:
        value=d[keypath]
        if not isinstance(value, (str)): continue
        prefixes=["${up_parent", "${parent"]
        for prefix in prefixes:
            if prefix in value:
                gv.logger.critical("Unresolved pointer")
                gv.logger.error("keypath: %s", keypath)
                gv.logger.error("value:   %s", value)
                sys.exit(1)

# resolve_my_references=xcross_references_resolving


def timing(ref_time=0, fSTART=False):
    if fSTART:
        return time.time()
    elif ref_time>0:
        print(time.time() - ref_time)
        import pdb; pdb.set_trace(); pass # by Loreto


###############################################
# d: dict --- will NOT modified
# columns: list
# return: csv_file (just created) as list[dict]
###############################################
def _get_columns_length(l_data: list, columns: list) -> dict:
    ### calculate max columns width
    def dictFieldsLength(d: dict, *, fld_width: dict={}) -> dict:
        for k, value in d.items():
            val_len=len(str(value))
            if val_len <10: val_len=10
            if not k in fld_width: fld_width[k]=0
            fld_width[k]=max(fld_width[k], val_len)
    # ------------------------------------


    fld_width={}

    """ calcola la len delle colonne """
    for rec in l_data:
        dictFieldsLength(rec, fld_width=fld_width)

    """ calcola anche la len dei nomi colonne """
    colnames_dict={}
    for col_name in columns:
        colnames_dict[col_name]=col_name
    dictFieldsLength(colnames_dict, fld_width=fld_width)
    l_data.insert(0, colnames_dict) ### lo inseriamo in modo che verranno justified anche i nomi delle colonne

    return fld_width

_get_keys_length=_get_columns_length


###############################################
# d: dict --- will NOT modified
# columns: list
# return: csv_file (just created) as list[dict]
###############################################
def _write_csv(l_data: list, columns: list, *, fld_width: dict={},  filepath: str=None, header_comments=[]):
    import tempfile

    ### - prepare for temporary file
    isTemp=False if filepath else True
    if isTemp:
        os_hndl, filepath=tempfile.mkstemp(suffix=None, prefix=None, dir=None, text=False)

    filepath=Path(filepath)
    gv.logger.info('writing file: %s', filepath)


    last_colname=columns[-1]

    fDICTWRITER=False
    if fDICTWRITER:
        ### utilizzo il dictWriter direttamente
        extrasaction="raise" if error_on_missed_column else "ignore"
        with filepath.open(mode='w', newline='') as csvfile:
            writer=csv.DictWriter(csvfile, fieldnames=ordered_columns, extrasaction=extrasaction) ### determina anche l'ordine come verranno scritte
            writer.writeheader()

            for record in l_data:
                writer.writerow(record)

    else:
        ### write csv file line by line (justified values) e mi permetti di inserire un commento
        with filepath.open(mode='w', newline='') as csvfile:
            writer=csv.writer(csvfile)

            if header_comments:
                writer.writerow(header_comments)

            for record in l_data:
                record_keys=list(record.keys())
                row=[]
                for col_name in columns[:-1]:
                    value=str(record[col_name]) if col_name in record_keys else "-"
                    if fld_width:
                        value=value.ljust(fld_width[col_name]+1) ### +1 for easy reading
                    row.append(value)


                ### - last column do not set width
                value=str(record[last_colname]) if last_colname in record_keys else "-"
                row.append(value)

                writer.writerow(row)


    ### -----------------------------------------------------------
    ### re-read the csv file for getting data  to be returned
    ### -----------------------------------------------------------
    csv_data=this.load_csv(filepath=filepath, strip_value=True)
    if isTemp:
        os.remove(filepath)

    return csv_data



def dict_to_csv(d: (dict, list), *, columns_list: list=[], out_filepath: str=None, sort_keys: bool=False, fixed_width=False, header_comments: list=[], error_on_missed_column: bool=True) -> list:

    ### trasforma il tutto in data[{rec1}, {rec2}, ...]
    if isinstance(d, dict):
        import copy
        data=copy.deepcopy(d)
        l_data=list(data.values())

    elif isinstance(d, list):
        l_data=d[:]

    else:
        raise ValueError('missing or wrong input data...')


    ### - get keys of first record
    if not columns_list:
        columns_list=list(l[0].keys()) ### else: prende il nome delle colonne dal primo record

    ordered_columns=columns_list if not sort_keys else columns_list.sort(reverse=False)


    if fixed_width:
        fld_width=_get_columns_length(l_data, ordered_columns)

    csv_data=_write_csv(l_data=l_data, columns=ordered_columns, fld_width=fld_width, filepath=out_filepath, header_comments=header_comments)

    return csv_data




##############################################################
# - READ - FILE
##############################################################
def ___read_text(*, filepath: (str, os.PathLike), encoding: str='utf-8', exit_on_error: bool=False) -> list:
    gv.logger.debug('reading file: %s', filepath)

    fin=Path(filepath).resolve()

    if fin.exists():
        content=[]
        encoding='utf-8'
        with open(fin, 'r', encoding='utf-8') as f:
            content=f.read() # return all file as string
        content=content.split('\n')

    else:
        gv.logger.error('File: %s NOT FOUND', fin)
        if exit_on_error:
            sys.exit(1)

    return content





def setVariables(data: dict):
    for var_name, value in data.items():
        os.environ[var_name]=os.path.expandvars(value)
        gv.logger.info('setting variable %s: %s', var_name, value)






#######################################################
#
#######################################################
def loadConfigurationData(*, config_file: str, tmp_dir: str, gVars: dict):
    gVars.hostname=socket.gethostname().split()[0]

    FileLoader=this # per puntare ai riferimenti interni

    LnUtils.setup(gVars)
    this.setup(gVars)

    config: dict = this.load_yaml(filename=config_file, to_dict="benedict", remove_templates=True)
    """Load configuration data"""

    LnUtils.writeFile(filepath=f"{tmp_dir}/unresolved_config.yaml", data=config, replace=True)
    """save unresolved configuration data"""

    if "devices_data" in config:
        this.xcross_references_resolving(d=config["devices_data"])
    """resolve external files cross references"""

    this.xcross_references_resolving(d=config)
    """resolve external files cross references"""

    LnUtils.writeFile(filepath=f"{tmp_dir}/resolved_config.yaml", data=config, replace=True)
    """save full configuration data"""

    if "system_variables" in config:
        system_variables=config.pop("system_variables")
        this.setVariables(data=system_variables)
    """Setting environment variables"""

    ### TEST per verificare che le variabili sono state impostate
    for var in ["ln_ENVARS_DIR", "ln_RUNTIME_DIR"]:
        if not os.getenv(var):
            gv.logger.error("La variabile: %s non risulta impostata.", var)
            sys.exit(1)


    return config



#############################################################
#
#############################################################
if __name__ == '__main__':
    prj_name='FileLoader_test'
    __ln_version__=f"{prj_name} version V2024-01-14_080051"

    yaml_conf='''
    system_variables: !include ${HOME}/.ln/envars/yaml/ln_system_variables.yaml#system_envars

    devices_data:
        bots:       !include "${HOME}/.ln/config/devicesDB/source/telegramBots.yaml#bots"
        broker:     !include ${HOME}/.ln/config/devicesDB/source/Mqtt_Brokers.yaml#brokers.lnmqtt
        devices:    !include_merge [
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#raspberry",
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#pc",
                        "${HOME}/.ln/config/devicesDB/source/Cellulari.yaml#cellulari",
                        "${HOME}/.ln/config/devicesDB/source/Printers.yaml#printers",
                        "${HOME}/.ln/config/devicesDB/source/Routers.yaml#routers",
                        "${HOME}/.ln/config/devicesDB/source/Tasmota.yaml#tasmota",
                        "${HOME}/.ln/config/devicesDB/source/Shelly.yaml#shelly",
                        "${HOME}/.ln/config/devicesDB/source/Telecamere.yaml#telecamere",
                        "${HOME}/.ln/config/devicesDB/source/TV.yaml#tv",
                        "${HOME}/.ln/config/devicesDB/source/Unused.yaml#unused",
                        "${HOME}/.ln/config/devicesDB/source/telegramApplGroups.yaml#application_groups",
                        "${HOME}/.ln/config/devicesDB/source/telegramChannels.yaml#channels",
                    ]
    '''



    from ColoredLogger_V103 import setColoredLogger, testLogger
    from benedict import benedict
    from datetime import datetime # , timedelta
    import platform
    import socket

    import tempfile


    tmp_dir=f"/tmp/{prj_name}"
    config_file=f"{tmp_dir}/config.yaml"
    with open(config_file, "w") as f:
        f.write(yaml_conf)


    # ---- Loggging
    logger=setColoredLogger(logger_name=prj_name,
                            console_logger_level="info",
                            file_logger_level=None,
                            logging_dir=None, # logging file--> logging_dir + logger_name
                            threads=False,
                            create_logging_dir=True)
    testLogger(logger)
    logger.info('------- Starting -----------')
    logger.warning(__ln_version__)



    gv=benedict(keyattr_enabled=True, keyattr_dynamic=False) # copy all input args to gv
    gv.logger             = logger
    gv.OpSys: str         = platform.system()
    gv.prj_name: str      = prj_name
    gv.search_paths: list = ['conf']
    gv.date_time: str     = datetime.now().strftime("%Y%m%d_%H%M")
    os.environ['DATE_TIME']=gv.date_time


    config=loadConfigurationData(gVars=gv, config_file=config_file, tmp_dir=tmp_dir)
    # print(config.py())
    sys.exit()

