#!/usr/bin/python
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 06-05-2024 16.45.40
#
# #############################################


import  sys; sys.dont_write_bytecode=True; this=sys.modules[__name__]
import  os

import socket; hostname=socket.gethostname()
import yaml, functools
import zipfile, io
import timeit, time

from types import SimpleNamespace
from collections import OrderedDict
from pathlib import Path, PureWindowsPath, PurePosixPath, PosixPath
from typing import Any, IO
from benedict import benedict

if __name__ == '__main__':
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Utils")
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Logger")
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/files")

import LnUtils
import File_csv
import File_yaml
import File_ini
import File_json

# import File_yaml

# loader_modules=os.environ.get("Loader_modules").split()
# for module_name in loader_modules:
#     if   module_name=="csv":  import File_csv
#     elif module_name=="yaml": import File_yaml
#     elif module_name=="ini":  import File_ini
#     elif module_name=="json": import File_json


#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    """ External refereces:
        - logger
        - search_paths
    """
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.search_paths: list=gVars["search_paths"] if "search_paths" in gVars else ["conf"]

    gv.read_file_content   = this.read_file_content
    gv.common_include_file = this.common_include_file

    File_csv.setup(gVars=gv)
    File_yaml.setup(gVars=gv)
    File_ini.setup(gVars=gv)
    File_json.setup(gVars=gv)


    # for module_name in loader_modules:
    #     if   module_name=="csv":  File_csv.setup(gVars=gv)
    #     elif module_name=="yaml": File_yaml.setup(gVars=gv)
    #     elif module_name=="ini":  File_ini.setup(gVars=gv)
    #     elif module_name=="json": File_json.setup(gVars=gv)


###########################################################
# Remove all the keys starting with "__" string
###########################################################
def removeTemplates(d: dict, flatten_list: bool=True):

    def f(d, key, value):
        if str(key).startswith("__"):
            gv.logger.notify("removing key: %s", key)
            del d[key]

        elif isinstance(value, list):
            gv.logger.debug("flatten key: %s", key)
            _list=[]
            for items in value:
                if isinstance(items, (list, tuple)):
                    for item in items:
                        if not item: continue
                        if isinstance(item, list):
                            _list.extend(item)
                        else:
                            _list.append(item)

                else:
                    _list.append(items) # è singolo

            d[key]=_list

    d.traverse(f)


###########################################################
#
###########################################################
def common_include_file(filename):
    _keypath=None
    if '#' in filename:
        filename, _keypath=filename.rsplit('#', 1)


    if not (content := this.read_file_content(filename)):
        return {}


    extension=Path(filename).suffix.lower()
    if extension=='.ini':
        _dict=File_ini.load_ini(filename=filename, content=content)

    elif extension=='.json':
        _dict=File_json.load_json(filename=filename, content=content)

    elif extension=='.csv':
        primary_key=_keypath if _keypath else None
        _dict=File_csv.load_csv(filepath=filename, content=content, dict_pri_key=primary_key)
        _keypath=None ### azzeriamolo altrimenti va in errore dopo
    else:
        _dict=File_yaml.load_yaml(filepath=filename, content=content)



    if _keypath:
        _dict=this._get_keypath(d=_dict, keypath=_keypath)
        if _dict is None:
            gv.logger.caller("keypath: %s NOT found", _keypath)

    return _dict




###################  C O M M O N   ###########################################
###################  C O M M O N   ###########################################
###################  C O M M O N   ###########################################


##########################################################################
# keypath is string whith keys separated by dot
#       key1.key2.....keyn
# cast is the returned dictionary type (lortodict, OrderedDict, ...)
##########################################################################
def _check_zip():
    gv=SimpleNamespace()
    """ check it its a zip file """
    script_path=Path(sys.argv[0]).resolve()
    if zipfile.is_zipfile(script_path):
        gv.zFile=zipfile.ZipFile(script_path, "r")
        gv.zFileNamelist=gv.zFile.namelist()

    else:
        gv.zFile=None
        gv.zFileNamelist=[]

    return gv



#==========================================================
# keypath: "key1.key2.key3...." or ["key1", "key2", "key3"]
#==========================================================
def _get_keypath(d: dict={}, keypath: (str, list)=[]) -> dict:
    keypath_sep='.'
    ptr=d

    if isinstance(keypath, str):
        keypath=keypath.split(keypath_sep)

    for key in keypath:
        if key in ptr:
            ptr=ptr[key]

        else:
            ptr=None

    return ptr



###############################################
#
###############################################
def read_file_content(filename: (str, PosixPath), search_paths: list=[], return_list: bool=False) -> str:
    gv.logger.info("File: %s - try loading", filename)
    #-----------------------
    def add_script_path():
        script_dir=Path(sys.argv[0]).absolute().parent
        if gv.OpSys=="Windows":
            script_dir=script_dir.parent

        new_paths=search_paths[:]

        for path in search_paths:
            new_paths.append(str(script_dir / path))
        new_paths.insert(0, '')
        new_paths=list(set(new_paths))  ### unique

        return new_paths


    fpath=Path(filename)
    #-- in caso di absolute path ---------------------
    if fpath.is_absolute():
        search_paths.insert(0, str(fpath.parent))
        filename=fpath.name   # set filename w/o path
    else:
        filename=Path(filename)


    search_paths=list(set(search_paths + gv.search_paths))
    _paths=add_script_path()

    lv=this._check_zip()

    content=None
    for path in _paths:
        ### - it's on filesystem
        filepath=Path(path) / filename
        gv.logger.debug("searching file: %s", filepath)

        # if filepath.exists():
        if filepath.is_dir():
            gv.logger.error("File: %s is a directory", filepath)
            return None

        elif filepath.is_file():
            with filepath.open(mode="r") as f:
                content=f.read() # single string
            break

        elif str(filepath) in lv.zFileNamelist:
            gv.logger.info("searching file: %s in zip", filepath)
            buffer=io.BytesIO(lv.zFile.read(str(filepath)))
            content=buffer.read()
            break

        ### - it's inside zipfile created by Linux
        elif gv and gv.OpSys=="Windows":
            filepath=PurePosixPath(filepath)
            if str(filepath) in lv.zFileNamelist:
                gv.logger.info("searching file: %s in zip", filepath)
                buffer=io.BytesIO(lv.zFile.read(str(filepath)))
                content=buffer.read()
                break

    if content:
        gv.logger.info("File: %s loaded", filepath)
    else:
        gv.logger.error("File: %s not found in paths: %s", filename, _paths)
        if gv.exit_on_config_file_not_found:
            sys.exit(1)
        return None

    ### resolve env vars
    content=os.path.expandvars(content)
    if return_list:
        return content.split("\n")
    return content


###################  r e s o l v e    C R O S S - R E F E R E N C E S   ##########################
###################  r e s o l v e    C R O S S - R E F E R E N C E S   ##########################


#####################################
# iterate on keypaths "key1.key2.key3...."
#####################################
def iter_keypaths(d: dict, search_str: (list, str)=""):
    gv.logger.caller("iter_keypaths", stacklevel=2)
    keypaths=d.keypaths(indexes=True) ### explode also lists objects
    gv.logger.debug("numbers of keypaths: %s", len(keypaths))

    for index, keypath in enumerate(keypaths):
        try:
            value=d[keypath]
        except KeyError:
            last_key=keypath.split(".")[-1]
            if last_key in ["merge_dict_no_overwrite", "merge_dict_overwrite"]:
                gv.logger.warning("skipping key: %s (it's a xrox-reference-key )", keypath)
            continue # forse già rimosso perché è una mia chiave


        if search_str:
            if isinstance(value, str):
                for string in search_str:
                    if string in value:
                        gv.logger.warning("found")
                        gv.logger.warning("  keypath: %s", keypath)
                        gv.logger.warning("  value:   %s", value)
                        yield keypath, value
        else:
            yield keypath, value




###################  function repeater   ###########################################
###################  function repeater   ###########################################
###################  function repeater   ###########################################


def dict_to_csv(**kwargs):
    File_csv.dict_to_csv(**kwargs)

###################  function repeater   ###########################################
###################  function repeater   ###########################################
###################  function repeater   ###########################################













def timing(ref_time=0, fSTART=False):
    if fSTART:
        return time.time()
    elif ref_time>0:
        print(time.time() - ref_time)
        import pdb; pdb.set_trace(); pass # by Loreto








def setVariables(data: dict):
    for var_name, value in data.items():
        os.environ[var_name]=os.path.expandvars(value)
        gv.logger.debug('setting variable %s: %s', var_name, value)




#######################################################
# - carica il file primario
# - elimina i templates (keys="__XXX")
# - salva il file
# - ricarica il file
# - imposta le system variable e le rimuove dal dictionary
# - ritorna config data
#######################################################
def loadConfigurationData(*, config_file: str, save_yaml_on_file: str, set_system_variables: bool=True):
    config: dict = File_yaml.load_yaml(filepath=config_file, to_dict="benedict")
    """Load configuration data"""

    this.removeTemplates(d=config, flatten_list=True)
    # this.flattenList(config)



    if set_system_variables:
        if "system_variables" in config:
            system_variables=config.pop("system_variables")
            this.setVariables(data=system_variables)
        """Setting environment variables"""

        ### TEST per verificare che le variabili sono state impostate
        for var in ["ln_ENVARS_DIR", "ln_RUNTIME_DIR"]:
            if not os.getenv(var):
                gv.logger.error("La variabile: %s non risulta impostata.", var)
                sys.exit(1)

    """ ---------------------------------------------
     nel caso avessi caricato file di tipo csv, ho notato che in fase di resolve xcross_references
    si allungano notevolente i tempi di risoluzione.
    Per ovviare a questo inconveniente di tale risoluzione, ricarico il file
    appena salvato ed il problema non si pone.
    Lo so che non è molto pulito ma non avendo capito la causa di tale problema... va bene casì
    --------------------------------------------- """
    # LnUtils.writeFile(filepath=save_yaml_on_file, data=config, replace=True)
    config.toYaml(filepath=save_yaml_on_file, replace=True)

    ### lo ricarichiamo
    config: dict = File_yaml.load_yaml(filepath=save_yaml_on_file, to_dict="benedict")

    return config





#############################################################
#
#############################################################
if __name__ == '__main__':
    prj_name='FileLoader_test'
    __ln_version__=f"{prj_name} version V2024-05-06_164540"

    yaml_conf='''
    system_variables: !include ${HOME}/.ln/envars/yaml/ln_system_variables.yaml#system_envars

    devices_data:
        bots:       !include "${HOME}/.ln/config/devicesDB/source/telegramBots.yaml#bots"
        broker:     !include ${HOME}/.ln/config/devicesDB/source/Mqtt_Brokers.yaml#brokers.lnmqtt
        devices:    !include_merge [
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#raspberry",
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#pc",
                        "${HOME}/.ln/config/devicesDB/source/Cellulari.yaml#cellulari",
                        "${HOME}/.ln/config/devicesDB/source/Printers.yaml#printers",
                        "${HOME}/.ln/config/devicesDB/source/Routers.yaml#routers",
                        "${HOME}/.ln/config/devicesDB/source/Tasmota.yaml#tasmota",
                        "${HOME}/.ln/config/devicesDB/source/Shelly.yaml#shelly",
                        "${HOME}/.ln/config/devicesDB/source/Telecamere.yaml#telecamere",
                        "${HOME}/.ln/config/devicesDB/source/TV.yaml#tv",
                        "${HOME}/.ln/config/devicesDB/source/Unused.yaml#unused",
                        "${HOME}/.ln/config/devicesDB/source/telegramApplGroups.yaml#application_groups",
                        "${HOME}/.ln/config/devicesDB/source/telegramChannels.yaml#channels",
                    ]
    '''



    from ColoredLogger_V103 import setColoredLogger, testLogger
    from benedict import benedict
    from datetime import datetime # , timedelta
    import platform
    import socket

    import tempfile


    tmp_dir=f"/tmp/{prj_name}"
    config_file=f"{tmp_dir}/config.yaml"
    with open(config_file, "w") as f:
        f.write(yaml_conf)


    # ---- Loggging
    logger=setColoredLogger(logger_name=prj_name,
                            console_logger_level="info",
                            file_logger_level=None,
                            logging_dir=None, # logging file--> logging_dir + logger_name
                            threads=False,
                            create_logging_dir=True)
    testLogger(logger)
    logger.info('------- Starting -----------')
    logger.warning(__ln_version__)



    gv=benedict(keyattr_enabled=True, keyattr_dynamic=False) # copy all input args to gv
    gv.logger             = logger
    gv.OpSys: str         = platform.system()
    gv.prj_name: str      = prj_name
    gv.search_paths: list = ['conf']
    gv.date_time: str     = datetime.now().strftime("%Y%m%d_%H%M")
    os.environ['DATE_TIME']=gv.date_time


    config=loadConfigurationData(gVars=gv, config_file=config_file, tmp_dir=tmp_dir)
    # print(config.py())
    sys.exit()

