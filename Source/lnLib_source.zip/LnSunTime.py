#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-09-17
#
import  sys; sys.dont_write_bytecode = True


from datetime import datetime #
from suntimes import SunTimes # pip3 install suntimes
from datetime import date, datetime, timezone, timedelta
import pytz

# https://stackoverflow.com/questions/38986527/sunrise-and-sunset-time-in-python
# https://github.com/p-mathis/suntimes
def sample():

    day = datetime(2021,4,6)
    day = datetime.now()

    tz_name='Europe/Warsaw';latitude=52.0691667; longitude=19.4805556; altitude=0
    tz_name='Europe/Rome'; latitude=43.070629; longitude=12.32749; altitude=800
    tz_name='Europe/Rome'; latitude=42.291476; longitude=12.957694; altitude=800; # Casetta
    tz_poland = pytz.timezone(tz_name)

    #date
    #location Paris Notre-Dame France
    sun = SunTimes(2.349902, 48.852968, 35)
    sun = SunTimes(longitude=longitude, latitude=latitude, altitude=altitude)


    # Return UTC time :
    print('====== suntimes UTC ======')
    print(sun.riseutc(day))
    # print(datetime(2021, 1, 6, 7, 42, 52, 269))

    print(sun.setutc(day))
    # datetime.datetime(2021, 1, 6, 16, 12, 5, 630)

    # Return local computer time :
    print('====== suntimes LOCAL ======')
    print(sun.riselocal(day))
    # print(.datetime(2021, 1, 6, 8, 42, 52, 269, tzinfo=<DstTzInfo 'Europe/Paris' CET+1:00:00 STD>))

    print(sun.setlocal(day))
    # print(datetime(2021, 1, 6, 17, 12, 5, 630, tzinfo=<DstTzInfo 'Europe/Paris' CET+1:00:00 STD>))
    # for_date = date(2021, 4, 6)

    print('====== suntimes ??? ======')
    print(sun.risewhere(day, tz_name))
    print(sun.setwhere(day, tz_name))



#######################################
# to_str="%Y/%m/%d %H:%M:%S"
#######################################
def _sunTime(latitude, longitude, altitude=0,  str_format=None):
    # gv.logger.caller('Entering in function...')
    day=datetime.now()
    sun=SunTimes(longitude=longitude, latitude=latitude, altitude=altitude)
    sun_rise=sun.riselocal(day) # datetime
    sun_set=sun.setlocal(day)   # datetime
    if str_format:
        sun_rise=sun_rise.strftime(str_format)
        sun_set=sun_set.strftime(str_format)

    return sun_rise, sun_set


def sunTime_casetta(str_format=None):
    # gv.logger.caller('Entering in function...')
    # to_str="%Y/%m/%d %H:%M:%S"
    return _sunTime(latitude=42.29182561160083, longitude=12.95754769929025, altitude=800, str_format=str_format)
    # if to_str:
    #     return dtime.strftime(to_str)
    # else:
    #     return dtime


def sunTime_beverino(str_format=None):
    # gv.logger.caller('Entering in function...')
    # to_str="%Y/%m/%d %H:%M:%S"
    return _sunTime(latitude=41.91091236947744, longitude=12.40124138418293, altitude=60, str_format=str_format)
    # if to_str:
    #     return dtime.strftime(to_str)
    # else:
    #     return dtime



def sunrise(day=None, tz_name=None):
    # gv.logger.caller('Entering in function...')
    if not day: day=datetime.now()
    if not tz_name: tz_name='Europe/Rome'
    return sun.risewhere(day, tz_name)


def sunset(day=None, tz_name=None):
    # gv.logger.caller('Entering in function...')
    if not day: day=datetime.now()
    if not tz_name: tz_name='Europe/Rome'
    return sun.setwhere(day, tz_name)


if __name__ == '__main__':
    sample()
    print('====== casetta ======')
    sun_rise, sun_set=sunTime_casetta()
    print(sun_rise)
    print(sun_set)