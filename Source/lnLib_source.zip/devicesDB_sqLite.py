#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 13-07-2024 16.06.57
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
import os, signal
from types import SimpleNamespace
from benedict import benedict
import time
from datetime import datetime
import ipaddress
from pathlib import Path


import LnUtils
from SQLiteDB_Class import SQLiteDB_Class


##################################################################
# tg_data nel caso abbia già i dati....
##################################################################
class devicesDB_Class():
    # def __init__(self, *, db_filepath: str=None, db_struct: dict, logger, error_on_duplicate: bool=True):
    def __init__(self, *, db_filepath: str=None, logger, close_after_read: bool=True, error_on_duplicate: bool=True):

        self.error_on_duplicate=error_on_duplicate
        self.logger=logger

        # self.myDB=self.readSQLiteDB(db_filename=db_filepath)
        if Path(db_filepath).exists():
            db_data=self.readSQLiteDB(db_filename=db_filepath)
            if close_after_read:
                self.myDB.Close()

        else:
            self.logger.error(f"il file:\n      %s\n non esiste.", db_filepath)
            sys.exit(1)

        '''
        tasmotaProperties   = db_data["tasmotaProperties"] ### crea un dict con solo "extra_data"
        self.bots    = db_data["bots"] ### crea un dict con solo "bots"
        self.brokers = db_data["brokers"]
        self.devices = db_data["devices"]

        ### ===================================================================
        ### per ogni device fa il merge con gli extra data... se esistono per esso
        ### inoltre inserisce le entrate del bot sotto tg_Group
        ### tg_Group:
        ###     name: ${parent.1.name}
        ###     chat_id: ${parent.1.chat_id} # https://web.telegram.org/a/#-451564560
        ###     type: ${parent.1.type}
        ###     bot_name:       will be overwritten by associated bot_name
        ###     bot_username:   will be overwritten by associated bot_name
        ###     bot_token:      will be overwritten by associated bot_name
        ### ===================================================================
        for name, device in self.devices.items():

            if name in tasmotaProperties.keys() and device.type == "tasmota" and device.chat_id:
                device["tasmota"] = benedict(tasmotaProperties[name], keyattr_enabled=True, keyattr_dynamic=False)

            if device.bot_name:
                bot=self.bots.get(device.bot_name)
                if bot:
                    tg = {
                        "name":      device.name,
                        "chat_id":      device.chat_id,
                        # "device_type":  device.device_type,
                        "bot_name":     device.bot_name,
                        "bot_username": bot.username,
                        "bot_token":    bot.token,
                    }
                    device["tg"]      = benedict(tg, keyattr_enabled=True, keyattr_dynamic=False)

                # device.merge(tasmotaProperties[name], overwrite=False, concat=True)


        '''

        # self.logger.info('devicesDB class has been instantied! %s', self.myDB.Version(fPRINT=True))
        self.logger.info('devicesDB class has been instantied!')




    #####################################################################
    #  read sqliteDB
    #####################################################################
    def readSQLiteDB(self, *, db_filename: str, close_after_read: bool=True) -> dict:
        myDB=SQLiteDB_Class(db_filename=db_filename, check_same_thread=False, logger=self.logger)
        myDB.Version(fPRINT=True)

        table_list=myDB.getTableList()
        # now = datetime.now().strftime("%Y%m%d_%H%M")

        tables={}
        db_data={}
        for table_name in table_list:
            myTable = myDB.getTableClass(table_name=table_name)
            _records=myTable.get_AllRecords(keyed_dict=True)
            tables[table_name] = myTable

            if table_name=="devices":
                self.devicesTable = myTable
                # self.devices    = _records
                # db_data["devices"]=_records

            elif table_name=="tasmotaProperties":
                self.tasmotaPropertiesTable = myTable
                # self.tasmotaProperties = _records
                # db_data["tasmotaProperties"]=_records

            elif table_name=="telegramBots":
                self.telegramBotsTable = myTable
                # self.bots = _records
                # db_data["bots"]=_records

            elif table_name=="mqttBrokers":
                self.brokersTable = myTable
                # self.brokers = _records
                # db_data["brokers"]=_records

            elif table_name=="virtual_servers":
                self.vServersTable = myTable
                # self.virtualServers = _records
                # db_data["virtual_servers"]=_records



        self.dbTables = benedict(tables, keyattr_enabled=True, keyattr_dynamic=False)
        self.myDB=myDB
        return benedict(db_data, keyattr_enabled=True, keyattr_dynamic=False)



    def getBroker(self, name: str):
        self.logger.caller(__name__)
        return self.brokersTable.getRecord(where = f'"broker_name" = "{name}"')


    def getDevice(self, name: str=None, mac: str=None, where: str=None) -> dict:
        self.logger.caller(__name__)

        if name:
            device = self.devicesTable.getRecord(where = f'"name" = "{name}"')
        elif mac:
            device = self.devicesTable.getRecord(where = f'"mac" = "{mac}"')
        elif where:
            device = self.devicesTable.getRecord(where = where)
        else:
            device = {}

        # if name=="Orto_4ch":
        #     import pdb; pdb.set_trace();print(name) # by Loreto
        if device:
            if device.type == "tasmota":
                tasmota_properties = self.tasmotaPropertiesTable.getRecord(where = f'"device_name" = "{device.name}"')
                if tasmota_properties:
                    device["tasmota"]=benedict(tasmota_properties, keyattr_enabled=True, keyattr_dynamic=False)
                else:
                    self.logger.error("No tasmota properties found for device: %s", device.name)
                    # os.kill(int(os.getpid()), signal.SIGTERM)



            if device.bot_name:
                bot=self.telegramBotsTable.getRecord(where = f'"bot_name" = "{device.bot_name}"')
                if bot:
                    tg = {
                        "name":         device.name,
                        "chat_id":      device.chat_id,
                        "bot_name":     device.bot_name,
                        "bot_username": bot.username,
                        "bot_token":    bot.token,
                    }
                    device["tg"] = benedict(tg, keyattr_enabled=True, keyattr_dynamic=False)




        return device






    def getTgGroup(self, name: str=None) -> dict:
        self.logger.caller(__name__)
        if name:
            return self.devicesTable.getRecord(where = f'"name" = "{name}"')

    def getObjects(self):
        return self.devices

    def getDevices(self):
        return self.devices

    def getYaml(self):
        return self.devices.to_yaml()


    def getBrokers(self):
        return self.brokers

    def getBots(self):
        return self.bots








class Tasmota_DeviceDB_Class():
    def __init__(self, devicesDB_Class, device_dict: dict):
        self.DB=devicesDB_Class
        self.device: dict = device_dict
        self.livedata: dict = {}

    def to_dict(self) -> str:
        self.logger.caller(__name__)
        return self.device

    def clone(self) -> str:
        self.logger.caller(__name__)
        import copy
        return self.device.clone() # benedict dictionary
        # native command: d = copy.deepcopy(obj, memo)

    # @property
    def friendlyNames(self) -> str:
        self.logger.caller(__name__)
        if self.device.type=="tasmota":
            return self.device.get("characteristics.friendly_names")

        return None

    def friendlyName(self, relay_nr: int) -> str:
        self.logger.caller(__name__)
        fn=self.friendlyNames
        if relay_nr in range(1, self.nRelays()+1):
            return fn[relay_nr]

        return None



    # @property
    def nRelays(self) -> int:
        self.logger.caller(__name__)
        if self.device.type=="tasmota":
            return len(self.device.get("characteristics.friendly_names"))

        return 0

    def bot(self) -> dict:
        self.logger.caller(__name__)
        tg=self.device.tg_Group
        bot={}
        bot['bot_name']   = tg.bot_name
        bot['bot_token']  = tg.bot_token
        bot['chat_id']    = tg.chat_id
        return bot

    # @property
    def tg(self) -> dict:
        self.logger.caller(__name__)
        return self.device.tg_Group

    def type(self) -> str:
        self.logger.caller(__name__)
        return self.device.type

    def name(self) -> str:
        self.logger.caller(__name__)
        return self.device.name

    def mac(self) -> str:
        self.logger.caller(__name__)
        return self.device.mac

    def get_setup_commands(self) -> list:
        self.logger.caller(__name__)
        if self.device.type=="tasmota":
            import pdb; pdb.set_trace();trace=True # by Loreto
            if "setup_commands" in self.device:
                return self.device.setup_commands
            else:
                import pdb; pdb.set_trace();trace=True # by Loreto
        return []

    def get_refresh_commands(self) -> list:
        self.logger.caller(__name__)
        if self.device.type=="tasmota":
            return self.device.refresh_commands
        return []








#############################################################
#
#############################################################
if __name__ == '__main__':
    prj_name='devicesDB_test'
    __ln_version__=f"{prj_name} version V2024-07-13_160657"


    yaml_conf='''
    system_variables: !include ${HOME}/.ln/envars/yaml/ln_system_variables.yaml#system_envars

    devices_data:
        bots:       !include "${HOME}/.ln/config/devicesDB/source/telegramBots.yaml#bots"
        broker:     !include ${HOME}/.ln/config/devicesDB/source/Mqtt_Brokers.yaml#brokers.lnmqtt
        devices:    !include_merge [
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#raspberry",
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#pc",
                        "${HOME}/.ln/config/devicesDB/source/Cellulari.yaml#cellulari",
                        "${HOME}/.ln/config/devicesDB/source/Printers.yaml#printers",
                        "${HOME}/.ln/config/devicesDB/source/Routers.yaml#routers",
                        "${HOME}/.ln/config/devicesDB/source/Tasmota.yaml#tasmota",
                        "${HOME}/.ln/config/devicesDB/source/Shelly.yaml#shelly",
                        "${HOME}/.ln/config/devicesDB/source/Telecamere.yaml#telecamere",
                        "${HOME}/.ln/config/devicesDB/source/TV.yaml#tv",
                        "${HOME}/.ln/config/devicesDB/source/Unused.yaml#unused",
                        "${HOME}/.ln/config/devicesDB/source/telegramApplGroups.yaml#application_groups",
                        "${HOME}/.ln/config/devicesDB/source/telegramChannels.yaml#channels",
                    ]
    '''



    from ColoredLogger_V103 import setColoredLogger, testLogger
    import FileLoader
    from benedict import benedict
    from datetime import datetime # , timedelta
    import platform
    import socket



    tmp_dir=f"/tmp/{prj_name}"
    config_file=f"{tmp_dir}/config.yaml"
    with open(config_file, "w") as f:
        f.write(yaml_conf)


    # ---- Loggging
    logger=setColoredLogger(logger_name=prj_name,
                            console_logger_level="info",
                            file_logger_level=None,
                            logging_dir=None, # logging file--> logging_dir + logger_name
                            threads=False,
                            create_logging_dir=True)
    testLogger(logger)
    logger.info('------- Starting -----------')
    logger.warning(__ln_version__)



    gv=benedict(keyattr_enabled=True, keyattr_dynamic=False) # copy all input args to gv
    gv.logger               = logger
    gv.OpSys: str           = platform.system()
    gv.prj_name: str        = prj_name
    gv.search_paths: list   = ['conf']
    gv.date_time: str       = datetime.now().strftime("%Y%m%d_%H%M")
    os.environ['DATE_TIME'] = gv.date_time


    config=FileLoader.loadConfigurationData(config_file=config_file, tmp_dir=tmp_dir, gVars=gv)

    devices_data=config.pop("devices_data")
    devicesDB=devicesDB_Class(db_data=devices_data, error_on_duplicate=True, logger=logger)
    """instantiate deviceaDB class (crea gli indici per alcuni attributi) """

    broker=devicesDB.getBroker()
    broker.py()
    # print(config.py())
    sys.exit()

