#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 05-05-2024 08.11.54
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
import os
from types import SimpleNamespace
from benedict import benedict
import time
from datetime import datetime
import ipaddress
from pathlib import Path



if __name__ == '__main__':
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Utils")
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Logger")
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/files")

import LnUtils
from SQLiteDB_Class import SQLiteDB_Class


##################################################################
# tg_data nel caso abbia già i dati....
##################################################################
class devicesDB_Class():
    # def __init__(self, *, db_filepath: str=None, db_struct: dict, logger, error_on_duplicate: bool=True):
    def __init__(self, *, db_filepath: str=None, logger, error_on_duplicate: bool=True):

        self.error_on_duplicate=error_on_duplicate
        self.logger=logger

        # self.myDB=self.readSQLiteDB(db_filename=db_filepath)
        if Path(db_filepath).exists():
            db_data=self.readSQLiteDB(db_filename=db_filepath)
        else:
            self.logger.error(f"il file:\n      %s\n non esiste.", db_filepath)
            sys.exit(1)

        tasmotaProperties   = db_data["tasmotaProperties"] ### crea un dict con solo "extra_data"
        self.bots    = db_data["bots"] ### crea un dict con solo "bots"
        self.brokers = db_data["brokers"]
        self.devices = db_data["devices"]

        ### ===================================================================
        ### per ogni device fa il merge con gli extra data... se esistono per esso
        ### inoltre inserisce le entrate del bot sotto tg_Group
        ### tg_Group:
        ###     name: ${parent.1.name}
        ###     chat_id: ${parent.1.chat_id} # https://web.telegram.org/a/#-451564560
        ###     type: ${parent.1.type}
        ###     bot_name:       will be overwritten by associated bot_name
        ###     bot_username:   will be overwritten by associated bot_name
        ###     bot_token:      will be overwritten by associated bot_name
        ### ===================================================================
        for name, device in self.devices.items():

            if name in tasmotaProperties.keys() and device.type == "tasmota":
                device["tasmota"] = benedict(tasmotaProperties[name], keyattr_enabled=True, keyattr_dynamic=False)

            if device.bot_name:
                bot=self.bots.get(device.bot_name)
                if bot:
                    tg = {
                        "name":      device.name,
                        "chat_id":      device.chat_id,
                        # "device_type":  device.device_type,
                        "bot_name":     device.bot_name,
                        "bot_username": bot.username,
                        "bot_token":    bot.token,
                    }
                    device["tg"]      = benedict(tg, keyattr_enabled=True, keyattr_dynamic=False)

                # device.merge(tasmotaProperties[name], overwrite=False, concat=True)



        # self.logger.info('devicesDB class has been instantied! %s', self.myDB.Version(fPRINT=True))
        self.logger.info('devicesDB class has been instantied!')




    #####################################################################
    #  read sqliteDB
    #####################################################################
    def readSQLiteDB(self, *, db_filename: str) -> dict:
        myDB=SQLiteDB_Class(db_filename=db_filename, logger=self.logger)
        myDB.Version(fPRINT=True)

        table_list=myDB.getTableList()
        # now = datetime.now().strftime("%Y%m%d_%H%M")

        tables={}
        db_data={}
        for table_name in table_list:
            myTable = myDB.getTableClass(table_name=table_name)
            _records=myTable.get_AllRecords(keyed_dict=True)
            tables[table_name] = myTable

            if table_name=="devices":
                self.devicesTable = myTable
                self.devices    = _records
                db_data["devices"]=_records

            elif table_name=="tasmotaProperties":
                self.tasmotaPropertiesTable = myTable
                self.tasmotaProperties = _records
                db_data["tasmotaProperties"]=_records

            elif table_name=="telegramBots":
                self.botsTable = myTable
                self.bots = _records
                db_data["bots"]=_records

            elif table_name=="mqttBrokers":
                self.brokersTable = myTable
                self.brokers = _records
                db_data["brokers"]=_records

            elif table_name=="virtual_servers":
                self.vServersTable = myTable
                self.virtualServers = _records
                db_data["virtual_servers"]=_records



        self.dbTables = benedict(tables, keyattr_enabled=True, keyattr_dynamic=False)
        # return myDB
        myDB.Close()
        return benedict(db_data, keyattr_enabled=True, keyattr_dynamic=False)



    def getBroker(self, name: str):
        # return self._getRecord0(table_name="mqttBrokers", where=f'broker_name = "{name}"')
        return self.brokers.get(name)

    def getMac(self, mac: str):
        for name, dev in self.devices.items():
            if "mac" in dev and dev.mac == mac:
                return dev
        return None

        # return self._getRecord0(table_name="devices", where=f'mac = "{mac}"')

    def getDevice(self, name: str):
        return self.devices.get(name)
        # return self._getRecord0(table_name="devices", where=f'device_name = "{name}"')

    def getObjects(self):
        return self.devices

    def getDevices(self):
        return self.devices

    def getYaml(self):
        return self.devices.to_yaml()


    def getBrokers(self):
        return self.brokers

    def getBots(self):
        return self.bots



    #############################################################################
    # 03-05-2024
    # ritorna solo record selezionato
    #############################################################################
    def _getRecord0(self, table_name: str, where: str) -> (list, dict):
        table = self.dbTables[table_name]
        records = table.selectRecords(whereString=where, keyed_dict=False, expected_records=1)

        if records:
            return records[0]

        return records



    #############################################################################
    # ritorna solo record selezionati
    # with_attrib    : attributo che deve essere contenuto del device. Deve essere una str
    # return_keylist : ritorna solo la lista dei devices
    # fSort          : key name to be sorted
    #############################################################################
    def getRecord(self, where: str=None, return_keylist: bool=False, sort_key_name: str=None, strict: bool=True) -> (list, dict):
        """
            whereString='("ip" = "192.168.1.189" OR "ip" = "192.168.1.64")'
            whereString='("ip not null)'
        """
        table = self.tables[table_name]

        records=self.devicesTable.selectRecords(whereString=where)
        if sort_key_name:
            records=records.sort_by_key_name(sort_key_name=sort_key_name, error_on_duplicate=True, return_keylist=False)

        return benedict(records, keyattr_enabled=True, keyattr_dynamic=False)

    #############################################################################
    # ritorna solo record selezionati
    # with_attrib    : attributo che deve essere contenuto del device. Deve essere una str
    # return_keylist : ritorna solo la lista dei devices
    # fSort          : key name to be sorted
    #############################################################################
    def selectDevice(self, where: str=None, return_keylist: bool=False, sort_key_name: str=None, strict: bool=True) -> (list, dict):
        """
            whereString='("ip" = "192.168.1.189" OR "ip" = "192.168.1.64")'
            whereString='("ip not null)'
        """
        table = self.tables[table_name]

        records=self.devicesTable.selectRecords(whereString=where)
        if sort_key_name:
            records=records.sort_by_key_name(sort_key_name=sort_key_name, error_on_duplicate=True, return_keylist=False)

        return benedict(records, keyattr_enabled=True, keyattr_dynamic=False)






    #####################################################################
    #  ritorna un istanza di classe di Device
    #####################################################################
    def getDeviceInstance(self, *, dev_name: str=None, mac: str=None, ip: str=None) -> dict:
        if mac and not ":" in mac:
            mac=':'.join(mac[i:i+2] for i in range(0,12,2))

        for key, device in self.devices.items():
            # device=self.devices[key] ### per mantenere benedict

            if dev_name and device.get("name", "").lower()==dev_name.lower():
                break
            elif mac and device.get("mac", "").lower()==mac.lower():
                break
            elif ip and device.get("ip", "").lower()==ip.lower():
                break

        else:
            return None

        device_class=Tasmota_DeviceDB_Class(devicesDB_Class=self, device_dict=device)
        return device_class







    #####################################################################
    #
    #####################################################################
    def records_iter(self, *, my_dict: dict={}, with_attrib: str=None, strict: bool=True) -> dict:
        if not my_dict:
            my_dict=self.devices

        for key, device in my_dict.items():
            if with_attrib:
                if with_attrib in device:
                    yield key, device # - return selected devices

                elif strict is False:
                    continue

                else:
                    yield key, device # - return all devices

            else:
                yield key, device # - return all devices








    #############################################################################
    # ritorna solo record selezionati
    # with_attrib    : attributo che deve essere contenuto del device. Deve essere una str
    # return_keylist : ritorna solo la lista dei devices
    # fSort          : key name to be sorted
    #############################################################################
    def _select_table(self, column_name: str):
        ...




    #############################################################################
    # ritorna solo record selezionati
    # with_attrib    : attributo che deve essere contenuto del device. Deve essere una str
    # return_keylist : ritorna solo la lista dei devices
    # fSort          : key name to be sorted
    #############################################################################
    def selectDevice(self, where: str=None, return_keylist: bool=False, sort_key_name: str=None, strict: bool=True) -> (list, dict):
        """
            whereString='("ip" = "192.168.1.189" OR "ip" = "192.168.1.64")'
            whereString='("ip not null)'
        """
        table = self.tables[table_name]

        records=self.devicesTable.selectRecords(whereString=where)
        if sort_key_name:
            records=records.sort_by_key_name(sort_key_name=sort_key_name, error_on_duplicate=True, return_keylist=False)

        return benedict(records, keyattr_enabled=True, keyattr_dynamic=False)


    #############################################################################
    # ritorna solo record selezionati
    # with_attrib    : attributo che deve essere contenuto del device. Deve essere una str
    # return_keylist : ritorna solo la lista dei devices
    # fSort          : key name to be sorted
    #############################################################################
    def selectVirtualServers(self, where: str=None, return_keylist: bool=False, sort_key_name: str=None, strict: bool=True) -> (list, dict):
        records=self.vServersTable.selectRecords(whereString=where)
        if sort_key_name:
            records=records.sort_by_key_name(sort_key_name=sort_key_name, error_on_duplicate=True, return_keylist=False)

        return benedict(records, keyattr_enabled=True, keyattr_dynamic=False)




    #############################################################################
    # ritorna solo record selezionati
    # with_attrib    : attributo che deve essere contenuto del device. Deve essere una str
    # return_keylist : ritorna solo la lista dei devices
    # fSort          : sort dei record da tornare
    #############################################################################
    def selectRecordsxxx(self, my_dict: dict={}, with_attrib: str=None, return_keylist: bool=False, fSort: bool=False, strict: bool=True) -> (list, dict):

        def UpdateIndexDict(d: dict, key: str, record_key_path: str):
            if self.error_on_duplicate:
                if key in d.keys():
                    self.logger.error("duplicate key %s on record: %s", key, record_key_path)
                    sys.exit(1)
            d[key]=record_key_path

        ret: dict={}
        ip_dummy=0

        my_dict=my_dict if my_dict else self.devices

        for main_key, device in self.records_iter(my_dict=my_dict, with_attrib=with_attrib, strict=strict):
            if strict and with_attrib not in device:
                continue

            attrib_value=device[with_attrib]

            if not with_attrib:
                """ prendo main_key come key  """
                ret_key=main_key

            elif with_attrib=="ip":
                """ devo fare l'hashing  dell'indirizzo IP per poi poterne fare il sort """
                try:
                    ip_hash=int(ipaddress.ip_address(attrib_value)) # reverse....: print(ipaddress.IPv4Address(ip_hash))
                except:
                    self.logger.warning("%s: %s - doesn't contain a valid ip address - skipping", attrib_value, main_key)
                    continue
                    sys.exit(1)

                attrib_value=attrib_value.replace('.', '_')
                ret_key=f"IP_{ip_hash}_{attrib_value}"


            elif isinstance(attrib_value, str):
                ret_key=device[with_attrib]

            else:
                """ attrib value non è una stringa quindi non posso metterelo come key in un dict  """
                ret_key=main_key

            UpdateIndexDict(d=ret, key=ret_key, record_key_path=main_key)

        if fSort:
            ret=dict(sorted(ret.items()))

        if return_keylist:
            data: list=[]
            for key, main_key in ret.items():
                data.append(main_key)

        else:
            data: dict={}
            for key, main_key in ret.items():
                data[main_key]={}
                data[main_key].update(my_dict[main_key])

        return benedict(data, keyattr_enabled=True, keyattr_dynamic=False)







class Tasmota_DeviceDB_Class():
    def __init__(self, devicesDB_Class, device_dict: dict):
        self.DB=devicesDB_Class
        self.device: dict = device_dict
        self.livedata: dict = {}

    def to_dict(self) -> str:
        return self.device

    def clone(self) -> str:
        import copy
        return self.device.clone() # benedict dictionary
        # native command: d = copy.deepcopy(obj, memo)

    # @property
    def friendlyNames(self) -> str:
        if self.device.type=="tasmota":
            return self.device.get("characteristics.friendly_names")

        return None

    def friendlyName(self, relay_nr: int) -> str:
        fn=self.friendlyNames
        if relay_nr in range(1, self.nRelays()+1):
            return fn[relay_nr]

        return None



    # @property
    def nRelays(self) -> int:
        if self.device.type=="tasmota":
            return len(self.device.get("characteristics.friendly_names"))

        return 0

    def bot(self) -> dict:
        tg=self.device.tg_Group
        bot={}
        bot['bot_name']   = tg.bot_name
        bot['bot_token']  = tg.bot_token
        bot['chat_id']    = tg.chat_id
        return bot

    # @property
    def tg(self) -> dict:
        return self.device.tg_Group

    def type(self) -> str:
        return self.device.type

    def name(self) -> str:
        return self.device.name

    def mac(self) -> str:
        return self.device.mac

    def get_setup_commands(self) -> list:
        if self.device.type=="tasmota":
            import pdb; pdb.set_trace();trace=True # by Loreto
            if "setup_commands" in self.device:
                return self.device.setup_commands
            else:
                import pdb; pdb.set_trace();trace=True # by Loreto
        return []

    def get_refresh_commands(self) -> list:
        if self.device.type=="tasmota":
            return self.device.refresh_commands
        return []








#############################################################
#
#############################################################
if __name__ == '__main__':
    prj_name='devicesDB_test'
    __ln_version__=f"{prj_name} version V2024-05-05_081154"


    yaml_conf='''
    system_variables: !include ${HOME}/.ln/envars/yaml/ln_system_variables.yaml#system_envars

    devices_data:
        bots:       !include "${HOME}/.ln/config/devicesDB/source/telegramBots.yaml#bots"
        broker:     !include ${HOME}/.ln/config/devicesDB/source/Mqtt_Brokers.yaml#brokers.lnmqtt
        devices:    !include_merge [
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#raspberry",
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#pc",
                        "${HOME}/.ln/config/devicesDB/source/Cellulari.yaml#cellulari",
                        "${HOME}/.ln/config/devicesDB/source/Printers.yaml#printers",
                        "${HOME}/.ln/config/devicesDB/source/Routers.yaml#routers",
                        "${HOME}/.ln/config/devicesDB/source/Tasmota.yaml#tasmota",
                        "${HOME}/.ln/config/devicesDB/source/Shelly.yaml#shelly",
                        "${HOME}/.ln/config/devicesDB/source/Telecamere.yaml#telecamere",
                        "${HOME}/.ln/config/devicesDB/source/TV.yaml#tv",
                        "${HOME}/.ln/config/devicesDB/source/Unused.yaml#unused",
                        "${HOME}/.ln/config/devicesDB/source/telegramApplGroups.yaml#application_groups",
                        "${HOME}/.ln/config/devicesDB/source/telegramChannels.yaml#channels",
                    ]
    '''



    from ColoredLogger_V103 import setColoredLogger, testLogger
    import FileLoader
    from benedict import benedict
    from datetime import datetime # , timedelta
    import platform
    import socket



    tmp_dir=f"/tmp/{prj_name}"
    config_file=f"{tmp_dir}/config.yaml"
    with open(config_file, "w") as f:
        f.write(yaml_conf)


    # ---- Loggging
    logger=setColoredLogger(logger_name=prj_name,
                            console_logger_level="info",
                            file_logger_level=None,
                            logging_dir=None, # logging file--> logging_dir + logger_name
                            threads=False,
                            create_logging_dir=True)
    testLogger(logger)
    logger.info('------- Starting -----------')
    logger.warning(__ln_version__)



    gv=benedict(keyattr_enabled=True, keyattr_dynamic=False) # copy all input args to gv
    gv.logger               = logger
    gv.OpSys: str           = platform.system()
    gv.prj_name: str        = prj_name
    gv.search_paths: list   = ['conf']
    gv.date_time: str       = datetime.now().strftime("%Y%m%d_%H%M")
    os.environ['DATE_TIME'] = gv.date_time


    config=FileLoader.loadConfigurationData(config_file=config_file, tmp_dir=tmp_dir, gVars=gv)

    devices_data=config.pop("devices_data")
    devicesDB=devicesDB_Class(db_data=devices_data, error_on_duplicate=True, logger=logger)
    """instantiate deviceaDB class (crea gli indici per alcuni attributi) """

    broker=devicesDB.getBroker()
    broker.py()
    # print(config.py())
    sys.exit()

