#!/usr/bin/python
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 03-05-2024 18.27.30
#
# #############################################

import  sys; sys.dont_write_bytecode=True
this=sys.modules[__name__]

import  os
from pathlib import Path, PureWindowsPath, PurePosixPath, PosixPath
from benedict import benedict


###############################################
#    C  S  V  -  C  S  V  -  C  S  V  -  C  S  V  -
###############################################
import csv



#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    """ External refereces:
        - gv.logger
        - gv.read_file_content
        - gv.common_include_file
    """
    global gv, C
    gv=gVars
    C=gv.logger.getColors()
    gv.search_paths: list=gVars["search_paths"] if "search_paths" in gVars else ["conf"]




###############################################
# d: dict --- will NOT modified
# columns: list
# return: csv_file (just created) as list[dict]
###############################################
def _get_columns_length(l_data: list, columns: list) -> dict:
    ### calculate max columns width
    def dictFieldsLength(d: dict, *, fld_width: dict={}) -> dict:
        for k, value in d.items():
            val_len=len(str(value))
            if val_len <10: val_len=10
            if not k in fld_width: fld_width[k]=0
            fld_width[k]=max(fld_width[k], val_len)
    # ------------------------------------


    fld_width={}

    """ calcola la len delle colonne """
    for rec in l_data:
        dictFieldsLength(rec, fld_width=fld_width)

    """ calcola anche la len dei nomi colonne """
    colnames_dict={}
    for col_name in columns:
        colnames_dict[col_name]=col_name
    dictFieldsLength(colnames_dict, fld_width=fld_width)
    l_data.insert(0, colnames_dict) ### lo inseriamo in modo che verranno justified anche i nomi delle colonne

    return fld_width





###############################################
# d: dict --- will NOT modified
# columns: list
# return: csv_file (just created) as list[dict]
###############################################
def _write_csv(l_data: list, columns: list, *, fld_width: dict={},  filepath: str=None, header_comments=[]):
    gv.logger.caller('Entering in function...')
    import tempfile

    ### - prepare for temporary file
    isTemp=False if filepath else True
    if isTemp:
        os_hndl, filepath=tempfile.mkstemp(suffix=None, prefix=None, dir=None, text=False)

    filepath=Path(filepath)
    gv.logger.info('writing file: %s', filepath)


    last_colname=columns[-1]

    fDICTWRITER=False
    if fDICTWRITER:
        ### utilizzo il dictWriter direttamente
        extrasaction="raise" if error_on_missed_column else "ignore"
        with filepath.open(mode='w', newline='') as csvfile:
            writer=csv.DictWriter(csvfile, fieldnames=ordered_columns, extrasaction=extrasaction) ### determina anche l'ordine come verranno scritte
            writer.writeheader()

            for record in l_data:
                writer.writerow(record)

    else:
        ### write csv file line by line (justified values) e mi permetti di inserire un commento
        with filepath.open(mode='w', newline='') as csvfile:
            writer=csv.writer(csvfile)

            if header_comments:
                writer.writerow(header_comments)

            for record in l_data:
                record_keys=list(record.keys())
                row=[]
                for col_name in columns[:-1]:
                    value=str(record[col_name]) if col_name in record_keys else "-"
                    if value in ["None"]: value="null"
                    if fld_width:
                        value=value.ljust(fld_width[col_name]+1) ### +1 for easy reading
                    row.append(value)


                ### - last column do not set width
                value=str(record[last_colname]) if last_colname in record_keys else "-"
                row.append(value)

                writer.writerow(row)


    ### -----------------------------------------------------------
    ### re-read the csv file for getting data  to be returned
    ### -----------------------------------------------------------
    csv_data=this.load_csv(filepath=filepath)
    if isTemp:
        os.remove(filepath)

    return csv_data



############################################################################
# Crea un dict dove le main_key sono date dal valore del field
############################################################################
def csv_to_dict(csv_data: list, primary_key: str, comments: list=["#", ";"]):
    gv.logger.caller('Entering in function...')
    fieldnames=[]
    my_dict: dict=benedict(keyattr_enabled=True, keyattr_dynamic=False)
    d_field=-1

    for row in csv_data:
        if not row: continue
        first_char=row[0].strip()[0]
        if first_char in comments: continue
        if not fieldnames:

            ### prendi la prima riga valida come fieldnames
            for field_no, field_name in enumerate(row):
                field_name=field_name.strip()
                if field_name==primary_key: d_field=field_no
                fieldnames.append(field_name.strip())

            if d_field<0:
                gv.logger.error("primary-key: [%s] nonfound in fieldnames: %s", primary_key, fieldnames)
                gv.logger.error("nell'include del file.csv la primary-key è indicata dopo '#' filename.csv#prim_key")
                gv.logger.error("nell'include del file.csv la primary-key è indicata dopo '#' filename.csv#prim_key")
                sys.exit(1)
            continue

        _row={}
        d_key=row[d_field].strip()
        for index, fld_name in enumerate(fieldnames):
            value=row[index]
            if isinstance(value, str): value=value.strip()
            _row[fld_name]=value


        if d_key in my_dict.keys():
            gv.logger.error("duplicated key: %s", d_key)
            sys.exit(1)
        my_dict[d_key]=_row

    return my_dict


def to_csv(d: (dict, list), *, columns_list: list=[], filepath: str=None, sort_keys: bool=False, fixed_width=False, header_comments: list=[], error_on_missed_column: bool=True) -> list:

    ### trasforma il tutto in data[{rec1}, {rec2}, ...]
    if isinstance(d, dict):
        import copy
        data=copy.deepcopy(d)
        csv_data=list(data.values())

    elif isinstance(d, list):
        csv_data=d[:]

    else:
        raise ValueError('missing or wrong input data...')


    ### - get keys of first record
    if not columns_list:
        columns_list=list(csv_data[0].keys()) ### else: prende il nome delle colonne dal primo record

    ordered_columns=columns_list if not sort_keys else columns_list.sort(reverse=False)


    if fixed_width:
        fld_width=_get_columns_length(csv_data, ordered_columns)
    else:
        fld_width=0

    if filepath:
        csv_data=_write_csv(l_data=csv_data, columns=ordered_columns, fld_width=fld_width, filepath=filepath, header_comments=header_comments)

    return csv_data

dict_to_csv=to_csv







############################################################################
#
############################################################################
def load_csv(filepath: str, content: str=None, search_paths: list=[], dict_pri_key: str=None, comments=['#', ';']) -> (list, dict):
    if dict_pri_key:
        assert isinstance(dict_pri_key, str)
    gv.logger.caller('Entering in function...')
    from io import StringIO


    if not content:
        if not search_paths:
            search_paths=gv.search_paths
        gv.logger.info('reading file: %s', filepath)
        if not (content := gv.read_file_content(filename=filepath, search_paths=search_paths)):
            return []

    if isinstance(content, bytes):
        buff=StringIO(content.decode('utf-8'))
    else:
        buff=StringIO(content)


    #-----------------------------------------------------------------------
    ### NON mi conviene utilizzare il csv.DictReader perchè più complicato da gestire
    #-----------------------------------------------------------------------
    csvreader=csv.reader(buff, skipinitialspace=True, delimiter=',', quotechar='"')
    orig_rows = [row for row in csvreader]
    if dict_pri_key:
        _dict: dict=this.csv_to_dict(csv_data=orig_rows, primary_key=dict_pri_key, comments=comments)
        orig_rows=None
        return _dict
    else:
        return orig_rows



