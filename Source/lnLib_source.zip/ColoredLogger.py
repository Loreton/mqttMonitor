#!/usr/bin/python
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 27-08-2023 16.59.09
#



##########################################################
# colored Logger con anche la creazione di due ulteriori
# livelli di TRACE e NOTIFY
##########################################################
import os
import colorlog  # https://pypi.org/project/colorlog/
import logging
from logging.handlers import RotatingFileHandler

# -----------------------------------------------------------------------------------d
# https://betterstack.com/community/questions/how-to-use-logging-in-multiple-modules/
#  negli alti moduli:
#       import  sys; sys.dont_write_bytecode = True
#       import  os
#       import logging; logger=logging.getLogger(__name__)
# nel __main__():
#       logging.basicConfig(level=logging.DEBUG, format='%(asctime)s [%(levelname)4s] - [%(module)s.%(funcName)s:%(lineno)4s]: %(message)s')
# -----------------------------------------------------------------------------------d


# ==============================================
# - funzione utile per usarla nei display....
# - ref https://tldp.org/HOWTO/Bash-Prompt-HOWTO/x329.html
# ==============================================
def getColors():
    from types import SimpleNamespace
    colors=SimpleNamespace(
        red        = '\033[0;31m',
        redH       = '\033[1;31m',
        green      = '\033[0;32m',
        greenH     = '\033[1;32m',
        yellow     = '\033[0;33m',
        yellowH    = '\033[1;33m',
        blue       = '\033[0;34m',
        blueH      = '\033[1;34m',
        purple     = '\033[0;35m',
        purpleH    = '\033[1;35m',
        cyan       = '\033[0;36m',
        cyanH      = '\033[1;36m',
        gray       = '\033[0;37m',
        white      = '\033[1;37m',
        colorReset = '\033[0m',
    )
    return colors

def getColors_dict():
    from benedict import benedict
    colors=benedict({
        "red"        : '\033[0;31m',
        "redH"       : '\033[1;31m',
        "green"      : '\033[0;32m',
        "greenH"     : '\033[1;32m',
        "yellow"     : '\033[0;33m',
        "yellowH"    : '\033[1;33m',
        "blue"       : '\033[0;34m',
        "blueH"      : '\033[1;34m',
        "purple"     : '\033[0;35m',
        "purpleH"    : '\033[1;35m',
        "cyan"       : '\033[0;36m',
        "cyanH"      : '\033[1;36m',
        "gray"       : '\033[0;37m',
        "white"      : '\033[1;37m',
        "colorReset" : '\033[0m',
    }, keyattr_enabled=True, keyattr_dynamic=False)
    return colors


_LEVELS={
    "CRITICAL": 50,
    "CALLER": 45,
    "ERROR": 40,
    "NOTIFY": 33,
    "WARNING": 30,
    "FUNCTION": 25,
    "INFO": 20,
    "DEBUG": 10,
    "TRACE": 5,
    "NOTSET": 0,
}



######################################################
#
######################################################
import inspect
def callerFunc(stacklevel=1, fDEBUG=False):
    if fDEBUG:
        import traceback
        x=traceback.extract_stack()

        print('-'*40)
        for i in range(len(x)): print(i, inspect.stack()[i].function, inspect.stack()[i].lineno)

        print('-'*40)
        print("stacklevel:", stacklevel, inspect.stack()[stacklevel].function, inspect.stack()[stacklevel].lineno)
        print('-'*40)

    caller=inspect.stack()[stacklevel]

    fname=caller.filename.rsplit('.', 1)[0]
    funcname=os.sep.join(fname.split(os.sep)[-2:])
    msg=f"{funcname}:{caller.lineno}"
    if fDEBUG:
        print(msg)
    return msg






# --------- Adding TRACE level -------------------
def addTraceLevel(level):
    logging.TRACE=level
    def _trace(logger, message, *args, **kwargs):
        if logger.isEnabledFor(logging.TRACE):
            logger._log(logging.TRACE, message, args, **kwargs)
    logging.Logger.trace = _trace
    logging.addLevelName(logging.TRACE, "TRACE")


# --------- Adding NOTIFY level -------------------
def addNotifyLevel(level):
    logging.NOTIFY=level
    def _notify(logger, message, *args, **kwargs):
        if logger.isEnabledFor(logging.NOTIFY):
            logger._log(logging.NOTIFY, message, args, **kwargs)
    logging.Logger.notify = _notify
    logging.addLevelName(logging.NOTIFY, "NOTIFY")


# --------- Adding FUNCTION level -------------------
def addFunctionLevel(level):
    logging.FUNCTION=level
    def _function(logger, message, *args, **kwargs):
        if logger.isEnabledFor(logging.FUNCTION):
            logger._log(logging.FUNCTION, message, args, **kwargs)
    logging.Logger.function = _function
    logging.addLevelName(logging.FUNCTION, "FUNCTION")


# --------- Adding CALLER level -------------------
def addFunctionLevel(level):
    logging.CALLER=level
    def _caller(logger, message, *args, **kwargs):
        if logger.isEnabledFor(logging.CALLER):
            STACKLEVEL=2
            if 'stacklevel' in kwargs:
                STACKLEVEL+=int(kwargs['stacklevel'])
            caller_name=callerFunc(stacklevel=STACKLEVEL)
            message=f'{message} - [caller: {caller_name}]'
            logger._log(logging.CALLER, message, args, **kwargs)
    logging.Logger.caller = _caller
    logging.addLevelName(logging.CALLER, "CALLER")






#############################################################
# logging_dir: if None, no file logger will be created
#############################################################
def setColoredLogger(logger_name: str,
                        console_logger_level: str='critical',
                        file_logger_level: str='warning',
                        logging_dir: str=None,
                        create_logging_dir: bool=True,
                        lock_log=False,  # da sperimentare
                        threads: bool=False):


    threads_str="%(threadName)s." if threads else ''
    # ----------------------------
    def set_streamingHandler():
        formatter=colorlog.ColoredFormatter(
            f"""%(cyan)s%(asctime)s %(log_color)s[%(levelname)4s] - %(blue)s[{threads_str}%(module)s.%(funcName)s:%(lineno)4s]: %(log_color)s%(message)s""",
            datefmt="%H:%M:%S",
            reset=True,
                            # -------------------------------------------------------------------------------
                            # The following escape codes are made available for use in the format string:
                            #
                            #   {color}, fg_{color}, bg_{color}: Foreground and background colors.
                            #   bold, bold_{color}, fg_bold_{color}, bg_bold_{color}: Bold/bright colors.
                            #   thin, thin_{color}, fg_thin_{color}: Thin colors (terminal dependent).
                            #   reset: Clear all formatting (both foreground and background colors).
                            #
                            #  The available color names are black, red, green, yellow, blue, purple, cyan and white.
                            # -------------------------------------------------------------------------------
            log_colors={
                'TRACE':    'blue',
                'DEBUG':    'cyan',
                # 'NOTIFY':   'yellow',
                'NOTIFY':   'fg_bold_cyan',
                'INFO':     'green',
                'FUNCTION': 'fg_bold_yellow',
                # 'WARNING':  'purple',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CALLER':   'red',
                'CRITICAL': 'red,bg_white',
            },
            secondary_log_colors={},
            style='%'
        )

        consoleHandler=logging.StreamHandler()
        consoleHandler.setFormatter(formatter)
        return consoleHandler


    def set_fileHandler():
        # parent_dir=os.path.dirname(logging_file)
        logging_file=f"{logging_dir}/{logger_name.lower()}.log"
        if not os.path.exists(logging_dir) and create_logging_dir:
            os.makedirs(logging_dir)
        fileHandler=RotatingFileHandler(logging_file, maxBytes=5*1000*1000, backupCount=5)
        # formatter=logging.Formatter('%(asctime)s %(levelname)-4s  %(funcName)s:%(lineno)4s: %(message)s')
        formatter=logging.Formatter(f"%(asctime)s [%(levelname)4s] - [{threads_str}%(module)s.%(funcName)s:%(lineno)4s]: %(message)s")
        fileHandler.setFormatter(formatter)
        return fileHandler

    if lock_log:
        """okkio che può bloccare alcune appl tipo Telegram"""
        logging._acquireLock() # use the global logging lock for thread safety


    addTraceLevel(level=_LEVELS["TRACE"])
    addNotifyLevel(level=_LEVELS["NOTIFY"])
    addFunctionLevel(level=_LEVELS["FUNCTION"])
    addFunctionLevel(level=_LEVELS["CALLER"])

    ### create logger
    logger=logging.getLogger(logger_name)


    ### streaming
    consoleHandler=set_streamingHandler()
    consoleHandler.setLevel(console_logger_level.upper())
    logger.addHandler(consoleHandler)

    ### file logger
    if logging_dir:
        fileHandler=set_fileHandler()
        fileHandler.setLevel(file_logger_level.upper())
        logger.addHandler(fileHandler)


    logger.setLevel('TRACE') # metterlo al massimo, decidono i singoli handlers
    logger.propagate=False # se messo a True mi trovo due righe di log, una colorata e l'altra no.

    if lock_log:
        logging._releaseLock() # use the global logging lock for thread safety
    logger.getColors=getColors
    return logger




def testLogger(logger):
    print()
    logger.trace("this is a TRACE message")
    logger.debug("this is a DEBUGGING message")
    logger.notify("this is a NOTIFY message")
    logger.info("this is an INFORMATIONAL message")
    logger.warning("this is a WARNING message")
    logger.error("this is an ERROR message")
    logger.critical("this is a CRITICAL message")
    print()

