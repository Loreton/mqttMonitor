#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 14-10-2023 15.59.45
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
import os
from types import SimpleNamespace
from benedict import benedict
import time
from datetime import datetime
import ipaddress



if __name__ == '__main__':
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Utils")
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/Logger")
    sys.path.insert(0, "/media/loreto/LnDisk_SD_ext4/lnData/GIT-REPO/Python/LnPyLib/files")

import LnUtils



##################################################################
# tg_data nel caso abbia già i dati....
##################################################################
class devicesDB_Class():
    def __init__(self, *, db_data: dict, logger, error_on_duplicate: bool=True, save_on_file: bool=False, prj_name: str=None):
        assert isinstance(db_data, benedict)
        self.prj_name=prj_name if prj_name else "devicesDB"
        LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/devicesDB_config.yaml", data=db_data, replace=True, write_datetime=True)

        self.error_on_duplicate=error_on_duplicate
        self.logger=logger
        self.logger.info('devicesDB class has been instantied!')

        self.db_data=db_data
        self.devices=self.getDevices()



    def getDevices(self):
        return self.db_data["devices"]

    def getBroker(self):
        return self.db_data["broker"]




    #####################################################################
    #  ritorna un istanza di classe di Device
    #####################################################################
    def getDeviceInstance(self, *, dev_name: str=None, mac: str=None, ip: str=None) -> dict:
        if mac and not ":" in mac:
            mac=':'.join(mac[i:i+2] for i in range(0,12,2))

        for key in self.devices.keys():
            device=self.devices[key] ### per mantenere benedict

            if dev_name and device.get("name", "").lower()==dev_name.lower():
                break
            elif mac and device.get("mac", "").lower()==mac.lower():
                break
            elif ip and device.get("ip", "").lower()==ip.lower():
                break

        else:
            return None

        device_class=Device_Class(devicesDB_Class=self, device_dict=device)
        return device_class






    #####################################################################
    # lavora con ignore case
    #####################################################################
    def _nextItem(self, *, with_attrib: str=None) -> dict:
        for key in self.devices.keys():
            device=self.devices[key] ### per mantenere benedict

            if not with_attrib: # - return all devices
                yield key, device
            else:
                if with_attrib in device:
                    yield key, device







    #####################################################################
    #
    #####################################################################
    def records(self, *, with_attrib: str=None) -> dict:
        for key in self.devices.keys():
            device=self.devices[key] ### per mantenere benedict

            if not with_attrib: # - return all devices
                yield key, device
            else:
                if with_attrib in device:
                    yield key, device









    #############################################################################
    # ritorna solo record selezionati
    # with_attrib    : attributo che deve essere contenuto del device. Deve essere una str
    # return_keylist : ritorna solo la lista dei devices
    # fSort          : sort dei record da tornare
    #############################################################################
    def selectRecords(self, with_attrib: str=None, return_keylist: bool=False, fSort: bool=False) -> (list, dict):
        def UpdateIndexDict(d: dict, key: str, record_key_path: str):
            if self.error_on_duplicate:
                if key in d.keys():
                    self.logger.error("duplicate key %s on record: %s", key, record_key_path)
                    sys.exit(1)
            d[key]=record_key_path



        ret: dict={}
        """ret {"with_attrib_value": record_main_key} """
        for main_key, device in self._nextItem(with_attrib=with_attrib):
            attrib_value=device[with_attrib]

            if not with_attrib:
                """ prendo main_key come key  """
                ret_key=main_key

            elif with_attrib=="ip":
                """ devo fare l'hashing  dell'indirizzo IP per poi poterne fare il sort """
                try:
                    ip_hash=int(ipaddress.ip_address(attrib_value)) # reverse....: print(ipaddress.IPv4Address(ip_hash))
                except:
                    self.logger.error("%s: %s - is not a valid ip address", attrib_value, main_key)
                    sys.exit(1)

                attrib_value=attrib_value.replace('.', '_')
                ret_key=f"IP_{ip_hash}_{attrib_value}"

            elif isinstance(attrib_value, str):
                ret_key=device[with_attrib]

            else:
                """ attrib value non è una stringa quindi non posso metterelo come key in un dict  """
                ret_key=main_key

            UpdateIndexDict(d=ret, key=ret_key, record_key_path=main_key)


        if fSort:
            ret=dict(sorted(ret.items()))

        if return_keylist:
            data: list=[]
            for key, main_key in ret.items():
                data.append(main_key)

        else:
            data: dict={}
            for key, main_key in ret.items():
                data[main_key]={}
                data[main_key].update(self.devices[main_key])

        return data







class Device_Class():
    def __init__(self, devicesDB_Class, device_dict: dict):
        self.DB=devicesDB_Class
        self.device: dict = device_dict
        self.livedata: dict = {}

    def to_dict(self) -> str:
        return self.device

    def clone(self) -> str:
        import copy
        return self.device.clone() # benedict dictionary
        # native command: d = copy.deepcopy(obj, memo)

    @property
    def friendlyNames(self) -> str:
        if self.device.type=="tasmota":
            return self.device.get("characteristics.friendly_names")

        return None

    def friendlyName(self, relay_nr: int) -> str:
        fn=self.friendlyNames
        if relay_nr in range(1, self.nRelays()+1):
            return fn[relay_nr]

        return None



    @property
    def nRelays(self) -> int:
        if self.device.type=="tasmota":
            return len(self.device.get("characteristics.friendly_names"))

        return 0

    def bot(self) -> dict:
        tg=self.device.tg_Group
        bot={}
        bot['bot_name']   = tg.bot_name
        bot['bot_token']  = tg.bot_token
        bot['chat_id']    = tg.chat_id
        return bot

    @property
    def tg(self) -> dict:
        return self.device.tg_Group

    @property
    def type(self) -> str:
        return self.device.type

    @property
    def name(self) -> str:
        return self.device.name

    @property
    def mac(self) -> str:
        return self.device.mac

    @property
    def tasmota_setup_commands(self) -> list:
        if self.device.type=="tasmota":
            return self.device.tasmota_setup_commands
        return []

    @property
    def tasmota_refresh_commands(self) -> list:
        if self.device.type=="tasmota":
            return self.device.tasmota_refresh_commands
        return []








#############################################################
#
#############################################################
if __name__ == '__main__':
    prj_name='devicesDB_test'
    __ln_version__=f"{prj_name} version V2023-10-14_155945"


    yaml_conf='''
    system_variables: !include ${HOME}/.ln/envars/yaml/ln_system_variables.yaml#system_envars

    devices_data:
        bots:       !include "${HOME}/.ln/config/devicesDB/source/telegramBots.yaml#bots"
        broker:     !include ${HOME}/.ln/config/devicesDB/source/Mqtt_Brokers.yaml#brokers.lnmqtt
        devices:    !include_merge [
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#raspberry",
                        "${HOME}/.ln/config/devicesDB/source/Computers.yaml#pc",
                        "${HOME}/.ln/config/devicesDB/source/Cellulari.yaml#cellulari",
                        "${HOME}/.ln/config/devicesDB/source/Printers.yaml#printers",
                        "${HOME}/.ln/config/devicesDB/source/Routers.yaml#routers",
                        "${HOME}/.ln/config/devicesDB/source/Tasmota.yaml#tasmota",
                        "${HOME}/.ln/config/devicesDB/source/Shelly.yaml#shelly",
                        "${HOME}/.ln/config/devicesDB/source/Telecamere.yaml#telecamere",
                        "${HOME}/.ln/config/devicesDB/source/TV.yaml#tv",
                        "${HOME}/.ln/config/devicesDB/source/Unused.yaml#unused",
                        "${HOME}/.ln/config/devicesDB/source/telegramApplGroups.yaml#application_groups",
                        "${HOME}/.ln/config/devicesDB/source/telegramChannels.yaml#channels",
                    ]
    '''



    from ColoredLogger_V103 import setColoredLogger, testLogger
    import FileLoader
    from benedict import benedict
    from datetime import datetime # , timedelta
    import platform
    import socket



    tmp_dir=f"/tmp/{prj_name}"
    config_file=f"{tmp_dir}/config.yaml"
    with open(config_file, "w") as f:
        f.write(yaml_conf)


    # ---- Loggging
    logger=setColoredLogger(logger_name=prj_name,
                            console_logger_level="info",
                            file_logger_level=None,
                            logging_dir=None, # logging file--> logging_dir + logger_name
                            threads=False,
                            create_logging_dir=True)
    testLogger(logger)
    logger.info('------- Starting -----------')
    logger.warning(__ln_version__)



    gv=benedict(keyattr_enabled=True, keyattr_dynamic=False) # copy all input args to gv
    gv.logger               = logger
    gv.OpSys: str           = platform.system()
    gv.prj_name: str        = prj_name
    gv.search_paths: list   = ['conf']
    gv.date_time: str       = datetime.now().strftime("%Y%m%d_%H%M")
    os.environ['DATE_TIME'] = gv.date_time


    config=FileLoader.loadConfigurationData(config_file=config_file, tmp_dir=tmp_dir, gVars=gv)

    devices_data=config.pop("devices_data")
    devicesDB=devicesDB_Class(db_data=devices_data, error_on_duplicate=True, save_on_file=True, logger=logger, prj_name=prj_name)
    """instantiate deviceaDB class (crea gli indici per alcuni attributi) """

    broker=devicesDB.getBroker()
    broker.py()
    # print(config.py())
    sys.exit()

