#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 29-08-2023 18.34.28
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
from types import SimpleNamespace
from benedict import benedict
import time

from datetime import datetime
import ipaddress
import LnUtils



##################################################################
# tg_data nel caso abbia già i dati....
##################################################################
class devicesDB_Class():
    """docstring for SendTelegram"""
    def __init__(self, *, db_data: dict, logger, error_on_duplicate: bool=True, save_on_file: bool=False, prj_name: str=None):
        assert isinstance(db_data, benedict)
        self.prj_name=prj_name if prj_name else "devicesDB"
        LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/devicesDB_config.yaml", data=db_data, replace=True, write_datetime=True)


        self.logger=logger
        self.logger.info('devicesDB class has been instantied!')

        self.db_data=db_data
        self.devices=self.getDevices()


        self.error_on_duplicate=error_on_duplicate

        self.tasmota_index_dict={}
        self.shelly_index_dict={}
        self.appltg_index_dict={}
        self.channel_index_dict={}
        self.alltg_index_dict={}
        self.ip_index_dict={}
        self.mac_index_dict={}


        # self.createIndexes(base_keypath=["devices_data", "devices"])
        self.createIndexes(base_keypath=[])
        self._TgGroups()



        if save_on_file:
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/indexes/devtgGroups_index.yaml",     data=self.tasmota_index_dict, replace=True, write_datetime=True)
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/indexes/shelly_tgGroups_index.yaml", data=self.shelly_index_dict,  replace=True, write_datetime=True)
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/indexes/applTgGroups_index.yaml",    data=self.appltg_index_dict,  replace=True, write_datetime=True)
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/indexes/channels_index.yaml",        data=self.channel_index_dict, replace=True, write_datetime=True)
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/indexes/allTgGroups_index.yaml",     data=self.alltg_index_dict,   replace=True, write_datetime=True)
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/indexes/ip_index.yaml",              data=self.ip_index_dict,      replace=True, write_datetime=True)
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/indexes/mac_index.yaml",             data=self.mac_index_dict,     replace=True, write_datetime=True)


    def getDevices(self):
        return self.db_data["devices"]

    def getBroker(self):
        return self.db_data["broker"]

    def getBots(self):
        return self.db_data["bots"]


    def _TgGroups(self, fSort: bool=False, save_on_file: (bool, str)=False):
        if not hasattr(self, "tgGroups"):
            self.tgGroups=self._getData(db_type="all_tg_groups", fSort=fSort, save_on_file=save_on_file)

        return self.tgGroups



    def getBot(self, group_name: str):
        bot={}
        # tg=self.tgData.group_name.get("tg_Group", {})
        device=self.tgGroups.get(group_name)
        if device:
            bot['bot_name']   = device["bot.bot_name"]
            bot['token']      = device["bot.token"]
            bot['chat_id']    = device["chat_id"]
            bot['group_name'] = device["group_name"]

        return bot

    def getTgData(self, group_name: str) -> dict:
        device=self.tgGroups.get(group_name)
        if device:
            tg=benedict(keyattr_enabled=True, keyattr_dynamic=False)
            tg=device.tg_Group
        else:
            self.logger.error("%s group_name was not found in devicesDB", group_name)
            tg={}


        return tg


    #####################################################################
    #
    #####################################################################
    def getDevice(self, name: str=None, mac: str=None, ip: str=None, ignore_case=False) -> dict:
        if mac and not ":" in mac:
            mac=':'.join(mac[i:i+2] for i in range(0,12,2))

        for key in self.devices.keys():
            device=self.devices[key] ### per mantenere benedict

            if name and device.get("name", "").lower()==name.lower():
                return device
            elif mac and device.get("mac", "").lower()==mac.lower():
                return device
            elif ip and device.get("ip", "").lower()==ip.lower():
                return device


        return None



    """ #####################################
     - devicesDB_Indexes version: 21-07-2023 09.30.09 (from dhcpDns.Source.Modules.devicesDB.py)

      create a dictionary for MAC, IP, tgGroups, applTgGroups:
            for each of them:
                key_name:
                       group_name op ip_address
                value:
                       "keypath.to.device"            if dot_keypath is True
                        ["keypath", "to", "device"]   if dot_keypath is False
    Examples:
        IP_3232235787_192_168_1_11:
        - devices_data
        - devices
        - Mac_5CA6E60C35AA

        LnAleBot_Client:
        - devices_data
        - devices
        - LnAleBot_Client

        00:31:92:81:A4:88:
        - devices_data
        - devices
        - Mac_00319281A488
    #####################################"""
    def createIndexes(self, base_keypath: (str, list)):
        # ---------------------------------------
        def update_index_dict(d: dict, key: str, record_key_path: str):
            if self.error_on_duplicate:
                if key in d.keys():
                    self.logger.error("duplicate key %s on record: %s", key, record_key_path)
                    sys.exit(1)
            d[key]=record_key_path
        # ---------------------------------------
        devices=self.getDevices()

        ### moving to base_keypath dictionary path
        devices_index_dict={}
        if base_keypath:
            if isinstance(base_keypath, list):
                dot_keypath: bool=False
                _keypath=base_keypath[:]

            elif isinstance(base_keypath, str):
                dot_keypath: bool=True
                _keypath=base_keypath.split('.')

            else:
                return

            devices_index_dict=devices[_keypath[0]]
            for key in _keypath[1:]:
                devices_index_dict=devices_index_dict[key]
        else:
            dot_keypath: bool=True
            devices_index_dict=devices




        for dev_name, device in devices_index_dict.items():
            if base_keypath:
                record_key_path=f"{base_keypath}.{dev_name}" if dot_keypath is True else base_keypath + [dev_name]
            else:
                record_key_path=dev_name if dot_keypath is True else [dev_name]

            if "tg_Group" in device:
                group_name=device["tg_Group"]["group_name"]
                group_type=device["tg_Group"]["type"]
                dev_type=device["type"]


                if dev_type=="tasmota":
                    update_index_dict(d=self.tasmota_index_dict, key=group_name, record_key_path=record_key_path)

                elif dev_type=="shelly":
                    update_index_dict(d=self.shelly_index_dict, key=group_name, record_key_path=record_key_path)

                elif dev_type=="application":
                    if group_type=="group":
                        update_index_dict(d=self.appltg_index_dict, key=group_name, record_key_path=record_key_path)

                    elif group_type=="channel":
                        update_index_dict(d=self.channel_index_dict, key=group_name, record_key_path=record_key_path)

                update_index_dict(d=self.alltg_index_dict, key=group_name, record_key_path=record_key_path)

            if "mac" in device:
                mac_addr=device["mac"]
                update_index_dict(d=self.mac_index_dict, key=mac_addr, record_key_path=record_key_path)


            if "ip" in device:
                ip_addr=device["ip"]
                try:
                    ip_hash=int(ipaddress.ip_address(ip_addr)) # reverse....: print(ipaddress.IPv4Address(ip_hash))
                except:
                    self.logger.error("%s: %s - is not a valid ip address", ip_addr, record_key_path)
                    sys.exit()

                ip_addr=ip_addr.replace('.', '_')
                ip_key=f"IP_{ip_hash}_{ip_addr}"
                update_index_dict(d=self.ip_index_dict, key=ip_key, record_key_path=record_key_path)






    ###########################################################################
    # ricrea il dictionary per la sola parte indicata dal db_type
    ###########################################################################
    def _getData(self, db_type: str, just_index: bool=False, fSort: bool=False, save_on_file: (bool, str)=False):
        if   db_type=="ip":               db_index=self.ip_index_dict
        elif db_type=="mac":              db_index=self.mac_index_dict
        elif db_type=="tasmota_tg_groups":db_index=self.tasmota_index_dict
        elif db_type=="shelly_tg_groups": db_index=self.shelly_index_dict
        elif db_type=="all_tg_groups":    db_index=self.alltg_index_dict


        devices=self.getDevices()
        if fSort:
            db_index=dict(sorted(db_index.items()))


        if just_index:
            ret_dict=db_index
        else:
            ### creazione del dict con il valori dei record
            ret_dict=benedict(keyattr_enabled=True, keyattr_dynamic=False)
            for key, value in db_index.items():
                record_name=key
                ret_dict[record_name]=devices[value]


        if save_on_file is True:
            LnUtils.writeFile(filepath=f"/tmp/{self.prj_name}/{db_type}.yaml", data=ret_dict, replace=True, write_datetime=True)
        elif save_on_file:
            LnUtils.writeFile(filepath=str(save_on_file), data=ret_dict, replace=True, write_datetime=True)

        return ret_dict



    def get_IP(self, fSort: bool=False, save_on_file: (bool, str)=False):
        return self._getData(db_type="ip", fSort=fSort, save_on_file=save_on_file)

    def get_tasmotaTgGroups(self, fSort: bool=False, save_on_file: (bool, str)=False):
        return self._getData(db_type="tasmota_tg_groups", fSort=fSort, save_on_file=save_on_file)

    def get_shellyTgGroups(self, fSort: bool=False, save_on_file: (bool, str)=False):
        return self._getData(db_type="shelly_tg_groups", fSort=fSort, save_on_file=save_on_file)





    def get_IP_index(self, fSort: bool=False, save_on_file: (bool, str)=False):
        return self._getData(db_type="ip", just_index=True, fSort=fSort, save_on_file=save_on_file)

    def get_tasmotaTgGroups_index(self, fSort: bool=False, save_on_file: (bool, str)=False):
        return self._getData(db_type="tasmota_tg_groups", just_index=True, fSort=fSort, save_on_file=save_on_file)

    def get_shellyTgGroups_index(self, fSort: bool=False, save_on_file: (bool, str)=False):
        return self._getData(db_type="shelly_tg_groups", just_index=True, fSort=fSort, save_on_file=save_on_file)

    def get_allTgGroups_index(self, fSort: bool=False, save_on_file: (bool, str)=False):
        return self._getData(db_type="all_tg_groups", just_index=True, fSort=fSort, save_on_file=save_on_file)





#######################################################
#
#######################################################
if __name__ == '__main__':

    yaml_conf='''
    devices_data:
        bots: !include "conf/telegramBots.lnk.yaml#bots"
        devices:
            !include_merge [
                    "${HOME}/.ln/config/devicesDB/source/Computers.lnk.yaml#raspberry",
                    "${HOME}/.ln/config/devicesDB/source/Computers.lnk.yaml#pc",
                    "${HOME}/.ln/config/devicesDB/source/Cellulari.lnk.yaml#cellulari",
                    "${HOME}/.ln/config/devicesDB/source/Printers.lnk.yaml#printers",
                    "${HOME}/.ln/config/devicesDB/source/Routers.lnk.yaml#routers",
                    "${HOME}/.ln/config/devicesDB/source/Tasmota.lnk.yaml#tasmota",
                    "${HOME}/.ln/config/devicesDB/source/Telecamere.lnk.yaml#telecamere",
                    "${HOME}/.ln/config/devicesDB/source/TV.lnk.yaml#tv",
                    "${HOME}/.ln/config/devicesDB/source/Varie.lnk.yaml#varie",
                    "${HOME}/.ln/config/devicesDB/source/telegramApplGroups.lnk.yaml#application_groups",
                    "${HOME}/.ln/config/devicesDB/source/telegramChannels.lnk.yaml#channels",
                ]
    '''



    prj_name="deviceDB"

    config={"main_key": gv.data_db}
    indexes_index_dict=Indexes(data=config, base_keypath="main_key.devices", save_on_file=True)

