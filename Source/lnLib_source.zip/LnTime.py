#!/usr/bin/python
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

import sys; sys.dont_write_bytecode=True
import time
# import datetime
from  datetime import datetime, timedelta



def test():
    import time
    token1='tele';token2='STATE'

    t = time.process_time()
    for j in range(1000000):
        [token1, token2]==['tele', 'STATE']
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    t = time.process_time()
    for j in range(1000000):
        token1=='tele' and token2=='STATE'
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    t = time.process_time()
    for j in range(1000000):
        token1 + token2=='tele' + 'STATE'
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    t = time.process_time()
    for j in range(1000000):
        f'{token1}.{token2}'=='tele.STATE'
    elapsed_time = time.process_time() - t
    print(elapsed_time)

    sys.exit()




def sum_offset(t0_time, offset):
    offset_HH, offset_MM=offset.split(':')
    offset_minutes=abs(int(offset_HH))*60+int(offset_MM)
    if offset_minutes==0:
        return t0_time

    t0_HH, t0_MM=t0_time.split(':')
    t0=timedelta(hours=int(t0_HH), minutes=int(t0_MM))
    ofs=timedelta(hours=int(offset_HH), minutes=int(offset_MM))

    if offset[0]=='-':
        new_time=t0-ofs
    else:
        new_time=t0+ofs

    td=str(timedelta(seconds=new_time.total_seconds()))
    xx=':'.join(str(td).split(':')[:2])
    self.logger.warningln('summming offset:', {
        'time  ': t0_time,
        'offset': offset,
        'result': xx
        })
    return xx


### dt1-dt2
def seconds_diff_datetime(dt1, dt2):
    epoch_time1=dt1.timestamp()
    epoch_time2=dt2.timestamp()
    return epoch_time1-epoch_time2

def epochToDatetime(epochTime):
    return datetime.fromtimestamp( epochTime)

def epochToStr(epochTime, formatStr='%Y/%m/%d %H:%M:%S'):
    dt=datetime.fromtimestamp( epochTime)
    return dt.strftime(formatStr)




def datetimeToEpoch(my_time):
    return my_time.timestamp()

def datetimeToStr(dt, formatStr='%Y/%m/%d %H:%M:%S'):
    return dt.strftime(formatStr)





def secs_to_DHMS(seconds):
    if isinstance(seconds, (int,float)):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        d, h = divmod(h, 24)
        return f'{d}T{h:02}:{m:02}:{s:02}'
    else:
        return ''

def secs_to_HMS(seconds):
    if isinstance(seconds, (int,float)):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        return f'{h:02}:{m:02}:{s:02}'
    else:
        return ''


def secs_to_HM(seconds):
    if isinstance(seconds, (int,float)):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        return f'{h:02}:{m:02}'
    else:
        return ''

def str_to_datetime(date_str: str=None, date_format="%d/%m/%Y",
                    time_str: str=None, time_format="%H:%M:%S",
                    return_format: str="%Y/%m/%d %H:%M:%S"):

    dt=datetime.now()
    try:
        if date_str:
            _dt=datetime.strptime(date_str, date_format)
            dt=dt.replace(year=_dt.year, day=_dt.day, month=_dt.month)

        if time_str:
            _dt=datetime.strptime(time_str, time_format)
            dt=dt.replace(hour=_dt.hour, minute=_dt.minute, second=_dt.second)

    except:
        return_format="ERROR"

    ret_val=dt.strftime(return_format)
    return ret_val


def millisecs_to_HMS_ms(milliseconds, strip_leading=False):
    s, ms = divmod(milliseconds, 1000)
    m, s = divmod(s, 60)
    h, m = divmod(m, 60)

    hours=int(h)
    minutes=int(m)
    seconds=int(s)
    milliseconds=int(ms)

    ret_val=f'{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:01}'
    if strip_leading:
        if h==0 and minutes==0:
            ret_val=f'{seconds:02}.{milliseconds:01}'
        elif h==0:
            ret_val=f'{minutes:02}:{seconds:02}.{milliseconds:01}'

    return ret_val



def get_uptime():
    with open('/proc/uptime', 'r') as f:
        uptime_seconds = float(f.readline().split()[0])

    return uptime_seconds


def get_boottime():
    """A way to figure out the boot time directly on Linux."""
    boot_time=0
    try:
        f = open('/proc/stat', 'r')
        for line in f:
            if line.startswith('btime'):
                boot_time = int(line.split()[1])

        return datetime.fromtimestamp(boot_time)
    except (IOError, IndexError):
        return None


'''
    now_secs=int(time.time())
    now=time.strftime("%Y/%m/%d %H:%M:%S")
    hh=time.strftime("%H")
    mm=time.strftime("%M")
'''

if __name__ == '__main__':
    print(str_to_datetime(date_str=None, date_format=None, time_str=None, time_format="%H:%M:%S", return_format="%Y/%m/%d %H:%M:%S"))
    print(str_to_datetime(time_str="09:56", time_format="%H:%M", return_format="%Y/%m/%d %H:%M:%S"))
    print(str_to_datetime(time_str="09:56:52", time_format="%H:%M:%S", return_format="%Y-%m-%d %H:%M:%S"))
    print(str_to_datetime(time_str="09:63:52", time_format="%H:%M:%S", return_format="%Y-%m-%d %H:%M:%S"))

