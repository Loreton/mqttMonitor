#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

import sys; sys.dont_write_bytecode=True
import os


import time
import datetime


##########################################
#
##########################################
class nullLogger():
    def dummy(title, *args, **kwargs):
        # import yaml
        # if title: print(title)
        # if args: print(yaml.dump(args, indent=4))
        # if kwargs: print(yaml.dump(kwargs, indent=4) )
        pass
    critical=error=warning=info=debug=dummy




class TimerLN(object):
    """Timer to simplify timing of execution."""

    def __init__(self, name, default_time=0, start=False, stacklevel=3, logger=nullLogger()):
        self.logger=logger
        self.name=name
        self.default=default_time
        self.timer_value=0
        self.start_time=0
        self.elapsed=0
        self.remaining=0
        self._check_timer()

        self._displayTimers(text_message='init', stacklevel=stacklevel)


    def _check_timer(self):
        now=time.time()
        if self.timer_value>0:
            self.elapsed=now-self.start_time
            self.remaining=self.timer_value-self.elapsed
            if self.remaining <= 0:
                self.stop()




    def _displayTimers(self, *, text_message="", stacklevel=3):
        # self._check_timer()
        if self.elapsed==0 and self.remaining==0:
            ### in %5.1f, the 5 is the number of characters allocated for the ENTIRE number,
            self.logger.debug('[Timer "%s" value=%7.2f]:  is NOT active', self.name, self.timer_value, stacklevel=stacklevel)
        else:
            # self.logger.debug('[Timer "%s" value=%7.2f]: %s elapsed=%7.2f  remaining=%7.2f', self.name, self.timer_value, text_message, self.elapsed, self.remaining, stacklevel=3)
            self.logger.debug('"%s" timer:  elapsed=%.2f  remaining=%.2f - %s with seconds=%.2f', self.name, self.elapsed, self.remaining, text_message, self.timer_value, stacklevel=stacklevel)


    def restart(self, seconds=0, stacklevel=4):
        self.start(seconds=seconds, stacklevel=stacklevel)

    def start(self, seconds=0, stacklevel=3):
        # import pdb; pdb.set_trace();trace=True # by Loreto
        self._check_timer()
        self.timer_value=seconds if seconds>0 else self.default
        self.start_time=time.time()
        self.running=True
        self._displayTimers(text_message='restarting', stacklevel=stacklevel)

    def stop(self, stacklevel=3):
        # self._check_timer() NO altrimentri va in recursive loop
        self.timer_value=0
        self.start_time=0
        self.running=False
        self.remaining=0
        self.elapsed=0
        self._displayTimers(text_message='stopped', stacklevel=stacklevel)

    def remaining_time(self, stacklevel=3):
        self._displayTimers(text_message='running', stacklevel=stacklevel)
        return self.remaining

    def remainingTime(self, stacklevel=3):
        self._check_timer()
        self._displayTimers(text_message='running', stacklevel=stacklevel)
        return self.remaining

    def isExausted(self, stacklevel=3):
        self._check_timer()
        return not self.running

    def isRunning(self, stacklevel=3):
        self._check_timer()
        return self.running




def simple_coloredLogger(logger_name, logger_level, test=False):
    import colorlog  # https://pypi.org/project/colorlog/
    import logging
    logger_level=logger_level.upper()

    # ------- Formatter ---------------------
    def getFormatter():
        formatter=colorlog.ColoredFormatter(
            """%(cyan)s%(asctime)s %(log_color)s[%(levelname)4s] - %(blue)s[%(module)s.%(funcName)s:%(lineno)4s]: %(log_color)s%(message)s""",
            datefmt="%H:%M:%S",
            reset=True,
            log_colors={
                'TRACE':    'yellow',
                'DEBUG':    'cyan',
                'debug':   'fg_bold_cyan',
                'INFO':     'green',
                'FUNCTION': 'purple',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CRITICAL': 'red,bg_white',
            },
            secondary_log_colors={},
            style='%'
        )
        return formatter
    # ------- Formatter ---------------------


    # --------- Adding debug level -------------------
    def adddebugLevel(level):
        logging.debug=level
        def _debug(logger, message, *args, **kwargs):
            if logger.isEnabledFor(logging.debug):
                logger._log(logging.debug, message, args, **kwargs)
        logging.Logger.debug = _debug
        logging.addLevelName(logging.debug, "debug")
    # --------- Adding debug level -------------------



    adddebugLevel(level=33)

    handler=logging.StreamHandler()
    handler.setFormatter(getFormatter())

    logger = logging.getLogger(logger_name)
    logger.addHandler(handler)
    logger.setLevel(logger_level)
    logger.propagate = False # se messo a True mi trovo due righe di log, una colorata e l'altra no.

    return logger





if __name__ == '__main__':
    logger=simple_coloredLogger(logger_name='ciao', logger_level='info')

    t1=TimerLN(name="timer_01", default_time=50.1, logger=logger)
    t2=TimerLN(name="timer_02", default_time=80.4, logger=logger)

    t1.start(seconds=10.5)
    while False:
        if t1.remaining_time <= 0:
            sys.exit()
        time.sleep(2)


    t1.start(12)
    t2.start(9)
    while True:
        if t1.remaining_time <= 0:
            t1.stop()
        if t2.remaining_time <= 0:
            t2.stop()

        # sys.exit()

        time.sleep(2)
        print()

