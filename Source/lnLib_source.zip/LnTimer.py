#!/usr/bin/python
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

import sys; sys.dont_write_bytecode=True
import os


import time
import datetime


##########################################
#
##########################################
class nullLogger():
    def dummy(title, *args, **kwargs):
        # import yaml
        # if title: print(title)
        # if args: print(yaml.dump(args, indent=4))
        # if kwargs: print(yaml.dump(kwargs, indent=4) )
        pass
    critical=error=warning=info=debug=dummy




class TimerLN(object):
    """Timer to simplify timing of execution."""

    def __init__(self, name, default_time=0, start=False, logger=nullLogger()):
        self.logger=logger
        self.name=name
        self.default=default_time
        self.timer_value=0
        self.start_time=0

        self._displayTimers(text_message='init')


    def _check_timer(self):
        now=time.time()
        if self.timer_value>0:
            self.elapsed=now-self.start_time
            self.remaining=self.timer_value-self.elapsed
            self.is_running=True
        else:
            self.is_running=False
            self.elapsed=0
            self.remaining=0



    def _displayTimers(self, *, text_message=""):
        self._check_timer()
        if self.elapsed==0 and self.remaining==0:
            ### in %5.1f, the 5 is the number of characters allocated for the ENTIRE number,
            self.logger.notify('[Timer "%s" value=%7.2f]:  is NOT active', self.name, self.timer_value, stacklevel=3)
        else:
            self.logger.notify('[Timer "%s" value=%7.2f]:  elapsed=%7.2f  remaining=%7.2f', self.name, self.timer_value, self.elapsed, self.remaining, stacklevel=3)


    def start(self, seconds=0):
        self.timer_value=seconds if seconds>0 else self.default
        self.start_time=time.time()
        self._displayTimers(text_message='started')

    def stop(self):
        self.timer_value=0
        self.start_time=0
        self._displayTimers(text_message='stopped')

    restart=start

    def remaining_time(self):
        self._displayTimers(text_message='running')
        return self.remaining




def simple_coloredLogger(logger_name, logger_level, test=False):
    import colorlog  # https://pypi.org/project/colorlog/
    import logging
    logger_level=logger_level.upper()

    # ------- Formatter ---------------------
    def getFormatter():
        formatter=colorlog.ColoredFormatter(
            """%(cyan)s%(asctime)s %(log_color)s[%(levelname)4s] - %(blue)s[%(module)s.%(funcName)s:%(lineno)4s]: %(log_color)s%(message)s""",
            datefmt="%H:%M:%S",
            reset=True,
            log_colors={
                'TRACE':    'yellow',
                'DEBUG':    'cyan',
                'NOTIFY':   'fg_bold_cyan',
                'INFO':     'green',
                'FUNCTION': 'purple',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CRITICAL': 'red,bg_white',
            },
            secondary_log_colors={},
            style='%'
        )
        return formatter
    # ------- Formatter ---------------------


    # --------- Adding NOTIFY level -------------------
    def addNotifyLevel(level):
        logging.NOTIFY=level
        def _notify(logger, message, *args, **kwargs):
            if logger.isEnabledFor(logging.NOTIFY):
                logger._log(logging.NOTIFY, message, args, **kwargs)
        logging.Logger.notify = _notify
        logging.addLevelName(logging.NOTIFY, "NOTIFY")
    # --------- Adding NOTIFY level -------------------



    addNotifyLevel(level=33)

    handler=logging.StreamHandler()
    handler.setFormatter(getFormatter())

    logger = logging.getLogger(logger_name)
    logger.addHandler(handler)
    logger.setLevel(logger_level)
    logger.propagate = False # se messo a True mi trovo due righe di log, una colorata e l'altra no.

    return logger





if __name__ == '__main__':
    logger=simple_coloredLogger(logger_name='ciao', logger_level='info')

    t1=TimerLN(name="timer_01", default_time=50.1, logger=logger)
    t2=TimerLN(name="timer_02", default_time=80.4, logger=logger)

    t1.start(seconds=10.5)
    while False:
        if t1.remaining_time <= 0:
            sys.exit()
        time.sleep(2)


    t1.start(12)
    t2.start(9)
    while True:
        if t1.remaining_time <= 0:
            t1.stop()
        if t2.remaining_time <= 0:
            t2.stop()

        # sys.exit()

        time.sleep(2)
        print()

