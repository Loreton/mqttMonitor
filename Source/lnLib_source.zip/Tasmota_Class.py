#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 03-05-2024 15.11.21
#
import  sys; sys.dont_write_bytecode = True
import os
import json, yaml
from types import SimpleNamespace
from datetime import datetime
from benedict import benedict
import time

if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Utils')

from LnTime import seconds_diff_datetime
from LnTimer import TimerLN as LnTimer
import Tasmota_Telegram_Notification as tgNotify
# from    devicesDB import devicesDB_Class, Tasmota_DeviceDB_Class


from devicesDB_sqLite import devicesDB_Class, Tasmota_DeviceDB_Class




class TasmotaClass:
    def __init__(self, gVars: (dict, SimpleNamespace), obj_device: Tasmota_DeviceDB_Class):

        clean_device_data = gVars.args.clean_device_data

        self.obj_device              = obj_device
        self.device_name             = self.obj_device.name
        self.logger                  = gVars["logger"]
        self.mqttmonitor_runtime_dir = gVars["mqttmonitor_runtime_dir"]

        # define filenames
        self.device_file_json        = f"{self.mqttmonitor_runtime_dir}/{self.device_name}.json"
        self.device_file_yaml        = f"{self.mqttmonitor_runtime_dir}/{self.device_name}.yaml"



        ### lettura file oppure default dict
        dev_data=self.loadDeviceFile()

        ### add device section
        if clean_device_data or self.device_name not in dev_data:
            dev_data[self.device_name]={}

        ### convert to benedict
        self.full_device=benedict(dev_data)
        self.full_device.update({"staticDevice": self.obj_device.__dict__}) # inseriamo nel runtime object


        ### create fast pointers
        self.loretoData=self.full_device['Loreto']
        if not 'STATE' in self.loretoData: self.loretoData['STATE']={}

        self.liveData=self.full_device[self.device_name]
        if not 'STATE' in self.liveData: self.liveData['STATE']={}


        self.telegramNotification(seconds=.1)

        self.savingData_start_time=time.time()
        self.savingData_period=gVars.args.save_period





    ###################################################################
    # Carichiamo solo i dati sommari sotto la key: Loreto
    ###################################################################
    def loadDeviceFile(self):
        # if not filename:
        #     filename=self.device_file_json

        base_device=f"""
            Loreto:
                file_out: {self.device_file_json}
                last_update: "2011-12-13T01:02:03"
                device_name: {self.device_name}
                topic_name:  {self.device_name}
                modello: ""
                firmware: ""
                STATE:
                    Time: "2022-12-16T11:40:27"
                    Uptime: N/A
                    UptimeSec: 0
                    Heap: 25
                    SleepMode: Dynamic
                    Sleep: 50
                    LoadAvg: 19
                    MqttCount: 3
                    POWER1: N/A
                    Wifi:
                        AP: 1
                        SSId: N/A
                        BSSId: N/A
                        Channel: 10
                        Mode: N/A
                        RSSI: 1
                        Signal: -1
                        LinkCount: 2
                        Downtime: N/A

                NET:
                    IPAddress: N/A
                    Gateway: N/A
                    Subnetmask: N/A
                    DNSServer1: N/A
                    DNSServer2: N/A
                    Mac: 112233445566

                relays:         [1, 0, 0, 0, 0, 0, 0, 0 ]
                friendly_names:  ["Relay_01", "Relay_02", "Relay_03", "Relay_04", "Relay_05", "Relay_06", "Relay_07", "Relay_08"]
                PulseTime:
                    "Set":       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
                    "Remaining": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
        """
                # Wifi: {dict()}
        device=None
        # if os.path.exists(filename) and os.stat(filename).st_size>0:
        #     with open(filename, 'r') as fin:
        #         device=json.load(fin)
        #         if not 'Loreto' in device:
        #             device=None

        if not device:
            device=yaml.load(base_device, Loader=yaml.SafeLoader)
            if self.obj_device.tasmota.nr_relays==1:
                device["Loreto"]["relays"]=[1]
            elif self.obj_device.tasmota.nr_relays==2:
                device["Loreto"]["relays"]=[1, 1]
            device["Loreto"]["friendly_names"]=self.obj_device.tasmota.friendly_names

        return device



    ##################################################################
    ##################################################################
    #    U P D A T E    functions
    ##################################################################
    ##################################################################

    ##########################################################
    # Invia un summary status per tutti i device
    ##########################################################
    def sendStatus(self, payload):
        gv.logger.debug("Sending summary for %s to Telegram", self.device_name)
        tgNotify.telegram_notify(tasmotaObj=self, payload=payload)





    ################################################
    ###
    ################################################
    def processMqttMessage(self, full_topic: str, payload: dict, mqttClient_CB):
        prefix, topic_name, suffix, *rest=full_topic.split('/')
        assert (self.device_name == topic_name)
        # self.logger.notify(full_topic)
        # self.logger.notify(payload)


        ### -----------------------------------------------
        ### skip some topics
        ### -----------------------------------------------
        if prefix == 'cmnd' or topic_name in ['tasmotas']:
            self.logger.warning('skipping topic: %s [in attesa di capire meglio come sfruttarlo]', full_topic)
            return



        ### -----------------------------------------------
        ### comandi derivanti da altre applicazioni per ottenere info
        ### da inviare a telegram group
        ### -----------------------------------------------
        elif prefix=='LnTelegram':
            # tgNotify.telegram_notify(deviceObj=self, topic_name=topic_name, payload=payload)
            tgNotify.telegram_notify(tasmotaObj=self, payload=payload)
            return



        ### dati che arrivano direttamente da tasmota
        elif prefix=='stat':
            if suffix=='POWER': ### payload is string
                ''' skip perchè prendiamo il topic con json payload 'stat/xxxx/RESULT {"POWER": "OFF"}' '''
                pass

            elif suffix.startswith('STATUS'):    ### incude tutti gli STATUSx
                self.updateDevice(key_path='STATUS', data=payload, writeOnFile=True)

            elif suffix=='RESULT':  ### in caso di RESULT dobbiamo analizzare il payload
                action=None  ### action indica se dobbiamo inviare un messaggio a telegram

                power_key=payload.find_in_key(substr='POWER', first_match=True)
                pulsetime_key=payload.find_in_key(substr='PulseTime', first_match=True)
                timer_key=payload.find_in_key(substr='Timer', first_match=True)


                if power_key:
                    self.updateDevice(key_path=None, data=payload, writeOnFile=True)
                    action='power_in_payload'

                ### Tested
                elif pulsetime_key:
                    self.updateLoreto_PulseTime(key_name=pulsetime_key, data=payload)
                    action='pulsetime_in_payload'

                elif 'PowerOnState' in payload:
                    action='poweronstate_in_payload'

                elif 'Timers' in payload: ### full timers display
                    self.updateDevice(key_path="TIMERS", data=payload, writeOnFile=True)
                    action='timers_in_payload'

                elif timer_key and timer_key != 'Timers': ### single timer display
                    self.updateDevice(key_path=f"TIMERS", data=payload, writeOnFile=True)
                    action='single_timer_in_payload'


                elif 'SSId1' in payload:
                    self.updateLoreto_SSID(data=payload)
                    action='ssid_in_payload'

                elif 'IPAddress1' in payload:
                    action='ipaddress_in_payload'

                ### process data
                if action:
                    self.logger.info('%s: %s', topic_name, action)
                    tgNotify.in_payload_notify(tasmotaObj=self, action=action, payload=payload)

        ### Tested
        elif prefix=='tele':

            if suffix=='STATE':
                self.updateDevice(key_path="STATE", data=payload, writeOnFile=True)

            elif suffix=='LWT':
                self.updateDevice(key_path="LWT", data=payload, writeOnFile=True)

            elif suffix=='HASS_STATE':
                pass

        elif prefix=='tasmota':
            if suffix in ['sensors', 'config']:
                self.updateDevice(key_path="Config", data=payload, writeOnFile=True)

        else:
            self.logger.warning("topic: %s not managed - payload: %s", full_topic, payload)

















    ################################################
    ### add/update payload to device
    ### crea entry con la key richiesta
    ################################################
    def updateDevice(self, key_path: str, data: dict, writeOnFile=False):

        if not isinstance(data, dict):
            self.logger.warning("data is not dictionary: %s", data)
            return

        self.logger.debug("updating device data: %s", data.to_json())

        if not key_path:
            keys=list(data.keys())

            ### aggiungiamola a LoretoDB
            if len(keys)==1:
                single_key='SingleKey'

                if 'POWER' in single_key:
                    self.updateLoreto_POWER(data=data)

                else:
                    if single_key not in self.loretoData:
                        self.loretoData[single_key]=benedict()

                    self.loretoData[single_key].update(data)

            elif 'Time' in data and 'Wifi' in data:
                key_path='STATE' ### è uno state che arriva solo al momento della connect al broker

            else:
                self.logger.caller('should not occurs', stacklevel=1)
                self.logger.caller('payload: %s', data.to_yaml())
                return



        if key_path:
            if key_path not in self.liveData:
                self.liveData[key_path]=benedict()

            self.liveData[key_path].update(data)


        ### aggiorniamo anche il loretoDB  lo STATE visto che

        if key_path=='STATE':
            self.logger.debug("updating STATE: %s", data)
            self.loretoData['STATE'].update(data)
            self.loretoData['last_update']=data['Time']


        elif 'StatusSTS' in data: ### StatusSTS==STATE
            self.logger.debug("updating StatusSTS: %s", data)
            statusSTS=data['StatusSTS']
            self.loretoData['STATE'].update(statusSTS)
            self.liveData['STATE'].update(statusSTS)
            self.loretoData['last_update']=statusSTS['Time']

        elif 'StatusNET' in data:
            self.logger.debug("updating StatusNET: %s", data)
            net=data['StatusNET']
            self.loretoData["NET"].update(data['StatusNET'])

        elif 'StatusPRM' in data:
            pass
            # import pdb; pdb.set_trace(); pass # by Loreto

        elif key_path=='Config':
            self.updateLoreto_Config(data=data)

        self.savingDataOnFile(forceWrite=writeOnFile)



    ################################################################
    #
    ################################################################
    def updateLoreto_POWER(self, data: dict):
        self.logger.debug("updating Loreto_power: %s", data)
        for relay in range(self.nRelays):
            key=f'POWER{relay+1}'
            if key in data:
                self.loretoData['STATE'][key]=data[key]



    ################################################################
    # {"PulseTime1":{"Set":0,"Remaining":0}}
    # {"PulseTime":{"Set":[111,0,0,0,0...],"Remaining":[0,0,0...]
    ################################################################
    def updateLoreto_PulseTime(self, key_name: str, data: dict):

        loreto_set=self.loretoData['PulseTime.Set']
        loreto_remaining=self.loretoData['PulseTime.Remaining']

        ### copiamo solo i pulsetime relativi al numero di relays
        if key_name=='PulseTime':
            self.loretoData['PulseTime.Set']=data['PulseTime.Set'][:self.nRelays()]
            self.loretoData['PulseTime.Remaining']=data['PulseTime.Remaining'][:self.nRelays()]

        ### modifichiamo il singolo Set[x]
        else:
            relay_nr=int(key_name[-1])-1
            if relay_nr in range(self.nRelays()):
                loreto_set[relay_nr]       = data[key_name]['Set']
                loreto_remaining[relay_nr] = data[key_name]['Remaining']



    ################################################################
    #
    ################################################################
    def updateLoreto_SSID(self, data: dict):
        self.loretoData['SSID']=data



    ################################################################
    #
    ################################################################
    def updateLoreto_Config(self, data: dict):
        if 'sn' in data:
            pass
        else:
            _dict=self.loretoData
            _dict['relays']           = [x for x in data['rl'] if x == 1]
            _dict['friendly_names']   = [x for x in data['fn'] if (x != '' and x != None)]
            _dict['device_name']      = data['dn']
            _dict['topic_name']       = data['t']
            _dict['modello']          = data['md']
            _dict['firmware']         = data['sw']


            _dict['NET.IPAddress']        = data['ip']
            _dict['NET.Mac']              = data['mac'] # formato senza punti ... da modificare



    ################################################################
    # Blocca le notifiche verso telegram
    # Utile quando si inviano diversi comandi al device
    ################################################################
    def telegramNotification(self, seconds: float=0) -> bool:
        if seconds:
            self.telegram_notification=time.time() + seconds

        remaining=self.telegram_notification-time.time()
        self.logger.info("telegramNotification remaining secs: %s", remaining)
        return ( remaining <= 0)



    ################################################################
    # Decide ogni quanto tempo fare il salvataggio del file su disco
    ################################################################
    def savingDataOnFile(self, forceWrite=False):
        remaining=self.savingData_period - ( time.time()-self.savingData_start_time )
        self.logger.debug("timerForSavingData.remaining_time: %s", remaining)

        if forceWrite==True or remaining<=0:
            self.logger.notify('updating file: %s', self.device_file_json)
            self.full_device.to_json(filepath=self.device_file_json, indent=4, sort_keys=False)
            self.full_device.to_yaml(filepath=self.device_file_yaml, indent=4, sort_keys=False)
            self.savingData_start_time=time.time() ### reload timer
        else:
            self.logger.notify("file: %s will not be saved due to timerForSavingData still active.", self.device_file_json)





    ##################################################################
    ##################################################################
    #    R E T R I E V E    functions
    ##################################################################
    ##################################################################


    def name(self) -> str:
        return self.device_name

    def pulsetime(self) -> dict:
        return self.loretoData.get("PulseTime")

    def timers(self) -> dict:
        return self.liveData.get("TIMERS")


    # @property
    def nRelays(self) -> int:
        return self.obj_device.get("tasmota.nr_relays", 0)

    # @property
    def tg(self) -> dict:
        return self.obj_device.get("tg", {})

    # @property
    def friendlyNames(self) -> list:
        # return self.obj_device.friendlyNames()
        data = self.obj_device.get("tasmota.friendly_names", [])
        if not data:
            data = []
        return data

    def friendlyName(self, relay_nr: int) -> str:
        return self.obj_device.friendlyName(relay_nr)

    def mac(self) -> str:
        return self.obj_device.mac()

        mac=str(self.loretoData.NET.Mac)
        if mac and not ":" in mac:
            mac=':'.join(mac[i:i+2] for i in range(0,12,2))
        return mac


    # @property
    def setup_commands(self) -> list:
        # if "tasmota.setup_commands" in self.obj_device:
        #     xx = self.obj_device.tasmota.setup_commands
        #     if not xx :
        #         import pdb; pdb.set_trace();trace=True # by Loreto
        data = self.obj_device.get("tasmota.setup_commands", [])
        if not data:
            data = []
        return data


    # @property
    def refresh_commands(self) -> list:
        data = self.obj_device.get("tasmota.refresh_commands", [])
        if not data:
            data = []
        return data
        # if "tasmota.refresh_commands" in self.obj_device:
        #     return self.obj_device.tasmota.refresh_commands
        # return []






    ################################################################
    #
    ################################################################
    def relayStatus(self, relay_nr: int):
        if relay_nr in range(1, self.nRelays()+1):
            keypath=f'Loreto.STATE.POWER{relay_nr}'
            if keypath in self.full_device:
                status=self.full_device[f'Loreto.STATE.POWER{relay_nr}']
                if status:
                    return status
                else:
                    self.logger.error('%s - relay_nr: %s/%s', self.device_name, relay_nr, self.nRelays())
            else:
                self.logger.error('%s: keypath %s not found in device', self.device_name, keypath)
        else:
            return 'N/A'



    ####################################################################
    ### info varie
    ####################################################################
    def generalInfo(self):
        data=self.loretoData

        d=dict()

        if 'T' in data['last_update']:

            dt_last_update=datetime.strptime(data['last_update'], "%Y-%m-%dT%H:%M:%S")
            dt_now=datetime.now()
            diff_time=seconds_diff_datetime(dt_now, dt_last_update) ### dt1-dt2

            if diff_time > 60:
                d['Nota Bene']= {
                            "sep": "-------",
                            "Status": "offline",
                            "msg": "Tutti i dati potrebbero non essere validi!",
                            "sep": "-------",
                            # }
                # d['Last Update OLD']= {
                            "date": "<b>" + dt_last_update.strftime("%d/%m/%Y") + "</b>",
                            "time": "<b>" + dt_last_update.strftime("%H:%M:%S") + "</b>",
                            }
            else:
                d['Last Update']= {
                            "date": dt_last_update.strftime("%d/%m/%Y"),
                            "time": dt_last_update.strftime("%H:%M:%S"),
                            }

            d['firmware'] = data["firmware"]
            d['modello']  = data["modello"]

            # timeit.timeit('var1 + var2 + var3', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)
            # timeit.timeit('f"{var1}{var2}{var3}"', setup='var1=".i."; var2=".i."; var3=".i."', number=10000000)

        return d


    ####################################################################
    ### preparazione stato networking
    ### {"IPAddress1":"0.0.0.0 (192.168.1.103)","IPAddress2":"192.168.1.1","IPAddress3":"255.255.255.0","IPAddress4":"192.168.1.9","IPAddress5":"1.1.1.1"}
    ####################################################################
    def net_status(self, payload: dict={}):

        _dict={}

        if payload:
            ip=payload['IPAddress1']
            ip=ip.split('(')[1]
            ip=ip.split(')')[0]
            _dict={
                "IPAddress": ip,
                "Gateway":   payload["IPAddress2"],
                "SubMask":   payload["IPAddress3"],
                "DNS1":      payload["IPAddress4"],
                "DNS2":      payload["IPAddress5"],
                }


        else:
            data=self.loretoData['NET']
            if data:
                keys=[ "IPAddress",
                        "Gateway",
                        "Subnetmask",
                        "DNSServer1",
                        "DNSServer2",
                        "Mac",
                    ]

                _dict={}
                for key in keys:
                    value=self.loretoData['NET'][key]
                    _dict[key]=value

                mac=_dict.get("Mac")
                if mac and not ":" in mac:
                    _dict["Mac"]=':'.join(mac[i:i+2] for i in range(0,12,2))

        return _dict



    ####################################################################
    ### preparazione stato WiFi
    ####################################################################
    def wifi(self):
        data=self.loretoData['STATE.Wifi']

        wifi={}
        if "NET" in self.loretoData:
            wifi["ip"]=self.loretoData.get("NET.IPAddress")
            wifi["Mac"]=self.loretoData.get("NET.Mac")

        keys=[  "AP",
                "SSId",
                "BSSId",
                "Channel",
                "Mode",
                "RSSI",
                "Signal",
                ]

        for key in keys:
            value=self.loretoData['STATE.Wifi'][key]
            wifi[key]=value



        return wifi




    ####################################################################
    ### ritorna info su mqtt configuration
    ####################################################################
    def mqttInfo(self):


        data=self.liveData.get('STATUS.StatusMQT')
        if data:
            _dict={}
            for k,v in data.items():
                _dict[k]=v

            _dict={"MQTT": _dict }
        else:
            _dict={"MQTT": "NO data"}

        return _dict


    ####################################################################
    ### ritorna info sul firmware
    ####################################################################
    def firmware(self):


        data=self.liveData.get('STATUS.StatusFWR')

        if data:
            _dict={}
            for k,v in data.items():
                _dict[k]=v

            _dict={"Firmware": _dict }
        else:
            _dict={"Firmware": "NO data" }

        return _dict





if __name__ == '__main__':
    device=TasmotaClass(deviceDB=xxxx, runtime_dir='/tmp', logger=nullLogger())
    # sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    # from suntimes_LN import sunTime_casetta
    args=[2, '600']
    # ret=checkRelayNumber(arg=args[0], nRelays=1)
    # ret=humanToPulseTime(args=[1, '600'], nRelays=1)
    # print(ret)

    # ret=humanToPulseTime(args=[0, '600'], nRelays=1)
    # print(ret)

    # ret=humanToPulseTime(args=[2, '600'], nRelays=1)
    # print(ret)


    # data=pulseTimeToHuman(value=1000)
    # print(data)

    # data=timersToHuman(data=TIMERS, outputRelay=1)
    # print(data)
    # data=timersToHuman(data=TIMERS, outputRelay=2)
    # print(data)
    # data=timersToHuman(data=TIMERS, outputRelay=0)
    # print(data)

    # setTimer               number HH:MM   days   output   repeat action
    # setTimer                 1    12:30  -1--1-1     1       r|n      on
    data=sys.argv[1]
    # data=device.setTimer(data='1 ena 21:15 -1--1-1     5       r        on', nRelays=1)
    data=device.setTimer(data=data, nRelays=1)
    print(data)

    # data=device.setTimer(data='1 ena', nRelays=1)
    # print(data)

    # data=device.setTimer(data='1 dis', nRelays=1)
    # print(data)
