#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 18-05-2024 08.55.47
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
import os
import yaml
import json
from pathlib import Path
from types import SimpleNamespace
from collections import OrderedDict
from benedict import benedict
import time

from datetime import datetime
from decimal import Decimal
import ipaddress

import re
import LnUtils

regex = re.compile("").__class__
uuid_re = re.compile(
    "^([0-9a-f]{32}){1}$|^([0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}){1}$",
    flags=re.IGNORECASE,
)





class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=dummy






#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()


def print_json( **kwargs):
    print(toJson(**kwargs))

def print_yaml(d: dict,  **kwargs):
    print(toYaml(d, **kwargs))







############################################################
#
############################################################
def toJson(d: dict, *, filepath: str=None, title: str=None, indent=4, sort_keys=False):
    _dict={title: d} if title else d
    json_data=json.dumps(_dict, indent=indent, sort_keys=sort_keys, separators=(',', ': '), default=str)

    if filepath:
        gv.logger.notify('writing file: %s', filepath)
        return writeFile(filepath=filepath, data=json_data, replace=True)

    else:
        return json_data






############################################################
#
############################################################
def toYaml_01(d: dict, filepath: str=None, title: str=None, indent=4, sort_keys=False):
    if isinstance(d, SimpleNamespace):
        d=vars(d)

    if title:
        _dict=benedict({title: d})
    else:
        _dict=benedict(d)

    yaml_data=_dict.to_yaml(indent=indent, sort_keys=sort_keys, default_flow_style=False)

    if filepath:
        return writeFile(filepath=filepath, data=yaml_data, replace=True)
    else:
        return yaml_data


############################################################
# version: 19-01-2024 19.03.09
# return:
#   yaml_data if filepath is None
#   filename if filepath is not None
# - okkio: TypeError: Object of type PosixPath is not JSON serializable
# -     convertire in str(file) prima di inserire un pathlib.object nel dict
############################################################
def toYaml(d: dict, *,  filepath: str=None, title: str=None,
                        indent=4, sort_keys=False, replace: bool=False,
                        write_datetime: bool=False,
                        stacklevel=0):

    def _checkFile(path):
        if path.exists() and replace is False:
            gv.logger.error('file %s already exists. No changes', path , stacklevel=stacklevel+1)
            return None
        else:
            os.makedirs(path.parent,  exist_ok=True)

    d={title: d} if title else d # add title

    ### benedict risolve TypeError: Object of type PosixPath is not JSON serializable
    if not isinstance(d, benedict):
        d=benedict(d)

    yaml_data=d.to_yaml(indent=indent, sort_keys=sort_keys, default_flow_style=False, allow_unicode=True)

    if filepath:
        gv.logger.notify('writing file: %s', filepath)
        return writeFile(filepath=filepath, data=yaml_data, replace=True)
    else:
        return yaml_data







############################################################
#
############################################################
def toYamlLN(d: dict, title: str=None, indent=4, sort_keys=False):
    # tutto il giro per evitare che compaiano dei riferimenti strani di benedict nel'output
    _dict={title: d} if title else d # add title
    _json_str=json.dumps(_dict) # convert benedict to json_str
    _json_dict=json.loads(_json_str) # convert json_str to dict
    yaml_data=yaml.dump(_json_dict, indent=indent, sort_keys=sort_keys, default_flow_style=False)
    return yaml_data





######################################################
# - crea un dict con keys in bold case e value in italic (html syntax)
# - utile per invio messaggi su telegram
######################################################
def dict_bold_italic(d: dict, keys='bold', values='italic', nlevels=1):
    key_before=key_after=value_before=value_after=''

    if keys=='bold':
        key_before='<b>'
        key_after='</b>'
    elif keys=='italic':
        key_before='<i>'
        key_after='</i>'

    if values=='bold':
        value_before='<b>'
        value_after='</b>'
    elif values=='italic':
        value_before='<i>'
        value_after='</i>'

    new_dict={}
    for key, value in d.items():
        mode_key=f'{key_before}{key}{key_after}'
        if isinstance(value, dict) and nlevels>1:
            new_dict[mode_key]=dict_bold_italic(value, keys=keys, values=values, nlevels=nlevels)
        elif isinstance(value, (list, tuple)):
            new_dict[mode_key]=[]
            for item in value:
                new_dict[mode_key].append(f"{value_before}{item}{value_after}")
        else:
            new_dict[mode_key]=f"{value_before}{value}{value_after}"
    return new_dict









##############################################################
# - WRITE - FILE
# - writeFile version: 18-07-2023 12.54.30
##############################################################
def writeFile(filepath: (str, os.PathLike), *, data: (str, list, dict), replace: bool=False, write_datetime: bool=True):
    fout=Path(filepath).resolve()
    gv.logger.debug('writing file: %s', fout)

    if fout.exists() and replace is False:
        gv.logger.error('file %s already exists. No changes', fout )
        return None
    else:
        os.makedirs(fout.parent,  exist_ok=True)

    is_list_in_list = any(isinstance(el, list) for el in data)


    # if extension=='.csv':
    #     _data=fileCsv.to_csv(data)

    if isinstance(data, list):
        _data='\n'.join(data)


    elif isinstance(data, dict):
        d=data if isinstance(data, benedict) else benedict(data)
        extension=fout.suffix.lower()

        if extension=='.json':
            _data=json.dumps(d, indent=4, sort_keys=True, separators=(',', ': '), default=str)

        elif extension=='.yaml':
            _data=d.to_yaml(indent=4, sort_keys=True, default_flow_style=False)

        else:
            _data=f"output type {extension} un_managed"
    else:
        _data=data

    if write_datetime:
        date_time=datetime.now().strftime("%d-%m-%Y %H:%M")
        _data=f"#\n# Write time: {date_time}\n#\n" + _data

    if not _data.endswith('\n'):
        _data+="\n"

    with open(fout, "w") as f:
        f.write(_data)
        # f.write(f'{_data}\n')

    gv.logger.debug("File: %s has been written.", fout)
    return str(fout)








#################################################################
# key_name: nome della key da cercare
# key_prefix: prefisso da inserire prima del valore trovato
# is_ipaddress: considera il valore con un  indirizzo IP in modo da convertirlo in INT per poi fare il sort
# parent_level: up level (negative number) per identificare il punto da cui prendere il record
#
#################################################################
def sort_by_key_name(d: dict, sort_key_name: str, key_prefix: str="", parent_level: int=-1, error_on_duplicate: bool=True, return_keylist=False):
    assert isinstance(sort_key_name, str)
    k=d.keypaths(indexes=False) ### get full keypath list
    _keyname=f".{sort_key_name}"


    if parent_level>-1:
        gv.logger.error("il parent level [%s] è maggiore di -1, quindi non valido", parent_level)
    token_rec_name=parent_level-1 # aggiungiamo -1 in quanto -1 indica il livello che stiamo analizzando, quindi inserire almeno -2


    tmp_list=[]
    dup_list=[]
    sep="_@_"
    for key_path in k:
        if key_path.endswith(_keyname):
            gv.logger.debug("key_path: %s", key_path)

            tokens=key_path.split('.')
            rec_name=tokens[token_rec_name] ### nome del record da salvare
            rec_path=".".join(tokens[:parent_level]) # path al record originale

            gv.logger.debug("record path: %s", rec_path)

            value=d[key_path]
            _ip=None

            if sort_key_name=="ip":
                try:
                    value=int(ipaddress.ip_address(d[key_path]))
                    _ip=d[key_path]
                    tk=d[key_path].split(".")
                    value=f"{tk[0]:>03}_{tk[1]:>03}_{tk[2]:>03}_{tk[3]:>03}"
                except:
                    gv.logger.error("%s: %s - is not a valid ip address", key_path, d[key_path])
                    sys.exit()

            if error_on_duplicate:
                if not value in dup_list:
                    dup_list.append(value)
                else:
                    gv.logger.error("   keypath %s", key_path)
                    gv.logger.error("duplicate key %s ip: %s", value, _ip)
                    sys.exit(1)

            # if numeric: value=int(value)

            tmp_list.append(f"{key_prefix}{value}{sep}{rec_path}{sep}{rec_name}")



    ### create a final dict ordered by sorted_keylist
    new_db=OrderedDict()
    sorted_keylist=sorted(tmp_list) ### --- sort temp key_list
    for item in sorted_keylist:
        dummy, orig_keypath, rec_name=item.split(sep)
        new_db[rec_name]={}
        new_db[rec_name].update(d[orig_keypath])

    if return_keylist:
        return new_db.keys()

    return benedict(new_db, keyattr_enabled=True, keyattr_dynamic=False)
    return new_db




#################################################################
# r = d.search(in_keys, in_keys=True, in_values=False, exact=True, case_sensitive=True)
# m = d.match(in_keys, indexes=True)
# f = d.find(['a.b.c', 'e.d.q'], default=0)
#################################################################
def benedict_search_key(d: dict, substr: str, first_match=False):
    _keys = d.keypaths(indexes=False) ### benedict function returns all keypaths
    valids=[_key for _key in _keys if substr in _key]
    if valids and first_match:
        return valids[0]

    return valids



#########################################################################
# cerca una stringa all'interno dei valori di un dictionary
# se incorriamo in un int, lo convertiamo in str
#
#   r = config.in_value(req_value="-805790016", exact_match=False)
#   r = config.in_value(req_value=-805790016, exact_match=False)
#########################################################################
def benedict_search_value(d: dict, req_value: str, exact_match=True):
    flatten_sep='/'
    flat_dict=d.flatten(separator=flatten_sep)
    results=[]
    req_type=type(req_value)
    for keypath, value in flat_dict.items():
        if isinstance(value, (int, float)):
            value=str(value)

        if type(value) == req_type:
            if exact_match:
                if req_value==value:
                    results.append((keypath, value))
            else:
                if req_value in value:
                    results.append((keypath, value))

    return results




#####################################
# iterate on keypaths "key1.key2.key3...."
#####################################
def _iter_keypaths(d: dict, search_str: (list, str)=""):
    gv.logger.caller("_iter_keypaths", stacklevel=2)
    keypaths=d.keypaths(indexes=True) ### explode also lists objects
    gv.logger.debug("numbers of keypaths: %s", len(keypaths))


    for index, keypath in enumerate(keypaths):
        if keypath.startswith("_"):
            continue

        try:
            value=d[keypath]
            # print(keypath, value)
        except KeyError:
            last_key=keypath.split(".")[-1]
            if last_key in ["merge_dict_no_overwrite", "merge_dict_overwrite"]:
                gv.logger.warning("skipping key: %s (it's a xrox-reference-key )", keypath)
            continue # forse già rimosso perché è una mia chiave


        if isinstance(value, str):
            if search_str:
                for string in search_str:
                    if string in value:
                        gv.logger.debug("found")
                        gv.logger.debug("  keypath: %s", keypath)
                        gv.logger.debug("  value:   %s", value)
                        yield keypath, value
            else:
                yield keypath, value


#####################################
# iterate on keypaths "key1.key2.key3...."
#####################################
def get_keypaths(d: dict, search_str: (list, str)=""):
    gv.logger.caller("_iter_keypaths", stacklevel=2)
    keypaths=d.keypaths(indexes=True) ### explode also lists objects
    gv.logger.debug("numbers of keypaths: %s", len(keypaths))

    _keypaths=[]
    for keypath in keypaths:
        if keypath.startswith("_"):
            continue

        try:
            value=d[keypath]
            # print(keypath, value)
        except KeyError:
            last_key=keypath.split(".")[-1]
            if last_key in ["merge_dict_no_overwrite", "merge_dict_overwrite"]:
                gv.logger.warning("skipping key: %s (it's a xrox-reference-key )", keypath)
            continue # forse già rimosso perché è una mia chiave


        if isinstance(value, str):
            if search_str:
                for string in search_str:
                    if string in value:
                        gv.logger.debug("found")
                        gv.logger.debug("  keypath: %s", keypath)
                        gv.logger.debug("  value:   %s", value)
                        # xx = (keypath, value)
                        _keypaths.append((keypath, value))
            else:
                # xx = (keypath, value)
                _keypaths.append((keypath, value))

    return _keypaths


###############################################
# risolve entry del tipo:
#   bot:        ${!include_key_path} devices_db.bots.LnCasettaBot
#   name:       ${up_parent.1}
#   group_name: ${parent.2.name}
# lparent sono i primi che devono essere risolti
# presume che il dictionary sia benedict
###############################################
# def resolveDictCrossReferences(d: dict):
def resolveDictCrossReferences(d: dict, save_yaml_on_file: str=None, replace=True):
    # ==============================================================
    # --------------------------------------------
    # - deve essere risolto come primo step, prima di poter essere richiamato da qualche parent.attr
    # --------------------------------------------
    def _resolve_up_parent(d1: dict):
        prefix="${up_parent."; suffix="}"
        # for keypath, value in _iter_keypaths(d=d, search_str=[prefix]):
        keypaths = get_keypaths(d=d1, search_str=[prefix])
        for keypath, value in keypaths:
            if match := LnUtils.regex_search(value, prefix, suffix, fLAST=True):
                gv.logger.info("string %s Found on keypath: %s", "${up_parent.}", keypath)
                parent_level=int(match.name)+1

                parent_keyname=keypath.split('.')[-parent_level]

                # -------------------------------------------------------------------
                # controlliamo che sia una lista
                # se provo ad assegnare il valore direttamente al keypath mi trovo
                # lo stesso valore su tutti i reocrd....Mah
                # -------------------------------------------------------------------
                l_square = keypath.rfind("[")
                if l_square > 0:
                    r_square = keypath.rfind("]")
                    index = keypath[l_square+1:r_square]
                    keypath = keypath[:l_square]
                    cur_val = d1[keypath][:] # mandatory - deve essere una copia
                    cur_val[int(index)] = parent_keyname
                    d1[keypath]=cur_val
                else:
                    d1[keypath]=parent_keyname


        debug=True
    # ==============================================================


    # ==============================================================
    def _resolve_x_parent():
        gv.logger.info("%s Found on path: %s", "${parent.}", keypath)
        # if "parent.1.characteristics.friendly_names" in value:
            # xx=0
        # import pdb; pdb.set_trace();trace=True # by Loreto
        parent_level, attr_name=match.name.split(".", 1) # attr_name può essere acnche un keypath a.b.c ma va implementato...
        parent_level=int(parent_level)+1
        '''
        if len(keypath.split('.')) >= parent_level:
            parent_level = len(keypath.split('.')) -1
        '''
        parent_keypath=keypath.split('.')[:-parent_level] # get parrent pointer
        parent_keypath.append(attr_name) # get parrent pointer
        ptr_val=d[parent_keypath] # read value pointed by variable - benedict legge anche keypath_list


        # rebuild value string 0:start_pos + new_val + end_pos:
        parts=[value[:match.start_pos]]
        parts.append(ptr_val)
        parts.append(value[match.end_pos:])
        parts = list(filter(None,parts))  # remove empty/null items
        new_val=''.join([str(n) for n in parts]) # @changed:  03-11-2023

        d[keypath]=new_val # assign new value
    # ==============================================================

    removing_keys=[]
    for key in d.keys():
        if key.startswith("__"):
            removing_keys.append(key)

    for key in removing_keys:
        d.pop(key)

    #--- deve essere risolto come primo step
    _resolve_up_parent(d, )

    prefix="${parent."; suffix="}"
    for keypath, value in _iter_keypaths(d=d, search_str=[prefix]):
        if match := LnUtils.regex_search(value, prefix, suffix, fLAST=True):
            _resolve_x_parent()

    for keypath, value in _iter_keypaths(d=d, search_str=""):
        if keypath.endswith("merge_dict_no_overwrite"):
            """merge_dict_no_overwrite: bots.LnCasettaBot [full dictionary path to be retrieved ] """
            gv.logger.debug("%s Found on path: %s", "merge_dict_no_overwrite", keypath)
            new_val=d[value]
            parent_keypath=keypath.split('.')[:-1] ### remove last qualifier
            if isinstance(d[parent_keypath], dict):
                if isinstance(new_val, dict):
                    d[parent_keypath].merge(new_val, overwrite=False, concat=True)

                    del d[keypath] ### remove item entry
                    temp_dict={}  # @Loreto:  04-12-2023
                    temp_dict.update(new_val)   # get new dictionary data
                    temp_dict.update(d[parent_keypath])   # get previous dictionary data to override new_val
                    d[parent_keypath].update(temp_dict)   # write merged data

                else:
                    gv.logger.error("Il path richiesto [%s] deve puntare ad un dictionary.", keypath)
            else:
                gv.logger.error("Il path receiver [%s] deve essere ad un dictionary.", parent_keypath)


        elif keypath.endswith("merge_dict_overwrite"):
            """merge_dict_on_keypath: bots.LnCasettaBot [full dictionary path to be retrieved ] """
            gv.logger.debug("%s Found on path: %s", "merge_dict_overwrite", keypath)
            new_val=d[value]
            parent_keypath=keypath.split('.')[:-1] ### remove last qualifier
            if isinstance(d[parent_keypath], dict):
                if isinstance(new_val, dict):
                    d[parent_keypath].merge(new_val, overwrite=True, concat=True)

                    del d[keypath] ### remove item entry
                    d[parent_keypath].update(new_val)   # write merged data
                else:
                    gv.logger.error("Il path richiesto [%s] deve puntare ad un dictionary.", keypath)
            else:
                gv.logger.error("Il path receiver [%s] deve essere ad un dictionary.", parent_keypath)



        elif value.startswith("${!include_key_path}"):
            """bot: ${!include_key_path} bots.LnCasettaBot [full dictionary path to be retrieved ]"""
            gv.logger.debug("%s Found on path: %s", "${!include_key_path}", keypath)
            _, _key_path=value.split()
            new_val=d[_key_path]

            if isinstance(new_val, dict):
                d[keypath]={}
                d[keypath].update(new_val)
            else:
                d[keypath]=new_val

        else:
            pass
            # print("???????")

    #-----------------------------------------------
    #- Verify all pointers are resolved
    #-----------------------------------------------
    check_pointers=True
    if check_pointers:
        gv.logger.notify("Verify all pointers are resolved")
        prefixes=["${up_parent", "${parent"]
        for keypath, value in _iter_keypaths(d=d, search_str=prefixes):
            gv.logger.critical("Unresolved pointer")
            gv.logger.error("keypath: %s", keypath)
            gv.logger.error("value:   %s", value)
            sys.exit(1)


    if save_yaml_on_file:
        d.toYaml(filepath=save_yaml_on_file, replace=replace)





######################################################
# - Monkeys
######################################################

try:
    from benedict import benedict
    benedict.toYaml                   = toYaml
    benedict.toJson                   = toJson
    benedict.print_json               = print_json
    benedict.print_yaml               = print_yaml
    benedict.pj                       = print_json
    benedict.py                       = print_yaml
    benedict.find_in_key              = benedict_search_key
    benedict.find_in_value            = benedict_search_value
    benedict.resolveDictCrossReferences = resolveDictCrossReferences
    benedict.sort_by_key_name         = sort_by_key_name
    print("YES benedict")
    # db=benedict(db, keyattr_enabled=True, keyattr_dynamic=False)


except:
    print("NO benedict")
    pass



# def is_bool(val):
#     return isinstance(val, bool)


def _test_dict():
    my_servers="""
        SERVER:
            S01:
                alias: ln_s01
                ssh_port: s01_1000
                host: 192.168.1.01
                credentials:
                    username: user_s01
                    password: passw_01
                location:
                    building: B01
                    floar: 1
                    room: 14
            S02:
                alias: ln_s02
                ssh_port: s02_2000
                host: 192.168.1.02
                credentials:
                    username: user_s02
                    password: passw_02
                location:
                    building: B02
                    floar: 2
                    room: 24
            servers:
            - server1:
                s11: s1_s01
                s12: s1_s02
            - server2:
                s21: s2_s01
                s22: s2_s02
            - server3:
                - s31: s3_s01
                - s32: s3_s02
       """
    server_dict=yaml.load(my_servers, Loader=yaml.SafeLoader)
    return server_dict



#######################################################
#
#######################################################
if __name__ == '__main__':
    gv=SimpleNamespace()
    gv.logger=nullLogger()

    fREGEX=True

    if fREGEX:
        data1='/media/loreto/LnDisk_SD_ext4/Filu/myData/MP3_songs/Stranieri/New_Age/Bellissima_Sampler/Sueno_de_San_Juan-[C_Peacock].mp3'
        data2='state.toTG .toLNloreto.toLNciao .toLNpippo-.toLNpippo-.toLNloreto.toLNciao'

        data3="${ciao_loreto} ${ciao_Ale}"
        data=regex_getDelimitedString(data=data3, prefix=r"\${", suffix="}", fLAST=False)
        print("regex_delimitedString - First:", data)

        data=regex_getDelimitedString(data=data3, prefix=r"\${", suffix="}", fLAST=True)
        print("regex_delimitedString - Last :", data)

        data=regex_findAll(data=data3, prefix=r"\${", suffix="}")
        print("regex_findAll                :", data)

    '''
    # from types import SimpleNamespace
    # gVars=SimpleNamespace()
    # gVars.logger=nullLogger()
    # setup(gVars=gVars)
    d=benedict(_test_dict())
    # r = d.ln_search('POWER', in_keys=True, in_values=False, exact=False, case_sensitive=True)
    # r = d.ln_search(in_keys="SERVER")
    r = d.in_key(in_str="building", first_match=True)
    print(r)
    r = d.in_key(in_str="building", first_match=False)
    print(r)
    r = d.in_key(in_str="buildingx", first_match=False)
    print(r)

    data=dict_bold_italic(d,  keys='bold', values='italic', nlevels=2)
    print(toYaml(data))
    '''
