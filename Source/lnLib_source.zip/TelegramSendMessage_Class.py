#!/usr/bin/python3
#
# updated by ...: Loreto Notarantonio
# Date .........: 01-08-2023 10.15.14
#

import sys; sys.dont_write_bytecode = True
import os
import requests
import socket
from types import SimpleNamespace
import json, yaml
from pathlib import Path
import zipfile, io

try:    ### ref: https://realpython.com/python-yaml/#yaml-syntax
    from yaml import CSafeLoader as SafeLoader, CFullLoader as FullLoader
except ImportError:
    print('....no yaml C class')
    from yaml import SafeLoader, FullLoader

this=sys.modules[__name__]
this.filedata={}

from    devicesDB import devicesDB_Class

##################################################################
# tg_data nel caso abbia già i dati....
##################################################################
class TelegramSendMessage_Class():
    """docstring for SendTelegram"""
    def __init__(self, *, devicesDB: devicesDB_Class, logger):
        assert isinstance(devicesDB, devicesDB_Class)

        self.logger=logger
        self.logger.info('Starting bot')
        self.hostname=socket.gethostname().split()[0]
        self.devicesDB=devicesDB

        # self.tgGroups=devicesDB.get_allTgGroups(fSort=True, save_on_file=True)
        """ get all devices having tg_Group definition"""

        # if not devicesDB.tgGroups()
        #     logger.error('No tg groups data available')
        #     sys.exit(1)


        self.italicB="<i>";self.italicE="</i>"
        self.boldB="<b>";self.boldE="</b>"
        self.sQ="'"
        self.dQ='"'






    ###############################################
    # per i bot, partendo dal group_name risaliamo al bot associato
    #
    #    LnCasettaBot_Mqtt_Client:
    #        chat_id: -584205814
    #        type: group
    #        bot:  ### questa tipologia mi dovrebbe semplificare la modifia live del bot
    #            bot_name:   Ale_Bot
    #            username:   Kily_bot
    #            token:      "806825655:AAFU5-7dVeYuS3dgb0tgkpYA7OY6TXqzJpw"
    #            link:       'http://t.me/Kily_bot'
    #
    ###############################################
    def _retrieveBotData(self, *, group_name: str):
        normalized_group_name=group_name.replace('-', '_')

        data=self.tgData
        if not data:  ### se abbiamo i dati già in memoria...
            self.logger.error('data NOT present' )
            sys.exit(1)


        main_keys=['groups', 'application_groups', 'channels']
        group_list=[]
        for _group in main_keys:
            group_list.extend(list(data[_group].keys()))
            if normalized_group_name in data[_group].keys():
                bot=data[_group][normalized_group_name]
                bot['group_name']=normalized_group_name ### aggiungiamo anche il nome gruppo per non dimenticarlo
                break
        else:
            bot={}
            self.logger.error('Bot for group: %s NOT found in data', group_name)
            for group in sorted(group_list): ### for debugging
                print('     ', group)

        return bot








    ###############################################################
    # group_name: if None {hostname}_channel will be used
    ###############################################################
    def send(self, group_name: str=None, msg_text: str=None, caller=True):
        if not group_name:
            group_name=f'{self.hostname}_channel'

        if not (tg_group:=self.devicesDB.getTgData(group_name)):
        # tg_group=self.devicesDB.getTgData(group_name)
        # if not tg_group:
            return


        if caller:
            json_data=json.dumps({self.hostname: {'msg': msg_text}}, indent=4, sort_keys=False)
            message=yaml.dump(yaml.load(json_data, Loader=FullLoader), indent=4, sort_keys=False, default_flow_style=False)
        elif isinstance(message, dict):
            json_data=json.dumps(msg_text, indent=4, sort_keys=False)
            message=yaml.dump(yaml.load(json_data, Loader=FullLoader), indent=4, sort_keys=False, default_flow_style=False)
        else:
            message=msg_text



        url = f'''https://api.telegram.org/bot{tg_group.bot_token}/sendMessage?chat_id={tg_group.chat_id}&text={message}'''
        self.logger.info('     bot_name:   %s',   tg_group.bot_name)
        self.logger.info('     group_name: %s',   tg_group.group_name)
        self.logger.info('     chat_id:    %s',   tg_group.chat_id)

        if tg_group.bot_name and tg_group.bot_token:
            result=requests.get(url).json() # this sends the message
            self.logger.notify(result)
        else:
            self.logger.error('     command cannot be executed....missing some values!')




    ###############################################################
    # group_name: if None {hostname}_channel will be used
    ###############################################################
    def send_html(self, group_name: str=None, message: dict={}, caller: bool=False, notify: bool=False):

        ### ---------------------------------------------
        def html_parse_mode(message):
            parse_mode='&parse_mode=HTML'
            message=message.replace(self.sQ, '')
            message=message.replace(self.dQ, '')

            if caller:
                message=f"from: {self.italicB}{self.boldB}{self.hostname}{self.boldE}{self.italicE}\nname: {self.boldB}{self.italicB}{group_name}{self.italicE}{self.boldE}\n\n{message}" # italic + bold

            return message, parse_mode
        ### ---------------------------------------------


        if not group_name:
            group_name=f'{self.hostname}_channel'


        if not (tg_group:=self.devicesDB.getTgData(group_name)):
        # tg_group=self.devicesDB.getTgData(group_name=group_name)
        # if not tg_group:
            return

        # bot_name=tg_group["bot_name"]
        # bot_token=tg_group["token"]
        # chat_id=tg_group["chat_id"]


        if tg_group.bot_name and tg_group.bot_token and tg_group.chat_id:

            ### -----------------------------
            ### serve a mettere le main key in bold
            ### si può toglere se serve
            if isinstance(message, dict):
                keys=list(message.keys())
                message=yaml.dump(message, indent=4, sort_keys=False, default_flow_style=False)

            else:
                parse_mode=None
                keys=[]

            for key in keys:
                message=message.replace(key, f'{self.boldB}{key}{self.boldE}')
            ### -----------------------------

            notification=f"&disable_notification={not notify}"

            self.logger.notify('     message:    %s',   message)
            message, parse_mode=html_parse_mode(message=message)

            ### non l'ho ancora ben capito ma ci deve essere qualche problema con gli apici all'interno del messaggio ed il parse mode....
            if self.sQ in message or self.dQ in message:
                parse_mode=''



            url=f"https://api.telegram.org/bot{tg_group.bot_token}/sendMessage?chat_id={tg_group.chat_id}&text={message}{parse_mode}{notification}"
            self.logger.info('     bot_name:   %s',   tg_group.bot_name)
            self.logger.info('     group_name: %s',   tg_group.group_name)
            self.logger.info('     chat_id:    %s',   tg_group.chat_id)
            self.logger.notify('     message with tags:    %s',   message)


            try:
                response=requests.get(url).json()
                ### response: {'ok': False, 'error_code': 400, 'description': "Bad Request: can't parse entities: Can't find end of the entity starting at byte offset 493"}
                ### esponse: {'ok': True, 'result': {'messag....
                if response['ok']:
                    self.logger.info('   response: %s',   response)
                else:
                    self.logger.error('   response: %s',   response)
                    self.logger.caller('url:  %s',   url, stacklevel=1)


            except (Exception) as ex:
                self.logger.error('     exception:   %s',   str(ex))

        else:
            self.logger.error('command cannot be executed....missing some values!')
            _d=benedict(tg_group, keyattr_enabled=True, keyattr_dynamic=False)
            self.logger.error('bot data: %s',   _d.to_json())






#################################
#
#################################
def setupLogger():
    import logging
    logging.basicConfig(level=logging.DEBUG,
                        format='[%(levelname)4s] - [%(module)s.%(funcName)s:%(lineno)4s]: %(message)s',
                        )

    logger = logging.getLogger('example_logger')
    return logger


###############################################
#
###############################################
if __name__ == '__main__':
    logger=setupLogger()
    telegram_group_data_file="conf/telegramGroups_lnk.yaml"

    # setup(gVars=gv)
    tg=telegramSendMessage_Class(telegram_group_data_file=telegram_group_data_file, logger=logger)
    tg.send(group_name='LnPi23_channel', msg_text='prova invio messaggio')
    tg.send(msg_text='prova invio messaggio_2')
