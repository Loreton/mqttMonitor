#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 03-05-2024 17.08.56
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
import os
import yaml
import json
from pathlib import Path
from types import SimpleNamespace
from collections import OrderedDict
from benedict import benedict
import time

from datetime import datetime
from decimal import Decimal
import ipaddress

import re
regex = re.compile("").__class__
uuid_re = re.compile(
    "^([0-9a-f]{32}){1}$|^([0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}){1}$",
    flags=re.IGNORECASE,
)


class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=dummy






#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()


def timeIt(ref_time=0, fStart=False):
    if fStart:
        return time.time()
    elif ref_time>0:
        print(time.time() - ref_time)
        import pdb; pdb.set_trace(); pass # by Loreto






###############################################################
# Search string between delimiters
# if fLAST==True search for the last occurrency
# return:
#        pattern if data==None
#        result  if data
###############################################################
def regex_search(data: str, prefix: str, suffix: str, fLAST=False):
    import re
    _prefix=prefix.replace('$', '\\$')
    _suffix=suffix.replace('$', '\\$')
    pattern=f'{_prefix}(.*?){_suffix}'
    regex=re.compile(pattern, re.IGNORECASE)

    ret=None
    if isinstance(data, (str, bytes)):
        start_pos=data.rfind(prefix) if fLAST else 0
        if start_pos>=0:
            matched=regex.search(data, start_pos)
            if matched:
                gv.logger.debug('MATCH FOUND: %s', matched)
                llen=len(prefix)
                rlen=len(suffix)

                ret=SimpleNamespace()
                matched_str, ret.start_pos, ret.end_pos=matched.group(), matched.start(), matched.end()
                ret.name=matched_str[llen:-rlen] #- strip prefix and suffix

    return ret





###############################################################
# Search string between delimiters
# if fLAST==True search for the last occurrency
# return:
#        pattern if data==None
#        result  if data
###############################################################
def regex_getDelimitedString(data: str, prefix: str, suffix: str, fLAST=False):
    import re
    # pattern=r"" + prefix + "(.*?)" + suffix
    pattern=prefix + "(.*?)" + suffix

    # - remove escape char
    prefix=prefix.replace('\\', "")
    suffix=suffix.replace('\\', "")

    # - compile pattern
    regex=re.compile(pattern, re.IGNORECASE)
    ret=None
    if isinstance(data, (str, bytes)):
        llen=len(prefix)
        rlen=len(suffix)
        start_pos=data.rfind(prefix) if fLAST else 0
        if start_pos>=0:
            matched=regex.search(data, start_pos)
            if matched:
                gv.logger.debug('MATCH FOUND: %s', matched)

                ret=SimpleNamespace()
                matched_str, ret.start_pos, ret.end_pos=matched.group(), matched.start(), matched.end()
                ret.name=matched_str[llen:-rlen] #- strip prefix and suffix

    return ret.name



###############################################################
# Search string between delimiters
# if fLAST==True search for the last occurrency
# return:
#        pattern if data==None
#        result  if data
###############################################################
def regex_findAll(data: str, prefix: str, suffix: str):
    import re
    pattern=prefix + "(.*?)" + suffix

    # - remove escape char
    prefix=prefix.replace('\\', "")
    suffix=suffix.replace('\\', "")

    # - compile pattern
    regex=re.compile(pattern, re.IGNORECASE)

    return regex.findall(data)






############################################################
# [[a,b,c], [c,d,e], [1,2], f] --> [a,b,c,d,e,f,1,2]
############################################################
def flatten_nested_list(array: list=[]):
    _list=[]
    if isinstance(array, (list, tuple)):
        for item in array:
            if not item: continue
            if isinstance(item, list):
                _list.extend(item)
            else:
                _list.append(item)

    else:
        _list.append(array)

    # remove duplicates
    _list=list(dict.fromkeys(_list))

    return _list





############################################################
#
############################################################
def zip_extract_file(archive_file: str, filename: str, content: bool=False, search_paths: list=[], out_dir: str='/tmp'):
    import zipfile

    """ check it its a zip file """
    if zipfile.is_zipfile(archive_file):
        zFile=zipfile.ZipFile(archive_file, "r")
        zFileNamelist=zFile.namelist()
        search_paths.insert(0, '')
        for path in search_paths:
            filepath=os.path.join(path, filename)
            if filepath in zFileNamelist:
                if content:
                    buffer=io.BytesIO(zFile.read(filepath))
                    content=buffer.read()
                    return content
                else:
                    zFile.extract(member=filepath, path=out_dir, pwd=None)
                    ftemp=f'{out_dir}/{filepath}'
                    return ftemp

    return None










##############################################################
# - WRITE - FILE
# - writeFile version: 18-07-2023 12.54.30
##############################################################
def writeFile(filepath: (str, os.PathLike), *, data: (str, list, dict), replace: bool=False, write_datetime: bool=True):
    fout=Path(filepath).resolve()
    gv.logger.debug('writing file: %s', fout)

    if fout.exists() and replace is False:
        gv.logger.error('file %s already exists. No changes', fout )
        return None
    else:
        os.makedirs(fout.parent,  exist_ok=True)

    if isinstance(data, list):
        _data='\n'.join(data)

    elif isinstance(data, dict):
        d=data if isinstance(data, benedict) else benedict(data)
        extension=fout.suffix.lower()
        if extension=='.json':
            _data=json.dumps(d, indent=4, sort_keys=True, separators=(',', ': '), default=str)
        elif extension=='.yaml':
            _data=d.to_yaml(indent=4, sort_keys=True, default_flow_style=False)
        else:
            _data=f"output type {extension} managed"
    else:
        _data=data

    if write_datetime:
        date_time=datetime.now().strftime("%d-%m-%Y %H:%M")
        _data=f"#\n# Write time: {date_time}\n#\n" + _data

    if not _data.endswith('\n'):
        _data+="\n"

    with open(fout, "w") as f:
        f.write(_data)
        # f.write(f'{_data}\n')

    gv.logger.notify("File: %s has been written.", fout)
    return str(fout)





#######################################################
# validKeys["pass_back"] pass any choice to back bat exitKeys
#######################################################
def keyb_prompt(*, text_msg: str, validKeys: list=["y", "n"], exitKeys: list=["x", "q"]):
    text_msg+= " - [" + '|'.join(exitKeys) + "]quit ->: "
    if "ENTER" in exitKeys  or "enter" in exitKeys: exitKeys.append("")
    if "ENTER" in validKeys or "enter" in validKeys: validKeys.append("")

    while True:
        choice=input(text_msg).lower()
        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request.")
            sys.exit(0)

        elif choice in validKeys:
            break

        elif "pass_back" in validKeys:
            break

        else:
            print('\n... please enter some valid key:', validKeys, "or exit key:", exitKeys)

    return choice


#######################################################
# validKeys["pass_back"] pass any choice to back bat exitKeys
#######################################################
def keyb_prompt_2(text_msg: str, *, validKeys: list=["y", "n"], exitKeys: list=["x", "q"]):
    _exit='|'.join(exitKeys)
    _valid='|'.join(validKeys)
    if "pass_back" in validKeys:
        pass_back = True
        validKeys.remove("pass_back")

    # text_msg+= " - [" + "validKeys" + '|'.join(validKeys) + "exitKeys" + '|'.join(exitKeys) + "]quit ->: "
    text_msg+= f""" - validKeys: [{_valid}]  exitKeys:[{_exit}]  ->: """
    if "ENTER" in exitKeys  or "enter" in exitKeys: exitKeys.append("")
    if "ENTER" in validKeys or "enter" in validKeys: validKeys.append("")
    while True:
        choice=input(text_msg).lower()
        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request.")
            sys.exit(0)

        elif choice in validKeys:
            break

        elif "pass_back" in validKeys:
            break

        else:
            print('\n... please enter some valid key:', validKeys, "or exit key:", exitKeys)

    return choice


#######################################################
# permette multiple choices
# return list[] of choice(s)
#######################################################
def keyb_prompt_MC(text_msg: str, validKeys: list=["y", "n"], exitKeys: list=["x", "q"], multi_choices: bool=False) -> list:
    # # -------------------------------
    def check_MC():
        for ch in choice.split():
            if ch not in validKeys:
                gv.logger.error("choice %s is not valid", ch)
                return False
        return True
    # # -------------------------------



    text_msg+= " - [" + '|'.join(exitKeys) + "]quit ->: "
    if "ENTER" in exitKeys: exitKeys.append("")
    if "ENTER" in validKeys: validKeys.append("")

    while True:
        choice=input(text_msg).lower()

        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request.")
            sys.exit(0)

        elif multi_choices and check_MC():
            break

        elif choice in validKeys:
            break

        else:
            print('\n... please enter some valid key:', validKeys, "or exit key:", exitKeys)

    return choice.split() if multi_choices else choice




########################################################################
# -------------- PROMPT -------------------
########################################################################
def keyb_prompt_too_complexXXXXX(msg='', validKeys='ENTER', exitKeys='x|q', displayValidKeys=False, gVars={}):
    # -------------------------------
    def caller_info(message, stacknum=2):
        from inspect import getframeinfo, stack
        caller = getframeinfo(stack()[stacknum][0])
        funcname=os.sep.join(caller.filename.split(os.sep)[-2:])
        msg=f"{funcname}:{caller.lineno} - {message}"
        return msg
    # -------------------------------

    C=gVars['color'] if 'color' in gVars else None

    if not msg.startswith('\n'): print()
    if not msg:
        # msg=caller_info('Enter [c] to continue....')
        msg=caller_info('[c] to continue')
        validKeys='c'

    if not validKeys or not displayValidKeys:
        msg = f"     {msg} - ({exitKeys} to exit) ==> "
    else:
        msg = f"     {msg} [{validKeys}] - ({exitKeys} to exit) ==> "



    if C: msg=C.gWhiteH(msg)
    if isinstance(validKeys, (range)):
        _keys = []
        for i in validKeys:
            _keys.append(i)
        validKeys = '|'.join([str(x) for x in _keys])

    validKeys = validKeys.split('|')

    exitKeys = exitKeys.split('|')
    while True:
        choice      = input(msg).strip()
        choiceUPP   = choice.upper()

        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request.")
            sys.exit(0)

        if choice == '':
            if "ENTER" in exitKeys:
                sys.exit()
            if "ENTER" in validKeys:
                return ''
            else:
                print('\n... please enter something\n')

        elif "ENTER" in validKeys:
            return choice

        elif choice in validKeys:
            break

        else:
            print('\n... try again\n')

    return choice

# prompt=keyb_prompt





#################################################################
# --- remove multiple consecutive blank lines
#################################################################
def remove_multiple_consecutive_blank_lines(content: list) -> str:
    _str='\n'.join(content)
    new_data=re.sub(r'[\r\n][\r\n]{2,}', '\n\n', _str)
    return new_data







################################################
### https://www.geeksforgeeks.org/compare-two-files-line-by-line-in-python/
################################################
def diff(file1: str, file2: str, exit_on_not_found=True):
    def use_difflib_differ(file1: str, file2: str):
        import difflib
        from difflib import Differ

        with open(file1) as file_1, open(file2) as file_2:
            differ = Differ()

            for line in differ.compare(file_1.readlines(), file_2.readlines()):
                print(line)


    def use_difflib(file1: str, file2: str):
        # Importing difflib
        import difflib

        with open(file1) as file_1:
            file_1_text = file_1.readlines()

        with open(file2) as file_2:
            file_2_text = file_2.readlines()

        # Find and print the diff:
        for line in difflib.unified_diff(file_1_text, file_2_text, fromfile=file1, tofile=file2, lineterm=''):
            print(line)


    def line_by_line2(file1: str, file2: str):
        f1_ID="@"
        f2_ID="#"
        if exit_on_not_found is False:
            if not Path(file1).exists(): return "[ERROR]"
            if not Path(file2).exists(): return "[ERROR]"

        print("Comparing files ", f"{f1_ID} + {file1}",f"{f2_ID} + {file2}",  sep='\n')

        f2=open(file2, "r")
        f1=open(file1, "r")


        # Use as a COunter
        line_no = 1

        file_1_line = f1.readline()
        file_2_line = f2.readline()

        diff_lines=[]
        while file_1_line != '' or file_2_line != '':

            # Removing whitespaces
            file_1_line = file_1_line.rstrip()
            file_2_line = file_2_line.rstrip()

            # Compare the lines from both file
            if file_1_line != file_2_line:

                # otherwise output the line on file1 and use @ sign
                if file_1_line == '':
                    line=f"{f1_ID} [{line_no:04}]  {file_1_line}"
                else:
                    line=f"{f1_ID} [{line_no:04}]- {file_1_line}"

                diff_lines.append(line)

                # otherwise output the line on file2 and use # sign
                if file_2_line == '':
                    line=f"{f2_ID} [{line_no:04}]  {file_2_line}"
                else:
                    line=f"{f2_ID} [{line_no:04}]- {file_2_line}"
                diff_lines.append(line)
                diff_lines.append("")

            # Read the next line from the file
            file_1_line = f1.readline()
            file_2_line = f2.readline()

            line_no += 1

        f1.close()
        f2.close()
        for line in diff_lines:
            print(line)

    # use_difflib(file1, file2)
    # use_difflib_differ(file1, file2)
    diff_lines=line_by_line2(file1, file2)
    return diff_lines






######################################################
# - Monkeys
######################################################



# def is_bool(val):
#     return isinstance(val, bool)


def is_collection(val):
    return isinstance(val, (dict, list, set, tuple))


def is_function(val):
    return callable(val)

def is_integer_in_range(val, min: int, max: int):
    try:
        val=int(val)
    except:
        return False

    if val in range(min, max+1):
        return val
    return False


def is_json_serializable(val):
    json_types = (type(None), bool, dict, float, int, list, str, tuple)
    return isinstance(val, json_types)


def is_uuid(val):
    return is_string(val) and uuid_re.match(val)



#######################################################
#
#######################################################
if __name__ == '__main__':
    gv=SimpleNamespace()
    gv.logger=nullLogger()

    fREGEX=True

    if fREGEX:
        data1='/media/loreto/LnDisk_SD_ext4/Filu/myData/MP3_songs/Stranieri/New_Age/Bellissima_Sampler/Sueno_de_San_Juan-[C_Peacock].mp3'
        data2='state.toTG .toLNloreto.toLNciao .toLNpippo-.toLNpippo-.toLNloreto.toLNciao'

        data3="${ciao_loreto} ${ciao_Ale}"
        data=regex_getDelimitedString(data=data3, prefix=r"\${", suffix="}", fLAST=False)
        print("regex_delimitedString - First:", data)

        data=regex_getDelimitedString(data=data3, prefix=r"\${", suffix="}", fLAST=True)
        print("regex_delimitedString - Last :", data)

        data=regex_findAll(data=data3, prefix=r"\${", suffix="}")
        print("regex_findAll                :", data)

    '''
    # from types import SimpleNamespace
    # gVars=SimpleNamespace()
    # gVars.logger=nullLogger()
    # setup(gVars=gVars)
    d=benedict(_test_dict())
    # r = d.ln_search('POWER', in_keys=True, in_values=False, exact=False, case_sensitive=True)
    # r = d.ln_search(in_keys="SERVER")
    r = d.in_key(in_str="building", first_match=True)
    print(r)
    r = d.in_key(in_str="building", first_match=False)
    print(r)
    r = d.in_key(in_str="buildingx", first_match=False)
    print(r)

    data=dict_bold_italic(d,  keys='bold', values='italic', nlevels=2)
    print(toYaml(data))
    '''
