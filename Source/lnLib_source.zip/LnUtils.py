#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 09-01-2024 18.10.27
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
import os
import yaml
import json
from pathlib import Path
from types import SimpleNamespace
from collections import OrderedDict
from benedict import benedict
import time

from datetime import datetime
from decimal import Decimal
import ipaddress

import re
regex = re.compile("").__class__
uuid_re = re.compile(
    "^([0-9a-f]{32}){1}$|^([0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}){1}$",
    flags=re.IGNORECASE,
)


class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=dummy






#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()


def timeIt(ref_time=0, fStart=False):
    if fStart:
        return time.time()
    elif ref_time>0:
        print(time.time() - ref_time)
        import pdb; pdb.set_trace(); pass # by Loreto

def print_json( **kwargs):
    print(toJson(**kwargs))

def print_yaml(d: dict,  **kwargs):
    print(toYaml(d, **kwargs))






###############################################################
# Search string between delimiters
# if fLAST==True search for the last occurrency
# return:
#        pattern if data==None
#        result  if data
###############################################################
def regex_search(data: str, prefix: str, suffix: str, fLAST=False):
    import re
    _prefix=prefix.replace('$', '\\$')
    _suffix=suffix.replace('$', '\\$')
    pattern=f'{_prefix}(.*?){_suffix}'
    regex=re.compile(pattern, re.IGNORECASE)

    ret=None
    if isinstance(data, (str, bytes)):
        start_pos=data.rfind(prefix) if fLAST else 0
        if start_pos>=0:
            matched=regex.search(data, start_pos)
            if matched:
                gv.logger.debug('MATCH FOUND: %s', matched)
                llen=len(prefix)
                rlen=len(suffix)

                ret=SimpleNamespace()
                matched_str, ret.start_pos, ret.end_pos=matched.group(), matched.start(), matched.end()
                ret.name=matched_str[llen:-rlen] #- strip prefix and suffix

    return ret





###############################################################
# Search string between delimiters
# if fLAST==True search for the last occurrency
# return:
#        pattern if data==None
#        result  if data
###############################################################
def regex_getDelimitedString(data: str, prefix: str, suffix: str, fLAST=False):
    import re
    # pattern=r"" + prefix + "(.*?)" + suffix
    pattern=prefix + "(.*?)" + suffix

    # - remove escape char
    prefix=prefix.replace('\\', "")
    suffix=suffix.replace('\\', "")

    # - compile pattern
    regex=re.compile(pattern, re.IGNORECASE)
    ret=None
    if isinstance(data, (str, bytes)):
        llen=len(prefix)
        rlen=len(suffix)
        start_pos=data.rfind(prefix) if fLAST else 0
        if start_pos>=0:
            matched=regex.search(data, start_pos)
            if matched:
                gv.logger.debug('MATCH FOUND: %s', matched)

                ret=SimpleNamespace()
                matched_str, ret.start_pos, ret.end_pos=matched.group(), matched.start(), matched.end()
                ret.name=matched_str[llen:-rlen] #- strip prefix and suffix

    return ret.name



###############################################################
# Search string between delimiters
# if fLAST==True search for the last occurrency
# return:
#        pattern if data==None
#        result  if data
###############################################################
def regex_findAll(data: str, prefix: str, suffix: str):
    import re
    pattern=prefix + "(.*?)" + suffix

    # - remove escape char
    prefix=prefix.replace('\\', "")
    suffix=suffix.replace('\\', "")

    # - compile pattern
    regex=re.compile(pattern, re.IGNORECASE)

    return regex.findall(data)






############################################################
# [[a,b,c], [c,d,e], [1,2], f] --> [a,b,c,d,e,f,1,2]
############################################################
def flatten_nested_list(array: list=[]):
    _list=[]
    if isinstance(array, (list, tuple)):
        for item in array:
            if not item: continue
            if isinstance(item, list):
                _list.extend(item)
            else:
                _list.append(item)

    else:
        _list.append(array)

    # remove duplicates
    _list=list(dict.fromkeys(_list))

    return _list




############################################################
#
############################################################
def toJson(d: dict, filepath: str=None, title: str=None, indent=4, sort_keys=False):
    _dict={title: d} if title else d
    json_data=json.dumps(_dict, indent=indent, sort_keys=sort_keys, separators=(',', ': '), default=str)

    if filepath:
        return writeFile(filepath=filepath, data=json_data, replace=True)
    else:
        return json_data






############################################################
#
############################################################
def toYaml(d: dict, filepath: str=None, title: str=None, indent=4, sort_keys=False):
    if isinstance(d, SimpleNamespace):
        d=vars(d)

    if title:
        _dict=benedict({title: d})
    else:
        _dict=benedict(d)

    yaml_data=_dict.to_yaml(indent=indent, sort_keys=sort_keys, default_flow_style=False)

    if filepath:
        return writeFile(filepath=filepath, data=yaml_data, replace=True)
    else:
        return yaml_data


############################################################
#
############################################################
def toYamlLN(d: dict, title: str=None, indent=4, sort_keys=False):
    # tutto il giro per evitare che compaiano dei rifetimenti strani di benedict nel'output
    _dict={title: d} if title else d # add title
    _json_str=json.dumps(_dict) # convert benedict to json_str
    _json_dict=json.loads(_json_str) # convert json_str to dict
    yaml_data=yaml.dump(_json_dict, indent=indent, sort_keys=sort_keys, default_flow_style=False)
    return yaml_data



############################################################
#
############################################################
def zip_extract_file(archive_file: str, filename: str, content: bool=False, search_paths: list=[], out_dir: str='/tmp'):
    import zipfile

    """ check it its a zip file """
    if zipfile.is_zipfile(archive_file):
        zFile=zipfile.ZipFile(archive_file, "r")
        zFileNamelist=zFile.namelist()
        search_paths.insert(0, '')
        for path in search_paths:
            filepath=os.path.join(path, filename)
            if filepath in zFileNamelist:
                if content:
                    buffer=io.BytesIO(zFile.read(filepath))
                    content=buffer.read()
                    return content
                else:
                    zFile.extract(member=filepath, path=out_dir, pwd=None)
                    ftemp=f'{out_dir}/{filepath}'
                    return ftemp

    return None


######################################################
# - crea un dict con keys in bold case e value in italic (html syntax)
# - utile per invio messaggi su telegram
######################################################
def dict_bold_italic(d: dict, keys='bold', values='italic', nlevels=1):
    key_before=key_after=value_before=value_after=''

    if keys=='bold':
        key_before='<b>'
        key_after='</b>'
    elif keys=='italic':
        key_before='<i>'
        key_after='</i>'

    if values=='bold':
        value_before='<b>'
        value_after='</b>'
    elif values=='italic':
        value_before='<i>'
        value_after='</i>'

    new_dict={}
    for key, value in d.items():
        mode_key=f'{key_before}{key}{key_after}'
        if isinstance(value, dict) and nlevels>1:
            new_dict[mode_key]=dict_bold_italic(value, keys=keys, values=values, nlevels=nlevels)
        elif isinstance(value, (list, tuple)):
            new_dict[mode_key]=[]
            for item in value:
                new_dict[mode_key].append(f"{value_before}{item}{value_after}")
        else:
            new_dict[mode_key]=f"{value_before}{value}{value_after}"
    return new_dict









##############################################################
# - WRITE - FILE
# - writeFile version: 18-07-2023 12.54.30
##############################################################
def writeFile(filepath: (str, os.PathLike), *, data: (str, list, dict), replace: bool=False, write_datetime: bool=True):
    fout=Path(filepath).resolve()
    gv.logger.debug('writing file: %s', fout)

    if fout.exists() and replace is False:
        gv.logger.error('file %s already exists. No changes', fout )
        return None
    else:
        os.makedirs(fout.parent,  exist_ok=True)

    if isinstance(data, list):
        _data='\n'.join(data)

    elif isinstance(data, dict):
        d=data if isinstance(data, benedict) else benedict(data)
        extension=fout.suffix.lower()
        if extension=='.json':
            _data=json.dumps(d, indent=4, sort_keys=True, separators=(',', ': '), default=str)
        elif extension=='.yaml':
            _data=d.to_yaml(indent=4, sort_keys=True, default_flow_style=False)
        else:
            _data=f"output type {extension} managed"
    else:
        _data=data

    if write_datetime:
        date_time=datetime.now().strftime("%d-%m-%Y %H:%M")
        _data=f"#\n# Write time: {date_time}\n#\n" + _data

    if not _data.endswith('\n'):
        _data+="\n"

    with open(fout, "w") as f:
        f.write(_data)
        # f.write(f'{_data}\n')

    gv.logger.notify("File: %s has been written.", fout)
    return str(fout)





#######################################################
#
#######################################################
def keyb_prompt(text_msg: str, validKeys: list=["y", "n"]):
    exitKeys: list=["x", "q"]
    text_msg+=" - [x|q]quit ->: "
    if "ENTER" in exitKeys: exitKeys.append("")
    if "ENTER" in validKeys: validKeys.append("")
    while True:
        choice=input(text_msg).lower()
        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request.")
            sys.exit(0)

        elif choice in validKeys:
            break

        else:
            print('\n... please enter something\n')

    return choice




########################################################################
# -------------- PROMPT -------------------
########################################################################
def keyb_prompt_too_complexXXXXX(msg='', validKeys='ENTER', exitKeys='x|q', displayValidKeys=False, gVars={}):
    # -------------------------------
    def caller_info(message, stacknum=2):
        from inspect import getframeinfo, stack
        caller = getframeinfo(stack()[stacknum][0])
        funcname=os.sep.join(caller.filename.split(os.sep)[-2:])
        msg=f"{funcname}:{caller.lineno} - {message}"
        return msg
    # -------------------------------

    C=gVars['color'] if 'color' in gVars else None

    if not msg.startswith('\n'): print()
    if not msg:
        # msg=caller_info('Enter [c] to continue....')
        msg=caller_info('[c] to continue')
        validKeys='c'

    if not validKeys or not displayValidKeys:
        msg = f"     {msg} - ({exitKeys} to exit) ==> "
    else:
        msg = f"     {msg} [{validKeys}] - ({exitKeys} to exit) ==> "



    if C: msg=C.gWhiteH(msg)
    if isinstance(validKeys, (range)):
        _keys = []
        for i in validKeys:
            _keys.append(i)
        validKeys = '|'.join([str(x) for x in _keys])

    validKeys = validKeys.split('|')

    exitKeys = exitKeys.split('|')
    while True:
        choice      = input(msg).strip()
        choiceUPP   = choice.upper()

        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request.")
            sys.exit(0)

        if choice == '':
            if "ENTER" in exitKeys:
                sys.exit()
            if "ENTER" in validKeys:
                return ''
            else:
                print('\n... please enter something\n')

        elif "ENTER" in validKeys:
            return choice

        elif choice in validKeys:
            break

        else:
            print('\n... try again\n')

    return choice

# prompt=keyb_prompt





#################################################################
# --- remove multiple consecutive blank lines
#################################################################
def remove_multiple_consecutive_blank_lines(content: list) -> str:
    _str='\n'.join(content)
    new_data=re.sub(r'[\r\n][\r\n]{2,}', '\n\n', _str)
    return new_data




#################################################################
# key_name: nome della key da cercare
# key_prefix: prefisso da inserire prima del valore trovato
# is_ipaddress: considera il valore con un  indirizzo IP in modo da convertirlo in INT per poi fare il sort
# parent_level: up level (negative number) per identificare il punto da cui prendere il record
#
#################################################################
def sort_dict_by_keyvalue(d: dict, key_name: str, key_prefix: str, parent_level: int=0, is_ipaddress: bool=False, error_on_duplicate: bool=True, return_keylist=False):
    k=d.keypaths(indexes=False) ### get full keypath list
    _keyname=f".{key_name}"


    if parent_level>-1:
        gv.logger.error("il parent level [%s] è maggiore di -1, quindi non valido", parent_level)
    token_rec_name=parent_level-1 # aggiungiamo -1 in quanto -1 indica il livello che stiamo analizzando, quindi inserire almeno -2


    tmp_list=[]
    dup_list=[]
    sep="_@_"
    for key_path in k:
        if key_path.endswith(_keyname):
            gv.logger.debug("key_path: %s", key_path)

            tokens=key_path.split('.')
            rec_name=tokens[token_rec_name] ### nome del record da salvare
            rec_path=".".join(tokens[:parent_level]) # path al record originale

            gv.logger.debug("record path: %s", rec_path)

            value=d[key_path]
            _ip=None
            if is_ipaddress:
                try:
                    value=int(ipaddress.ip_address(d[key_path]))
                    _ip=d[key_path]
                except:
                    gv.logger.error("%s: %s - is not a valid ip address", key_path, d[key_path])
                    sys.exit()

            if error_on_duplicate:
                if not value in dup_list:
                    dup_list.append(value)
                else:
                    gv.logger.error("   keypath %s", key_path)
                    gv.logger.error("duplicate key %s ip: %s", value, _ip)
                    sys.exit(1)

            # if numeric: value=int(value)

            tmp_list.append(f"{key_prefix}{value}{sep}{rec_path}{sep}{rec_name}")



    ### create a final dict ordered by sorted_keylist
    new_db=OrderedDict()
    new_ordered_list=[]
    sorted_keylist=sorted(tmp_list) ### --- sort temp key_list
    for item in sorted_keylist:
        dummy, orig_keypath, rec_name=item.split(sep)
        new_ordered_list.append(orig_keypath)
        new_db[rec_name]={}
        new_db[rec_name].update(d[orig_keypath])

    if return_keylist:
        return new_ordered_list

    return new_db




#################################################################
# r = d.search(in_keys, in_keys=True, in_values=False, exact=True, case_sensitive=True)
# m = d.match(in_keys, indexes=True)
# f = d.find(['a.b.c', 'e.d.q'], default=0)
#################################################################
def benedict_search_key(d: dict, substr: str, first_match=False):
    _keys = d.keypaths(indexes=False) ### benedict function returns all keypaths
    valids=[_key for _key in _keys if substr in _key]
    if valids and first_match:
        return valids[0]

    return valids



#########################################################################
# cerca una stringa all'interno dei valori di un dictionary
# se incorriamo in un int, lo convertiamo in str
#
#   r = config.in_value(req_value="-805790016", exact_match=False)
#   r = config.in_value(req_value=-805790016, exact_match=False)
#########################################################################
def benedict_search_value(d: dict, req_value: str, exact_match=True):
    flatten_sep='/'
    flat_dict=d.flatten(separator=flatten_sep)
    results=[]
    req_type=type(req_value)
    for keypath, value in flat_dict.items():
        if isinstance(value, (int, float)):
            value=str(value)

        if type(value) == req_type:
            if exact_match:
                if req_value==value:
                    results.append((keypath, value))
            else:
                if req_value in value:
                    results.append((keypath, value))

    return results


################################################
### return value on first dict found or default
################################################
def getValueOnMdict(key_name: str, *, d1: dict={}, d2: dict={}, d3: dict={}, default=None):
    if   key_name in d1: return d1[key_name]
    elif key_name in d2: return d2[key_name]
    elif key_name in d3: return d3[key_name]
    else:                return default



################################################
### https://www.geeksforgeeks.org/compare-two-files-line-by-line-in-python/
################################################
def diff(file1: str, file2: str, exit_on_not_found=True):
    def use_difflib_differ(file1: str, file2: str):
        import difflib
        from difflib import Differ

        with open(file1) as file_1, open(file2) as file_2:
            differ = Differ()

            for line in differ.compare(file_1.readlines(), file_2.readlines()):
                print(line)


    def use_difflib(file1: str, file2: str):
        # Importing difflib
        import difflib

        with open(file1) as file_1:
            file_1_text = file_1.readlines()

        with open(file2) as file_2:
            file_2_text = file_2.readlines()

        # Find and print the diff:
        for line in difflib.unified_diff(file_1_text, file_2_text, fromfile=file1, tofile=file2, lineterm=''):
            print(line)


    def line_by_line2(file1: str, file2: str):
        f1_ID="@"
        f2_ID="#"
        if exit_on_not_found is False:
            if not Path(file1).exists(): return "[ERROR]"
            if not Path(file2).exists(): return "[ERROR]"

        print("Comparing files ", f"{f1_ID} + {file1}",f"{f2_ID} + {file2}",  sep='\n')

        f2=open(file2, "r")
        f1=open(file1, "r")


        # Use as a COunter
        line_no = 1

        file_1_line = f1.readline()
        file_2_line = f2.readline()

        diff_lines=[]
        while file_1_line != '' or file_2_line != '':

            # Removing whitespaces
            file_1_line = file_1_line.rstrip()
            file_2_line = file_2_line.rstrip()

            # Compare the lines from both file
            if file_1_line != file_2_line:

                # otherwise output the line on file1 and use @ sign
                if file_1_line == '':
                    line=f"{f1_ID} [{line_no:04}]  {file_1_line}"
                else:
                    line=f"{f1_ID} [{line_no:04}]- {file_1_line}"

                diff_lines.append(line)

                # otherwise output the line on file2 and use # sign
                if file_2_line == '':
                    line=f"{f2_ID} [{line_no:04}]  {file_2_line}"
                else:
                    line=f"{f2_ID} [{line_no:04}]- {file_2_line}"
                diff_lines.append(line)
                diff_lines.append("")

            # Read the next line from the file
            file_1_line = f1.readline()
            file_2_line = f2.readline()

            line_no += 1

        f1.close()
        f2.close()
        for line in diff_lines:
            print(line)

    # use_difflib(file1, file2)
    # use_difflib_differ(file1, file2)
    diff_lines=line_by_line2(file1, file2)
    return diff_lines






######################################################
# - Monkeys
######################################################
try:
    from dotmap import DotMap
    DotMap.toJson = _toJson
    DotMap.toYaml = _toYaml
except:
    pass

try:
    from benedict import benedict
    benedict.toYaml     = toYaml
    benedict.toJson     = toJson
    benedict.print_yaml = print_yaml
    benedict.py         = print_yaml
    benedict.print_json         = print_json
    benedict.pj         = print_json
    benedict.find_in_key   = benedict_search_key
    benedict.find_in_value = benedict_search_value
    print("YES benedict")
    # db=benedict(db, keyattr_enabled=True, keyattr_dynamic=False)



except:
    print("NO benedict")
    pass



# def is_bool(val):
#     return isinstance(val, bool)


def is_collection(val):
    return isinstance(val, (dict, list, set, tuple))


def is_function(val):
    return callable(val)

def is_integer_in_range(val, min: int, max: int):
    try:
        val=int(val)
    except:
        return False

    if val in range(min, max+1):
        return val
    return False


def is_json_serializable(val):
    json_types = (type(None), bool, dict, float, int, list, str, tuple)
    return isinstance(val, json_types)


def is_uuid(val):
    return is_string(val) and uuid_re.match(val)


def _test_dict():
    my_servers="""
        SERVER:
            S01:
                alias: ln_s01
                ssh_port: s01_1000
                host: 192.168.1.01
                credentials:
                    username: user_s01
                    password: passw_01
                location:
                    building: B01
                    floar: 1
                    room: 14
            S02:
                alias: ln_s02
                ssh_port: s02_2000
                host: 192.168.1.02
                credentials:
                    username: user_s02
                    password: passw_02
                location:
                    building: B02
                    floar: 2
                    room: 24
            servers:
            - server1:
                s11: s1_s01
                s12: s1_s02
            - server2:
                s21: s2_s01
                s22: s2_s02
            - server3:
                - s31: s3_s01
                - s32: s3_s02
       """
    server_dict=yaml.load(my_servers, Loader=yaml.SafeLoader)
    return server_dict



#######################################################
#
#######################################################
if __name__ == '__main__':
    gv=SimpleNamespace()
    gv.logger=nullLogger()

    fREGEX=True

    if fREGEX:
        data1='/media/loreto/LnDisk_SD_ext4/Filu/myData/MP3_songs/Stranieri/New_Age/Bellissima_Sampler/Sueno_de_San_Juan-[C_Peacock].mp3'
        data2='state.toTG .toLNloreto.toLNciao .toLNpippo-.toLNpippo-.toLNloreto.toLNciao'

        data3="${ciao_loreto} ${ciao_Ale}"
        data=regex_getDelimitedString(data=data3, prefix=r"\${", suffix="}", fLAST=False)
        print("regex_delimitedString - First:", data)

        data=regex_getDelimitedString(data=data3, prefix=r"\${", suffix="}", fLAST=True)
        print("regex_delimitedString - Last :", data)

        data=regex_findAll(data=data3, prefix=r"\${", suffix="}")
        print("regex_findAll                :", data)

    '''
    # from types import SimpleNamespace
    # gVars=SimpleNamespace()
    # gVars.logger=nullLogger()
    # setup(gVars=gVars)
    d=benedict(_test_dict())
    # r = d.ln_search('POWER', in_keys=True, in_values=False, exact=False, case_sensitive=True)
    # r = d.ln_search(in_keys="SERVER")
    r = d.in_key(in_str="building", first_match=True)
    print(r)
    r = d.in_key(in_str="building", first_match=False)
    print(r)
    r = d.in_key(in_str="buildingx", first_match=False)
    print(r)

    data=dict_bold_italic(d,  keys='bold', values='italic', nlevels=2)
    print(toYaml(data))
    '''
