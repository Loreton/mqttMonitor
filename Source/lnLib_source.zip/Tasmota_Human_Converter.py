#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 17-05-2024 18.26.36


import  sys; sys.dont_write_bytecode = True
import  os
this=sys.modules[__name__]

import sys
import json, yaml
from types import SimpleNamespace
from datetime import timedelta, datetime
import time
# from benedict import benedict


if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Time')
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Utils')
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/tasmota')


from LnUtils import is_integer_in_range
from LnSunTime import sunTime_casetta




#####################################
# gVars is benedict dictionary
#####################################
def setup(gVars: dict):
    global gv, C
    gv=gVars
    C=gv.logger.getColors()



####################################################################
# input:
#         "Timer1": {
#             "Enable": 1,
#             "Mode": 0,
#             "Time": "01:00",
#             "Window": 0,
#             "Days": "1111111",
#             "Repeat": 1,
#             "Output": 1,
#             "Action": 0
#         },
#
# voglamo tradurlo in:
#    Timers:
#       T1.x: 17:21 on LMMGVSD sS   x rappresenta il relay di output
#       T2.x: 22:30 off LMMGVSD   x rappresenta il relay di output
####################################################################
def singleTimerToHuman(timer_name: str, timer_data: dict, relay_nr: int=1) -> dict:
    gv.logger.caller('Entering in function...')
    # -----------------------------------
    def _convertWeekDays(val):
        _it_days='DLMMGVS' # tasmota days start from Sunday
        _en_days='SMTWTFS' # tasmota days start from Sunday
        separator='_ '
        _data=''
        for i in range(0, 7):
            _data+=_en_days[i] if val[i]=='1' else separator
        return _data[1:] + _data[0] # lets start from Monday



    # -----------------------------------
    def sum_offset(t0_time, offset):
        offset_HH, offset_MM=offset.split(':')
        offset_minutes=abs(int(offset_HH))*60+int(offset_MM)
        if offset_minutes==0:
            return t0_time

        t0_HH, t0_MM=t0_time.split(':')
        t0=timedelta(hours=int(t0_HH), minutes=int(t0_MM))
        ofs=timedelta(hours=int(offset_HH), minutes=int(offset_MM))

        if offset[0]=='-':
            new_time=t0-ofs
        else:
            new_time=t0+ofs

        return time.strftime("%H:%M", time.gmtime(new_time.total_seconds()))

    # -----------------------------------

    myTimer={}
    if timer_data:
        index=timer_name.split('Timer')[1] ### get timer_number, skip "Timers key"
        if index.isdigit():
            timer_nr=int(index)
        else:
            return myTimer

        output=int(timer_data['Output'])

        _action=['off', 'on', 'toggle', 'rule/blink']
        _mode=['clock time', 'sunrise', 'sunset']
        sunrise_time, sunset_time=sunTime_casetta(str_format='%H:%M')


        MODE   = _mode[int(timer_data['Mode'])]
        ACTION = _action[int(timer_data['Action'])]
        REPEAT = '-R' if timer_data['Repeat'] == 1 else '--'
        offset = timer_data["Time"]
        DAYS   = _convertWeekDays(timer_data['Days'])
        RELAY  = timer_data['Output']


        if MODE == 'sunset':
            onTime=' sS'
            offset=timer_data["Time"]
            _time=sum_offset(t0_time=sunset_time,offset=offset)

        elif MODE == 'sunrise':
            onTime=' sR'
            _time=sum_offset(t0_time=sunrise_time,offset=offset)

        else:
            onTime=''
            _time=timer_data["Time"]


        fOutput=False
        if fOutput:
            myTimer[f't{timer_nr}.{output}{REPEAT}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}' ### con Output/relayNr indicator
        else:
            myTimer[f't{timer_nr}{REPEAT}']=f'{_time} {ACTION.upper()} {DAYS}{onTime}'
            # myTimer=f'{_time} {ACTION.upper()} {DAYS}{onTime}'

    else:
        gv.logger.caller("data: %s", timer_data)

    return myTimer



####################################################################
# "RESULT": {
#         "Timers": "ON",
#         "Timer1": {
#             "Enable": 1,
#             "Mode": 0,
#             "Time": "01:00",
#             "Window": 0,
#             "Days": "1111111",
#             "Repeat": 1,
#             "Output": 1,
#             "Action": 0
#         },
#
# voglamo tradurlo in:
#    Timers:
#       T1.x: 17:21 on LMMGVSD sS   x rappresenta il relay di output
#       T2.x: 22:30 off LMMGVSD   x rappresenta il relay di output
####################################################################
def timersToHuman(timers_data: dict, relay_nr: int=1) -> dict:
    gv.logger.caller('Entering in function...')
    """ DO NOT MODIFY timers_data"""

    myTimers={}
    gv.logger.info("retrieving timer for relay: %s, on data: %s", relay_nr, timers_data, stacklevel=2)
    if not timers_data or not 'Timers' in timers_data:
        gv.logger.caller("data: %s", timers_data)
        return "N/A"


    areEnabled=timers_data["Timers"] ## remove from dictionary


    if areEnabled=='ON':
        for name in timers_data.keys():
            if name=="Timers": continue ### per sicurezza
            timerx=timers_data[name]
            if timerx['Enable']==0: continue
            if timerx['Output']!=relay_nr: continue
            hum_timerx=singleTimerToHuman(timer_name=name, timer_data=timerx, relay_nr=relay_nr)
            myTimers.update(hum_timerx)

    else:
        myTimers='Disabled'

    return myTimers









####################################################################################################
# setTimer number ena_dis HH:MM   days   output   repeat action
#
# setTimer   1    ena|dis 12:30 dlmMgvs     1      rep|norep on|off
#
# ref: https://tasmota.github.io/docs/Timers/#json-payload-anatomy
#-
# return:
#       Timer1 {"Enable":1,"Time":"02:23","Window":0,"Days":"--TW--S","Repeat":1,"Output":1,"Action":1}
####################################################################################################
def humanToTimer(args: (str, list), nRelays: int, device: dict) -> dict:
    gv.logger.caller('Entering in function...')
    ret=SimpleNamespace(err_msg=None, timer_name=None, payload={}, execute=False)

    ### -------------------------------
    def _time(hhmm):
        hh, mm, *rest=f'{hhmm}:'.split(':') # per evitare errore nello splitting
        hh=is_integer_in_range(hh, 0, 23)
        mm=is_integer_in_range(mm, 0, 59)
        if hh is False or mm is False:
            ret.err_msg=f"invalid time [{hhmm}] value"
            ret.rcode=1

        return hhmm


    def _days(days):
        _it_days='dlmMgvs' # tasmota days start from Sunday
        _en_days='smtwtfs' # tasmota days start from Sunday
        _days=''
        for i in range(0, 7):
            _days+="1" if _it_days[i] in days else "0"
        return _days

    ### -------------------------------



    if args:
        timer_nr=is_integer_in_range(args[0], 1, 16)
    else:
        ret.err_msg={ "Syntax":
            {
                "1":         "timer_Nr [1..16]",
                "ena|dis":   "enable",
                "12:30":     "time",
                "d_dlmMgvs":  "days",  ### non mettere il punto perchè è il keysep di benedict
                "rx":        "relay_Nr [1..2]",
                "rep|norep": "repeat",
                "on|off":    "action",
                }

            }
        return ret


    if timer_nr:
        if 'TIMERS' in device:
            timer_name=f'Timer{timer_nr}'
            timerx=device['TIMERS'][timer_name] ### prendiamo i dati del timer corrente
        else:
            ret.err_msg="timers not found on mqttmonitor file"
            return ret
    else:
        ret.err_msg="timer number wrong (1..16)"
        return ret

    # @LnToDo:  03-03-2023 verificato il numero del timer ... procedere oltre
    gv.logger.notify('Current timer %s %s', timer_name, timerx)

    ### andiamo a modificarli se necessario
    # rest_args=args[1:]
    for arg in args[1:]:
        if arg=='ena':          timerx["Enable"]=1
        elif arg=='dis':        timerx["Enable"]=0
        elif arg=='r1':         timerx["Output"]=1
        elif arg=='r2':         timerx["Output"]=2 if nRelays>1 else 1
        elif arg=='rep':        timerx["Repeat"]=1
        elif arg=='norep':      timerx["Repeat"]=0
        elif arg=='on':         timerx["Action"]=1
        elif arg=='off':        timerx["Action"]=0
        elif arg[0:2]=='d_':    timerx["Days"]=_days(arg[2:])
        elif ':' in arg:        timerx["Time"]=_time(arg)

    gv.logger.notify('new timer %s %s', timer_name, timerx)

    if timerx["Enable"]==1:
        timerx["Mode"]=0
        timerx["Windows"]=0

    ret.timerx=timerx
    ret.timer_name=timer_name

    return ret





####################################################################
#
# {"PulseTime":{"Set":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"Remaining":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}}
#
#   PulseTime<x>:   Display the amount of PulseTime remaining on the corresponding Relay<x>
#           0 / OFF = disable use of PulseTime for Relay<x>
#           1..111 = set PulseTime for Relay<x> in 0.1 second increments
#           112..64900 = set PulseTime for Relay<x>, offset by 100, in 1 second increments.
#           Add 100 to desired interval in seconds, e.g.,
#           PulseTime 113 = 13 seconds and PulseTime 460 = 6 minutes (i.e., 360 seconds)
#           <value> Set the duration to keep Relay<x> ON when Power<x> ON command is issued.
#           After this amount of time, the power will be turned OFF.
#
####################################################################
def humanToPulseTime(value: str):
    gv.logger.caller('Entering in function...')
    ret=SimpleNamespace(rcode=1, err_msg=None, pulsetime_value=0)

    #-------------------------------------------------
    def secondsToPulseTime(seconds: float) -> int:
        seconds=float(seconds)
        if seconds<=11.1:
            pulsetime_value=seconds*10
        else:
            pulsetime_value=float(seconds)+100

        return float(pulsetime_value)
    #-------------------------------------------------

    try: ### if passed as seconds
        ret.pulsetime_value=secondsToPulseTime(seconds=float(value))
        ret.rcode=0

    except (ValueError):
        try:
            mm, ss=value.split(':')
            ret.pulsetime_value=secondsToPulseTime(seconds=int(mm)*60+float(ss))
            ret.rcode=0

        except (Exception) as exc:
            ret.err_msg=f"ERROR evaluating seconds value '{value}')"

    return ret



####################################################################
### preparazione stato PulseTime
### relay_nr: parte da '0''
####################################################################
   #----------------------------------------------
def pulseTimeToHuman(pulsetime_data: dict, relay_nr: int, strip_leading=False):
    gv.logger.caller('Entering in function...')
    gv.logger.info("retrieving pulsetime for relay: %s, on data: %s", relay_nr, pulsetime_data, stacklevel=2)

    #-----------------------------------------------
    #-
    #-----------------------------------------------
    def millisecs_to_HMS_ms(milliseconds, strip_leading=False):
        s, ms = divmod(milliseconds, 1000)
        m, s = divmod(s, 60)
        h, m = divmod(m, 60)
        hours=int(h)
        minutes=int(m)
        seconds=int(s)
        # milliseconds=int(ms)
        milliseconds = f'.{int(ms):01}' if ms>0 else ''

        ret_val=f'{hours:02}:{minutes:02}:{seconds:02}{milliseconds}'
        if strip_leading:
            if h==0 and minutes==0:
                ret_val=f'{seconds:02}{milliseconds}'
            elif h==0:
                ret_val=f'{minutes:02}:{seconds:02}{milliseconds}'


        return ret_val

    #-----------------------------------------------
    #-
    #-----------------------------------------------
    def pulsetime_to_ms(value):
        if value<=111:
            seconds=int(value/10)
            milliseconds=(value/10)*1000
        else:
            seconds=int(value-100)
            milliseconds=(value-100)*1000
        return milliseconds
    #-----------------------------------------------


    pulsetime_value="?"
    pulsetime_remaining="?"

    # @ToDo:  16-03-2023 File "/media/loreto/LnDiskExt4/lnDisk/GIT-REPO/Python/mqttMonitor/Source/lnLib/Tasmota_Human_Converter.py", line 388, in pulseTimeToHuman

    if pulsetime_data:
        SET=pulsetime_data["Set"]
        s_ms=pulsetime_to_ms(SET[relay_nr-1])
        pulsetime_value=millisecs_to_HMS_ms(milliseconds=s_ms, strip_leading=True)

        REMAINING=pulsetime_data["Remaining"]
        r_ms=pulsetime_to_ms(REMAINING[relay_nr-1])
        if r_ms>s_ms: ### a volte il valore è strano dec: 690978 hex:A8B22 # @Loreto:  10-10-2023
            r_ms=s_ms
        pulsetime_remaining=millisecs_to_HMS_ms(milliseconds=r_ms, strip_leading=True)



    return pulsetime_value, pulsetime_remaining



#################################################
#
#################################################
def checkRange(value: int, min: int, max: int) -> int:
    gv.logger.caller('Entering in function...')
    ret=SimpleNamespace(rcode=1, err_msg=None, value=-1)

    try:
        if int(min) <= int(value) <= int(max)+1:
            ret.value=int(value)
            ret.rcode=0
        else:
            raise ValueError

    except (ValueError):
        ret.err_msg=f"value: '{value}' is out of range"

    except (Exception) as exc:
        ret.err_msg=str(exc)


    return ret






TIMERS= {
        "Timers": "ON",
        "Timer1": {
            "Enable": 1,
            "Mode": 0, # clock
            "Mode": 2, # sunset
            "Mode": 1, # sunrise
            "Time": "01:30",
            "Window": 0,
            "Days": "1111111",
            "Repeat": 1,
            "Output": 1,
            "Action": 0
        },
        "Timer2": {
            "Enable": 1,
            "Mode": 0, # clock
            "Mode": 1, # sunrise
            "Mode": 2, # sunset
            "Time": "01:30",
            "Window": 0,
            "Days": "1111111",
            "Repeat": 1,
            "Output": 2,
            "Action": 0
        },
    }



if __name__ == '__main__':
    # args="t,1 e.ena 21:15 rep on "
    # args=' '.join(sys.argv[1:])
    data=humanToTimer(args=sys.argv[1:], nRelays=1)
    # print(args)
    print("rcode: ", data.rcode)
    if data.rcode:
        print("err_msg: ", data.err_msg)
    print("payload", data.payload)
    sys.exit()


