#!/usr/bin/python
# -*- coding: utf-8 -*-

import  sys; sys.dont_write_bytecode = True
import os
import logging; logger=logging.getLogger(__name__)

import random
import time
from queue import Queue
from paho.mqtt import client as mqtt_client # pip3 install paho-mqtt
from benedict import benedict
# from LnUtils import toJson


# https://www.emqx.com/en/blog/how-to-use-mqtt-in-python


class MqttTxRx_Class():
    def __init__(self, broker: dict, logger):
        self.logger = logger
        self.broker = broker
        self.q=Queue()



    ##########################################################################
    #
    ##########################################################################
    def connect_mqtt(self, client_id: str):
        def on_connect(client, userdata, flags, rc):
            if rc == 0:
                self.logger.info("Connected to MQTT Broker!")
                client.is_connected=True
            else:
                self.logger.error("Failed to connect, return code %d\n", rc)
                client.is_connected=False


        def on_disconnect(client, userdata, rc):
            self.logger.info("disconnecting reason: %s", rc)
            client.loop_stop()
            client.is_connected=False

        client=mqtt_client.Client(client_id)
        if "password" in self.broker: client.username_pw_set(username=self.broker.username, password=self.broker.password)

        client.on_connect=on_connect
        client.on_disconnect=on_disconnect
        self.logger.notify('connecting broker %s: %s', self.broker.broker_name, self.broker.url)
        client.connect(self.broker.url, self.broker.port)

        time.sleep(1)
        """Wait for connection setup to complete"""
        if client.is_connected is False:
            self.logger.error('Mqtt client cannot connect to broker')
            sys.exit(1)

        return client



    ##########################################################################
    #
    ##########################################################################
    def subscribe(self, client: mqtt_client, topic: str):
        def on_message(client, userdata, msg):
            payload=msg.payload.decode()
            # self.received(client=client, msg=msg)
            self.logger.info(f"Topic: '%s' - Received payload: '%s'", msg.topic, payload)
            self.q.put(payload)
            client.disconnect()


        self.logger.notify('Subscribing topic: %s', topic, stacklevel=2)
        # self.logger.info('Subscribing topic: %s', topic)
        result, mid=client.subscribe(topic)
        self.logger.info('    result: %s message-ID: %s', result, mid)

        client.on_message=on_message




    ##########################################################################
    #
    ##########################################################################
    def publish(self, client: mqtt_client, topic: str, payload):
        self.logger.notify('publishing: topic: %s -  payload: %s', topic, payload, stacklevel=2)
        result=client.publish(topic=topic, payload=payload, qos=0, retain=False)

        status = result[0] # result: [0, 1]
        if status == 0:
            self.logger.info("Topic: %s - successfully sent to '%s' - [Payload '%s'] ", topic, payload, self.broker.broker_name)
        else:
            self.logger.error("Failed sending message '%s' to topic %s", payload, topic)



    # ----------------------------------------
    # -
    # ----------------------------------------
    def send(self, topic: str, payload: str, waitForReply: int=0, response_topic: str=None):
        client_id = f'python-mqtt-{random.randint(0, 1000)}'
        """generate client ID with randomly suffix """

        client=self.connect_mqtt(client_id)
        client.loop_start() # oppure  client.loop_forever()


        if response_topic:
            self.subscribe(client=client, topic=response_topic)
        else:
            self.subscribe(client=client, topic=topic)


        if isinstance(payload, dict):
            payload=benedict(payload, keyattr_enabled=True, keyattr_dynamic=False)
            payload=payload.toJson()
        self.publish(client=client, topic=topic, payload=payload)


        ''' Attendiamo il tempo neessario e poi verifichiamo che il payload sia identico a quello ricevuto
            questo perché facciamo il subsrcibing sullo stesso topic di trasmissione
            Quindi siamo certi che il messaggio abbia raggiunto il broker '''
        msg='OK'
        if waitForReply:
            sleeptime=.1
            waitForReply/=sleeptime
            while waitForReply>0 and client.is_connected:
                time.sleep(sleeptime) # Wait for message
                waitForReply-=1

            while not self.q.empty():    # check if the queue is empty
                new=self.q.get()         # get the first message which was received and delete
                if not payload==new:
                    msg='BAD'

        return msg



def test_telegram():
    device_name="FaroLetto"
    commands="firmware ipaddress mqtt net_status power poweronstate pulsetime ssid summary status timers version"
    topic=f"LnTelegram/{device_name}/alias"
    for command in commands:
        payload={
                'command': null,
                'payload': null,
                'debug': false,
                'host': "LnPi31",
                'bot_name': "LnCasettaBot",
                'alias': "{command}"
                }
        data=send(brokers='lnmqtt', topic=topic, payload=payload, waitForReply=5)



if __name__ == '__main__':
    global gv
    from types import SimpleNamespace

    gv=SimpleNamespace()

    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s [%(levelname)4s] - [%(module)s.%(funcName)s:%(lineno)4s]: %(message)s')
    gv.logger.info('start')
    setup(gVars=gv)
    yaml_file=os.path.expandvars("${ln_ENVARS_DIR}/yaml/Mqtt_Brokers.yaml")

    with open(yaml_file, 'r') as f:
        content=f.read() # single string
        yaml_data=yaml.load(content, Loader=yaml.FullLoader)


    # MQTT.send(broker=gv.broker, topic=_topic, payload=_payload, waitForReply=0)
    ### non ritorna il valore
    # data=send(brokers='emq', topic="python/mqtt", payload="Ciao messaggio", waitForReply=5)
    print(yaml_data)

